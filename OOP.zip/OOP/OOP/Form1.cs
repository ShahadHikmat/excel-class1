﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOP
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //Syntax to create an object of class
        //create an object of type integer,and store it in the variable obje1
        Human Obj1 = new Human();
        //create an object of type integer,and store it in the variable obje2 and this object is different from obj1 ,and will have its own independent value

        Human Obj2 = new Human();

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Increase Age +1 __ in obj1 by calling the Human class-->Obj1.IncreaseAge()
            // it is start by age=0 or  [ get it from setAge(textbox2) ]
            //put the valve in textBox1
            textBox1.Text = Convert.ToString(Obj1.IncreaseAge());
        }

       

        private void button3_Click(object sender, EventArgs e)
        {
            //get Age - obj1
            
            //call the class
            // Obj1.GetAge() from class human
            //put the valve in textBox3
            textBox3.Text = Obj1.GetAge().ToString();
           
        }
        //Set age -obj1
        private void button4_Click(object sender, EventArgs e)
        {
            //check if the textbox2 is empty then show me messagebox and end 
            if (textBox2.Text == "")
            {
                MessageBox.Show("Please fill in the text box");
            }
            else
            {

                //call the class human 
                // call object class SetAge(textBox2) --- (convert textBox2  to integer32)
                Obj1.SetAge(Convert.ToInt32(textBox2.Text));
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {

            //Increase Age +1 __ in obj1 by calling the Human class-->Obj2.IncreaseAge()
            // it is start by age=0
            //put the valve in textBox4

            textBox4.Text = Convert.ToString(Obj2.IncreaseAge());

        }
        private void button5_Click(object sender, EventArgs e)
        {
            if (textBox5.Text == "")
            {
                MessageBox.Show("Please fill in the text box");
            }
            else
            {

                //call the class human 
                // call object class SetAge(textBox2) --- (convert textBox5  to integer32)
                Obj2.SetAge(Convert.ToInt32(textBox5.Text));
                //Obj1.SetAge(Convert.ToInt32(textBox5.Text));

            }

        }

        private void button6_Click(object sender, EventArgs e)
        {
            //get Age - obj2

            //call the class
            // Obj2.GetAge() from class human
            //put the valve in textBox6
            textBox6.Text = Obj2.GetAge().ToString();

        }
    }
}
