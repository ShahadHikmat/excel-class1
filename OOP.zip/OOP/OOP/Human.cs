﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*Object-oriented programming has several advantages over procedural programming:

OOP is faster and easier to execute
OOP provides a clear structure for the programs
OOP helps to keep the C++ code DRY "Don't Repeat Yourself", and makes the code easier to maintain, modify and debug
OOP makes it possible to create full reusable applications with less code and shorter development time
*/

namespace OOP
{
    //  create The class - name : Human
    internal class Human
    {
        // Attribute (int variable)
        int age;
        // Access specifier -public
        //method to access data members

        //public:Access is allowed for all classes.
        public Human()
        {
            // set value in class variable(age)
            age = 0;
        }
        /*public Human(int CAge)
        { 
            age = CAge;
        }*/
    
       
        public void SetAge(int input_two)             // get the input from textBox2    ( input_two=textBox2 )

        {

            // set the value in class variable(age)
            age = input_two;
        }
        public int GetAge()
        {
            //get the age's value from class Human
            return age;
            //return to form1 to put the value in textbox3
        }
        public int IncreaseAge()    // this is method and it is a function are unable an object to do something
        {
            //get the value from class Human
//Increase Age (+1 ) by calling
            age++;
            return age;
            //return to form1 to put the value in textbox1

        }

    }
}
