﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
			//create integer row
			int row = 1;
			//Convert my intput in textbox to integer then put it in variable name n with type integer
			int n = Convert.ToInt32(textBox1.Text) + 1;
			//  while loop - first triangle
			while (row < n)
			{

				int stars_count = 1;
				//  while loop to prints the spaces in the row
				while (stars_count <= n - row)
				{
					richTextBox1.Text = richTextBox1.Text + "  ";

					stars_count++;
				}
				stars_count = 1;
				//  while loop to prints the hashes in the row
				while (stars_count <= 2 * row - 1)
				{
					richTextBox1.Text = richTextBox1.Text + "#";

					stars_count++;
				}
				row++;
				richTextBox1.Text = richTextBox1.Text + "\n";
			}
			//  while loop to second but inverted
		
			while (row > 0)
			{
				int stars_count = 1;
				//  while loop to prints the spaces in the row
				while (stars_count <= n - row)
				{
					richTextBox1.Text = richTextBox1.Text + "  ";

					stars_count++;
				}
				stars_count = 1;
				//  while loop to prints the hashes in the row

				while (stars_count <= 2 * row - 1)
				{
					richTextBox1.Text = richTextBox1.Text + "#";

					stars_count++;
				}
				row--;
				// print in richTextBox1.Text
				richTextBox1.Text = richTextBox1.Text + "\n";
				// richTextBox1.Text- saved  our  printed 
			}
		}
	}
}
