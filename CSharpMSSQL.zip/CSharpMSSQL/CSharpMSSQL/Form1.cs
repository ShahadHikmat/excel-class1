﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharpMSSQL
{
    //At the base level for connecting DB to front end, we need to have something that connects and something that brings forth the records in ADO it was ConncetionOBJ and RecordSet Object
    //
    public partial class Form1 : Form
    {
        System.Data.SqlClient.SqlConnection _ConnObj;//we create the connection object to connect front end to the back end
        System.Data.SqlClient.SqlDataAdapter _DataAdapObj;//this helps us populate the dataset
                                                          //
       // Create DataSet
        DataSet _DataSet;//this is like our record set
        int _recordCount;
        int _currentRow;
        public Form1()
            
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // conecting to DataBase ------------------------
            // we create a new connection object
            _ConnObj = new System.Data.SqlClient.SqlConnection();
            //we use the location of our table as the connection string
            _ConnObj.ConnectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\repos\Teaching\C#\CSharpMSSQL\CSharpMSSQL\ClubMemebers.mdf;Integrated Security=True";
            _ConnObj.Open();     // Open connection
            String SqlStr = "SELECT * FROM MemberList";//makes our SQL statement
            //the following two lines are always used to connect to our table  
            System.Data.SqlClient.SqlConnection SC = new System.Data.SqlClient.SqlConnection(_ConnObj.ConnectionString);
            _DataAdapObj = new System.Data.SqlClient.SqlDataAdapter(SqlStr, _ConnObj);

            _DataSet = new DataSet(); //to create the object for DataSet

            _DataAdapObj.Fill(_DataSet,"MemberList");
           _recordCount = _DataSet.Tables["MemberList"].Rows.Count;// tells us how many records we have starting at 0
        }
        public void ShowRecord(int ThisRow)
        {
            //displays our row field in our textBoxes 
            textBox1.Text = _DataSet.Tables["MemberList"].Rows[ThisRow].Field<int>("MemberID").ToString();
            textBox2.Text = _DataSet.Tables["MemberList"].Rows[ThisRow].Field<String>("FirstName").ToString();
            textBox3.Text = _DataSet.Tables["MemberList"].Rows[ThisRow].Field<String>("LastName").ToString();
            textBox4.Text = _DataSet.Tables["MemberList"].Rows[ThisRow].Field<DateTime>("DOB").ToString();
            textBox5.Text = _DataSet.Tables["MemberList"].Rows[ThisRow].Field<String>("Rank").ToString();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            //goes to the first record and shows it
            _currentRow = 0;
            ShowRecord(_currentRow);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //increases our row number by 1
            _currentRow++;
            if (_currentRow > _recordCount - 1)
            {
                MessageBox.Show("End Of File");
                _currentRow--; 
            }
            ShowRecord(_currentRow);

        }

        private void button3_Click(object sender, EventArgs e)
        {
            //decreases our row number by 1

            _currentRow--;
            if (_currentRow < 0)
            {
                MessageBox.Show("Beginning Of File");
                _currentRow++;
            }
            ShowRecord(_currentRow);
        }

        private void button4_Click(object sender, EventArgs e)
        {  
            _currentRow = _recordCount - 1;
            ShowRecord(_currentRow);  // display 
        }

        private void button5_Click(object sender, EventArgs e)
        {
            // searching
            System.Data.DataRow[] FoundRows;
            String StrToFind;

            if (textBox1.Text == "")//check the input if empty ------> Show me massage
            {
                System.Windows.Forms.MessageBox.Show("Please Enter A Member ID To Find");  // display
                return; // back 
            }
            StrToFind = "MemberID =" + textBox1.Text;    // add to our string  
            FoundRows = _DataSet.Tables["MemberList"].Select(StrToFind); // search in the table to find it
            int _rowIndex;  // define 
            if (FoundRows.Length == 0)  // check if not return anything then add 
            {
                MessageBox.Show("Record Not Found"); // display 

            }
            else //Record Found
            {
                _rowIndex = _DataSet.Tables["MemberList"].Rows.IndexOf(FoundRows[0]); 
                _currentRow = _rowIndex;
                ShowRecord(_currentRow);
            }

        }

        private void button6_Click(object sender, EventArgs e)
        {
            ClearBoxes();  //Clear Data  --- calling function
        }
        //Clear Data 
        private void ClearBoxes()
        {
            textBox1.Clear();       
            textBox2.Clear();        
            textBox3.Clear();        
            textBox4.Clear();        
            textBox5.Clear();
        }

        private void button7_Click(object sender, EventArgs e)
        {  // add record
            System.Data.DataRow[] _foundRows;
            String StrToFind;

            if (textBox1.Text == "")//check the input if empty ------> Show me massage
            {
                MessageBox.Show("Please Enter in a member ID to Add");
            }
            StrToFind = "MemberID = " + textBox1.Text; // add to our string 
            _foundRows = _DataSet.Tables["MemberList"].Select(StrToFind);// search in the table to find it
            if (_foundRows.Length == 0) // check if not return anything then add
            {
                System.Data.DataRow NewRow = _DataSet.Tables["MemberList"].NewRow();
                System.Data.SqlClient.SqlCommandBuilder CommBuilder = new System.Data.SqlClient.SqlCommandBuilder(_DataAdapObj);
                NewRow.SetField<int>("MemberID", Convert.ToInt32(textBox1.Text));
                NewRow.SetField<String>("FirstName", textBox2.Text);
                NewRow.SetField<String>("LastName", textBox3.Text);
                NewRow.SetField<DateTime>("DOB", Convert.ToDateTime(textBox4.Text));
                NewRow.SetField<String>("Rank", textBox5.Text);
                _DataSet.Tables["MemberList"].Rows.Add(NewRow);
                _DataAdapObj.Update(_DataSet, "MemberList");
                _recordCount += 1;
                MessageBox.Show("Add Successful");
            }
            else  //Record Found- you can not add  - Duplicate Record
            {
                MessageBox.Show("Duplicate Record, Please Try Again");
            }
                
        }

        private void button8_Click(object sender, EventArgs e)
        {
            // Update

            System.Data.DataRow[] _foundRows;
            String StrToFind;
            int _rowIndex;
            if (textBox1.Text == "") //check the input if empty ------>n Show me massage
            {
                MessageBox.Show("Please Enter in a member ID to Add");
            }
            StrToFind = "MemberID = " + textBox1.Text;  // add to our string 
            _foundRows = _DataSet.Tables["MemberList"].Select(StrToFind);  // search in the table to find it
            System.Data.SqlClient.SqlCommandBuilder CommBuilder = new System.Data.SqlClient.SqlCommandBuilder(_DataAdapObj); // the CommandBuilder helps you to generate update, delete., and insert commands on a single database table for a data adapter
            if (_foundRows.Length == 0) // check if not return anything
            {
                MessageBox.Show("Record Not Found, Try again");
            }
            else  //Record Found
            {
                _rowIndex = _DataSet.Tables["MemberList"].Rows.IndexOf(_foundRows[0]);
                _DataSet.Tables["MemberList"].Rows[_rowIndex].SetField<String>("FirstName", textBox2.Text);
                _DataSet.Tables["MemberList"].Rows[_rowIndex].SetField<String>("LastName", textBox3.Text);
                _DataSet.Tables["MemberList"].Rows[_rowIndex].SetField<String>("DOB", textBox4.Text);
                _DataSet.Tables["MemberList"].Rows[_rowIndex].SetField<String>("Rank", textBox5.Text);
                MessageBox.Show("Update Successful!");

            }
        }

        private void button9_Click(object sender, EventArgs e)
        {             //delet
           DataRow[] _foundRows;
            String StrToFind;
            int _rowIndex;
            if (textBox1.Text == "") //check the input if empty ------> Show me massage
            {
                MessageBox.Show("Enter an ID, Please Try Again"); //display

            }
            StrToFind = "MemberID = " + textBox1.Text; // add our input to  string 
            _foundRows = _DataSet.Tables["MemberList"].Select(StrToFind); // search in table to find what we are looking for
            if (_foundRows.Length == 0)  // check if not return anything
            {
                MessageBox.Show("Record Not Found");
            }
            else  //Record Found - process to delet
            {
                int result; // define
                _rowIndex = _DataSet.Tables["MemberList"].Rows.IndexOf(_foundRows[0]);   // get
                  // Create a command builder object  
                 System.Data.SqlClient.SqlCommandBuilder CommBuilder = new System.Data.SqlClient.SqlCommandBuilder(_DataAdapObj); //helps developers generate update, delete., and insert commands on a single database table for a data adapter

                result = Convert.ToInt32(MessageBox.Show("Are you sure you want to Delete?", "Deleting Record", MessageBoxButtons.YesNo)); //  check it if you want to delet or not  - if yes then convert the result from yes to 6

                if (result == 6)
                {
                    _DataSet.Tables["MemberList"].Rows[_rowIndex].Delete();  // delete

                    _DataAdapObj.Update(_DataSet, "MemberList"); // update our Dateset

                    ClearBoxes();                   // clear data calling function
                    MessageBox.Show("Delete Successful");  // dispaly to end user
                    _recordCount -= 1; // decrease our record counter after delet
                   

                }
            }
        }
    }
}
