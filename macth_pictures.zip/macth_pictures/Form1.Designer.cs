﻿
namespace macth_pictures
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Button2 = new System.Windows.Forms.Button();
            this.PictureBox9 = new System.Windows.Forms.PictureBox();
            this.PictureBox8 = new System.Windows.Forms.PictureBox();
            this.PictureBox7 = new System.Windows.Forms.PictureBox();
            this.PictureBox6 = new System.Windows.Forms.PictureBox();
            this.PictureBox5 = new System.Windows.Forms.PictureBox();
            this.PictureBox4 = new System.Windows.Forms.PictureBox();
            this.PictureBox3 = new System.Windows.Forms.PictureBox();
            this.PictureBox2 = new System.Windows.Forms.PictureBox();
            this.PictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            this.SuspendLayout();
            // 
            // Button2
            // 
            this.Button2.Location = new System.Drawing.Point(344, 418);
            this.Button2.Name = "Button2";
            this.Button2.Size = new System.Drawing.Size(142, 54);
            this.Button2.TabIndex = 20;
            this.Button2.Text = "let\'s Play !";
            this.Button2.UseVisualStyleBackColor = true;
            this.Button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // PictureBox9
            // 
            this.PictureBox9.Image = global::macth_pictures.Properties.Resources.Z;
            this.PictureBox9.Location = new System.Drawing.Point(477, 214);
            this.PictureBox9.Name = "PictureBox9";
            this.PictureBox9.Size = new System.Drawing.Size(142, 90);
            this.PictureBox9.TabIndex = 19;
            this.PictureBox9.TabStop = false;
            this.PictureBox9.Click += new System.EventHandler(this.PictureBox9_Click);
            // 
            // PictureBox8
            // 
            this.PictureBox8.Image = global::macth_pictures.Properties.Resources.Z;
            this.PictureBox8.Location = new System.Drawing.Point(329, 215);
            this.PictureBox8.Name = "PictureBox8";
            this.PictureBox8.Size = new System.Drawing.Size(142, 90);
            this.PictureBox8.TabIndex = 18;
            this.PictureBox8.TabStop = false;
            this.PictureBox8.Click += new System.EventHandler(this.PictureBox8_Click);
            // 
            // PictureBox7
            // 
            this.PictureBox7.Image = global::macth_pictures.Properties.Resources.Z;
            this.PictureBox7.Location = new System.Drawing.Point(181, 215);
            this.PictureBox7.Name = "PictureBox7";
            this.PictureBox7.Size = new System.Drawing.Size(142, 90);
            this.PictureBox7.TabIndex = 17;
            this.PictureBox7.TabStop = false;
            this.PictureBox7.Click += new System.EventHandler(this.PictureBox7_Click);
            // 
            // PictureBox6
            // 
            this.PictureBox6.Image = global::macth_pictures.Properties.Resources.Z;
            this.PictureBox6.Location = new System.Drawing.Point(477, 118);
            this.PictureBox6.Name = "PictureBox6";
            this.PictureBox6.Size = new System.Drawing.Size(142, 90);
            this.PictureBox6.TabIndex = 16;
            this.PictureBox6.TabStop = false;
            this.PictureBox6.Click += new System.EventHandler(this.PictureBox6_Click);
            // 
            // PictureBox5
            // 
            this.PictureBox5.Image = global::macth_pictures.Properties.Resources.Z;
            this.PictureBox5.Location = new System.Drawing.Point(329, 119);
            this.PictureBox5.Name = "PictureBox5";
            this.PictureBox5.Size = new System.Drawing.Size(142, 90);
            this.PictureBox5.TabIndex = 15;
            this.PictureBox5.TabStop = false;
            this.PictureBox5.Click += new System.EventHandler(this.PictureBox5_Click);
            // 
            // PictureBox4
            // 
            this.PictureBox4.Image = global::macth_pictures.Properties.Resources.Z;
            this.PictureBox4.Location = new System.Drawing.Point(181, 119);
            this.PictureBox4.Name = "PictureBox4";
            this.PictureBox4.Size = new System.Drawing.Size(142, 90);
            this.PictureBox4.TabIndex = 14;
            this.PictureBox4.TabStop = false;
            this.PictureBox4.Click += new System.EventHandler(this.PictureBox4_Click);
            // 
            // PictureBox3
            // 
            this.PictureBox3.Image = global::macth_pictures.Properties.Resources.Z;
            this.PictureBox3.Location = new System.Drawing.Point(477, 19);
            this.PictureBox3.Name = "PictureBox3";
            this.PictureBox3.Size = new System.Drawing.Size(142, 90);
            this.PictureBox3.TabIndex = 13;
            this.PictureBox3.TabStop = false;
            this.PictureBox3.Click += new System.EventHandler(this.PictureBox3_Click);
            // 
            // PictureBox2
            // 
            this.PictureBox2.Image = global::macth_pictures.Properties.Resources.Z;
            this.PictureBox2.Location = new System.Drawing.Point(329, 18);
            this.PictureBox2.Name = "PictureBox2";
            this.PictureBox2.Size = new System.Drawing.Size(142, 90);
            this.PictureBox2.TabIndex = 12;
            this.PictureBox2.TabStop = false;
            this.PictureBox2.Click += new System.EventHandler(this.PictureBox2_Click);
            // 
            // PictureBox1
            // 
            this.PictureBox1.Image = global::macth_pictures.Properties.Resources.Z;
            this.PictureBox1.Location = new System.Drawing.Point(181, 19);
            this.PictureBox1.Name = "PictureBox1";
            this.PictureBox1.Size = new System.Drawing.Size(142, 89);
            this.PictureBox1.TabIndex = 11;
            this.PictureBox1.TabStop = false;
            this.PictureBox1.Click += new System.EventHandler(this.PictureBox1_Click);
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = global::macth_pictures.Properties.Resources.Z;
            this.pictureBox10.Location = new System.Drawing.Point(181, 311);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(142, 90);
            this.pictureBox10.TabIndex = 13;
            this.pictureBox10.TabStop = false;
            this.pictureBox10.Click += new System.EventHandler(this.pictureBox10_Click);
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = global::macth_pictures.Properties.Resources.Z;
            this.pictureBox11.Location = new System.Drawing.Point(329, 310);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(142, 90);
            this.pictureBox11.TabIndex = 16;
            this.pictureBox11.TabStop = false;
            this.pictureBox11.Click += new System.EventHandler(this.pictureBox11_Click);
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = global::macth_pictures.Properties.Resources.Z;
            this.pictureBox12.Location = new System.Drawing.Point(477, 310);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(142, 90);
            this.pictureBox12.TabIndex = 19;
            this.pictureBox12.TabStop = false;
            this.pictureBox12.Click += new System.EventHandler(this.pictureBox12_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 514);
            this.Controls.Add(this.Button2);
            this.Controls.Add(this.pictureBox12);
            this.Controls.Add(this.PictureBox9);
            this.Controls.Add(this.PictureBox8);
            this.Controls.Add(this.pictureBox11);
            this.Controls.Add(this.PictureBox7);
            this.Controls.Add(this.PictureBox6);
            this.Controls.Add(this.PictureBox5);
            this.Controls.Add(this.pictureBox10);
            this.Controls.Add(this.PictureBox4);
            this.Controls.Add(this.PictureBox3);
            this.Controls.Add(this.PictureBox2);
            this.Controls.Add(this.PictureBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.Button Button2;
        internal System.Windows.Forms.PictureBox PictureBox9;
        internal System.Windows.Forms.PictureBox PictureBox8;
        internal System.Windows.Forms.PictureBox PictureBox7;
        internal System.Windows.Forms.PictureBox PictureBox6;
        internal System.Windows.Forms.PictureBox PictureBox5;
        internal System.Windows.Forms.PictureBox PictureBox4;
        internal System.Windows.Forms.PictureBox PictureBox3;
        internal System.Windows.Forms.PictureBox PictureBox2;
        internal System.Windows.Forms.PictureBox PictureBox1;
        internal System.Windows.Forms.PictureBox pictureBox10;
        internal System.Windows.Forms.PictureBox pictureBox11;
        internal System.Windows.Forms.PictureBox pictureBox12;
    }
}

