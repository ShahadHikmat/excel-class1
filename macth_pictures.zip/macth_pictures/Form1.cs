﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace macth_pictures
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

        }

        int conter;
        int conter2;
        private void PictureBox1_Click(object sender, EventArgs e)
        {
            
            if (PictureBox1.Name == "" )
            {
                
                PictureBox1.Image = Image.FromFile("C:\\kiwi.jpeg");
                pics[0] = "1";
                PictureBox1.Name = ("C:\\kiwi.jpeg");
                conter++;
                conter2++;
                            }

            else
            {
                    PictureBox1.Name = "";
             PictureBox1.Image = Image.FromFile("C:\\z.jpeg");
                pics[0] = "";
                conter--;
            }

           if(conter==1)
                {
                MessageBox.Show("choose another picture - find the match");

            }
           else 
                {
                check();

                check_1();
                check_2();

            }

            
        }


        private void PictureBox4_Click(object sender, EventArgs e)
        {
            {

                if (PictureBox4.Name == "")
                {
                    PictureBox4.Image = Image.FromFile("C:\\kiwi.jpeg");
                    PictureBox4.Name = ("C:\\kiwi.jpeg");
                    pics[3] = "1";
                    conter2++;
                    conter++;
                }
               
                else
                {
                    PictureBox4.Name = "";

                    PictureBox4.Image = Image.FromFile("C:\\z.jpeg");
                    pics[3] = "";
                    conter--;
                    conter2 = 0;
                }
                if (conter == 1)
                {
                    MessageBox.Show("choose another picture - find the match");

                }
                else
                {
                    check();

                    check_1();
                    check_2();

                }
            }


        }
        private void PictureBox7_Click(object sender, EventArgs e)
        {
            {
                pics[6] = "";
                if (PictureBox7.Name == "")
                {
                    pics[6] = "7";
                    PictureBox7.Image = Image.FromFile("C:\\blackberry.jpeg");
                    PictureBox7.Name = ("C:\\blackberry.jpeg");
                    conter2++;
                    conter++;
                }
                else
                {

                    PictureBox7.Image = Image.FromFile("C:\\z.jpeg");
                    pics[6] = "";
                    conter--;
                    PictureBox7.Name = "";
                    conter2 = 0;
                }
                if (conter == 1)
                {
                    MessageBox.Show("choose another picture - find the match");

                }
                else
                {
                    check();

                    check_1();
                    check_2();

                }
            }


            }


            private void PictureBox2_Click(object sender, EventArgs e)
        {
            {
                pics[1] = "";
                if (PictureBox2.Name == "")
                {
                    pics[1] = "2";
                    PictureBox2.Image = Image.FromFile("C:\\strawberry.jpeg");
                    PictureBox2.Name = ("C:\\strawberry.jpeg");
                    conter2++;
                    conter++;
                }
                else
                {

                    PictureBox2.Image = Image.FromFile("C:\\z.jpeg");
                    pics[6] = "";
                    conter--;
                    PictureBox2.Name = "";
                    conter2 = 0;

                }
                if (conter == 1)
                {
                    MessageBox.Show("choose another picture - find the match");

                }
                else
                {
                    check();

                    check_1();
                    check_2();

                }
            }




        }
        string[] pics = new string[12];
        private void Button2_Click(object sender, EventArgs e)
        {
            delet();
        }

        private void delet()
        {
            conter = 0;
            conter2 = 0;



            PictureBox1.Image = Image.FromFile("C:\\z.jpeg");
            PictureBox2.Image = Image.FromFile("C:\\z.jpeg");
            PictureBox3.Image = Image.FromFile("C:\\z.jpeg");
            PictureBox4.Image = Image.FromFile("C:\\z.jpeg");
            PictureBox5.Image = Image.FromFile("C:\\z.jpeg");
            PictureBox6.Image = Image.FromFile("C:\\z.jpeg");
            PictureBox7.Image = Image.FromFile("C:\\z.jpeg");
            PictureBox8.Image = Image.FromFile("C:\\z.jpeg");
            PictureBox9.Image = Image.FromFile("C:\\z.jpeg");
            pictureBox10.Image = Image.FromFile("C:\\z.jpeg");
            pictureBox11.Image = Image.FromFile("C:\\z.jpeg");
            pictureBox12.Image = Image.FromFile("C:\\z.jpeg");

            PictureBox1.Name = "";
            PictureBox2.Name = "";
            PictureBox3.Name = "";
            PictureBox4.Name = "";
            PictureBox5.Name = "";
            PictureBox6.Name = "";
            PictureBox7.Name = "";
            PictureBox8.Name = "";
            PictureBox9.Name = "";
            pictureBox10.Name = "";
            pictureBox11.Name = "";
            pictureBox12.Name = "";
            for (int i = 0; i < 12; i++)
            {
                pics[i] = "";
                //MessageBox.Show(i +":"+ pics[i]) ;
            }
        }
        private void check_2()
        {
        
            if (conter2==2)
            {
       

                if ( (pics[0] == "1" && pics[3] == "4") && (pics[0] != "" || pics[3] != ""))
                {

                    PictureBox1.Image = Image.FromFile("C:\\kiwi.jpeg");
                    PictureBox4.Image = Image.FromFile("C:\\kiwi.jpeg");

                    conter2 = 0;

                }


                else

                {

                     PictureBox1.Image = Image.FromFile("C:\\z.jpeg");
                     PictureBox4.Image = Image.FromFile("C:\\z.jpeg");
                     pics[0] = "";
                    pics[3] = "";
                     conter2 = 0;

                    PictureBox1.Name = "";
                    PictureBox4.Name = "";
                }

                
            if ( (pics[2] == "3" && pics[1] == "2") && (pics[1] != "" || pics[2] != ""))

                {

                    PictureBox2.Image = Image.FromFile("C:\\strawberry.jpeg");
                    PictureBox3.Image = Image.FromFile("C:\\strawberry.jpeg");

                    conter2 = 0;


                }

                else
                {

                  
                    PictureBox2.Image = Image.FromFile("C:\\z.jpeg");
                    PictureBox3.Image = Image.FromFile("C:\\z.jpeg");
                    pics[1] = "";
                    pics[2] = "";
                    conter2 = 0;
                    PictureBox2.Name = "";
                    PictureBox3.Name = "";
                }
                if ( (pics[4] == "5" && pics[7] == "8") && (pics[4] != "" || pics[7] != ""))

                {

                    PictureBox5.Image = Image.FromFile("C:\\pineapple.jpeg");
                    PictureBox8.Image = Image.FromFile("C:\\pineapple.jpeg");

                    conter2 = 0;
                 


                }
                else
                {


                    PictureBox5.Image = Image.FromFile("C:\\z.jpeg");
                    PictureBox8.Image = Image.FromFile("C:\\z.jpeg");
                    pics[4] = "";
                    pics[7] = "";
                    conter2 = 0;
                    PictureBox5.Name = "";
                    PictureBox8.Name = "";
                }

                if ((pics[5] == "6" && pics[8] == "9") && (pics[5] != "" || pics[8] != ""))

                {

                    PictureBox6.Image = Image.FromFile("C:\\apple.jpeg");
                    PictureBox9.Image = Image.FromFile("C:\\apple.jpeg");
              
                    conter2 = 0;
               

                }
                else
                {


                    PictureBox6.Image = Image.FromFile("C:\\z.jpeg");
                    PictureBox9.Image = Image.FromFile("C:\\z.jpeg");
                    pics[5] = "";
                    pics[8] = "";
                    conter2 = 0;
                    PictureBox6.Name = "";
                    PictureBox9.Name = "";
                }

                if ((pics[6] == "7" && pics[9] == "10") && (pics[6] != "" || pics[9] != ""))

                {

                    PictureBox7.Image = Image.FromFile("C:\\blackberry.jpeg");
                    pictureBox10.Image = Image.FromFile("C:\\blackberry.jpeg");

                    conter2 = 0;
           

                }

                else
                {


                    PictureBox7.Image = Image.FromFile("C:\\z.jpeg");
                    pictureBox10.Image = Image.FromFile("C:\\z.jpeg");
                    pics[6] = "";
                    pics[9] = "";
                    conter2 = 0;
                    PictureBox7.Name = "";
                    pictureBox10.Name = "";
                }
                if ((pics[10] == "11" && pics[11] == "12") && (pics[10] != "" || pics[11] != ""))

                {
                    pictureBox11.Image = Image.FromFile("C:\\banana.jpeg");
                    pictureBox12.Image = Image.FromFile("C:\\banana.jpeg");
                     conter2 = 0;
                }
                else
                {


                    pictureBox11.Image = Image.FromFile("C:\\z.jpeg");
                   pictureBox12.Image = Image.FromFile("C:\\z.jpeg");
                    pics[10] = "";
                    pics[11] = "";
                    conter2 = 0;
                    pictureBox11.Name = "";
                    pictureBox12.Name = "";
                }
                conter--;
                conter--;
                MessageBox.Show("Not matched");
            }
        }
            private void  check_1()
        {
            if ((pics[0] == pics[3] ) && (pics[0] == "1" && pics[3] == "1") && (pics[0] != "" || pics[3]!=""))
            {

                PictureBox1.Image = Image.FromFile("C:\\kiwi.jpeg");
                PictureBox4.Image = Image.FromFile("C:\\kiwi.jpeg");
                pics[0] = "1";
                pics[3] = "4";
                conter2 = 0;
                MessageBox.Show("pic 1 matched pic 4");

            }

            else if ((pics[1] == pics[2]) && (pics[2] == "2" && pics[1] == "2") && (pics[1] != "" || pics[2] != ""))

            {

                PictureBox2.Image = Image.FromFile("C:\\strawberry.jpeg");
                PictureBox3.Image = Image.FromFile("C:\\strawberry.jpeg");
                pics[1] = "2";
                pics[2] = "3";
                conter2 = 0;
                MessageBox.Show("pic 2 matched pic 3");

            }

            else if ((pics[4] == pics[7]) && (pics[4] == "5" && pics[7] == "5") && (pics[4] != "" || pics[7] != ""))

            {

                PictureBox5.Image = Image.FromFile("C:\\pineapple.jpeg");
                PictureBox8.Image = Image.FromFile("C:\\pineapple.jpeg");
                pics[4] = "5";
                pics[7] = "8";
                conter2 = 0;
                MessageBox.Show("pic 5 matched pic 8");


            }
            else if ((pics[5] == pics[8]) && (pics[5] == "6" && pics[8] == "6") && (pics[5] != "" || pics[8] != ""))

            {

                PictureBox6.Image = Image.FromFile("C:\\apple.jpeg");
                PictureBox9.Image = Image.FromFile("C:\\apple.jpeg");
                pics[5] = "6";
                pics[8] = "9";
                conter2 = 0;
                MessageBox.Show("pic 6 matched pic 9");

            }

            else if ((pics[6] == pics[9]) && (pics[6] == "7" && pics[9] == "7") && (pics[6] != "" || pics[9] != ""))

            {

                PictureBox7.Image = Image.FromFile("C:\\blackberry.jpeg");
                pictureBox10.Image = Image.FromFile("C:\\blackberry.jpeg");
                pics[6] = "7";
                pics[9] = "10";
                conter2 = 0;
                MessageBox.Show("pic 7 matched pic 10");

            }

            else if ((pics[10] == pics[11]) && (pics[10] == "11" && pics[11] == "11") && (pics[10] != "" || pics[11] != ""))

            {
                pictureBox11.Image = Image.FromFile("C:\\banana.jpeg");
               pictureBox12.Image = Image.FromFile("C:\\banana.jpeg");
                pics[10] = "11";
                pics[11] = "12";
                conter2 = 0;
                MessageBox.Show("pic 11 matched pic 12");


            }




        }
        private void check()
        {
           
            if (conter==12)
            {
                MessageBox.Show("Done");
            }
        }
       
        private void Form1_Load(object sender, EventArgs e)
        {
            delet();
        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {

            {
                pics[10] = "";
                if (pictureBox11.Name == "")
                {
                    pics[10] = "11";
                    pictureBox11.Image = Image.FromFile("C:\\banana.jpeg");
                    pictureBox11.Name = ("C:\\banana.jpeg");
                    conter2++;
                    conter++;
                }
                else
                {

                    pictureBox11.Image = Image.FromFile("C:\\z.jpeg");
                    pics[10] = "";
                    conter--;
                    pictureBox11.Name = "";
                    conter2 = 0;
                }
                if (conter == 1)
                {
                    MessageBox.Show("choose another picture - find the match");

                }
                else
                {
                    check();

                    check_1();
                    check_2();

                }
            }

        }

        private void pictureBox12_Click(object sender, EventArgs e)
        {

            {
                pics[11] = "";
                if (pictureBox12.Name == "")
                {
                    pics[11] = "11";
                    pictureBox12.Image = Image.FromFile("C:\\banana.jpeg");
                    pictureBox12.Name = ("C:\\banana.jpeg");
                    conter2++;
                    conter++;
                }
                else
                {

                    pictureBox12.Image = Image.FromFile("C:\\z.jpeg");
                    pics[11] = "";
                    conter--;
                    pictureBox12.Name = "";
                    conter2 = 0;
                }
                if (conter == 1)
                {
                    MessageBox.Show("choose another picture - find the match");

                }
                else
                {
                    check();

                    check_1();
                    check_2();

                }
            }

        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            {
                pics[9] = "";
                if (pictureBox10.Name == "")
                {
                    pics[9] = "7";
                    pictureBox10.Image = Image.FromFile("C:\\blackberry.jpeg");
                    pictureBox10.Name = ("C:\\blackberry.jpeg");
                    conter2++;
                    conter++;
                }
                else
                {

                    pictureBox10.Image = Image.FromFile("C:\\z.jpeg");
                    pics[9] = "";
                    conter--;
                    pictureBox10.Name = "";
                    conter2 = 0;
                }
                if (conter == 1)
                {
                    MessageBox.Show("choose another picture - find the match");

                }
                else
                {
                    check();

                    check_1();
                    check_2();

                }
            }


        }

        private void PictureBox5_Click(object sender, EventArgs e)
        {
            {
                pics[4] = "";
                if (PictureBox5.Name == "")
                {
                    pics[4] = "5";
                    PictureBox5.Image = Image.FromFile("C:\\pineapple.jpeg");
                    PictureBox5.Name = ("C:\\pineapple.jpeg");
                    conter2++;
                    conter++;
                }
                
                else
                {
                    PictureBox5.Name = "";

                    PictureBox5.Image = Image.FromFile("C:\\z.jpeg");
                    pics[4] = "";
                    conter--;
                    conter2 = 0;
                }
                if (conter == 1)
                {
                    MessageBox.Show("choose another picture - find the match");

                }
                else
                {
                    check();

                    check_1();
                    check_2();

                }
            }
        }

        private void PictureBox3_Click(object sender, EventArgs e)
        {
            {
              
            pics[2] = "";
            if (PictureBox3.Name == "")
            {
                pics[2] = "2";
                PictureBox3.Image = Image.FromFile("C:\\strawberry.jpeg");
                PictureBox3.Name = ("C:\\strawberry.jpeg");
                conter2++;
                    conter++;
                }
            else
            {

                PictureBox3.Image = Image.FromFile("C:\\z.jpeg");
                pics[2] = "";
                conter--;
                PictureBox3.Name = "";
                conter2 = 0;
            }
                if (conter == 1)
                {
                    MessageBox.Show("choose another picture - find the match");

                }
                else
                {
                    check();

                    check_1();
                    check_2();

                }
            }


    }

        private void PictureBox6_Click(object sender, EventArgs e)
        {
            {
                pics[5] = "";
                if (PictureBox6.Name == "")
                {
                    pics[5] = "6";
                    PictureBox6.Image = Image.FromFile("C:\\apple.jpeg");
                    PictureBox6.Name = ("C:\\apple.jpeg");
                    conter2++;
                    conter++;
                }
                else
                {

                    PictureBox6.Image = Image.FromFile("C:\\z.jpeg");
                    pics[5] = "";
                    conter--;
                    PictureBox6.Name = "";
                    conter2 = 0;
                }
                if (conter == 1)
                {
                    MessageBox.Show("choose another picture - find the match");

                }
                else
                {
                    check();

                    check_1();
                    check_2();

                }
            }


        }

        private void PictureBox8_Click(object sender, EventArgs e)
        {
            { 
            pics[7] = "";
            if (PictureBox8.Name == "")
            {
                pics[7] = "5";
                PictureBox8.Image = Image.FromFile("C:\\pineapple.jpeg");
                PictureBox8.Name = ("C:\\pineapple.jpeg");
                conter2++;
                    conter++;
                }
            else
            {

                PictureBox8.Image = Image.FromFile("C:\\z.jpeg");
                pics[7] = "";
                conter--;
                PictureBox8.Name = "";
                conter2 = 0;
            }
                if (conter == 1)
                {
                    MessageBox.Show("choose another picture - find the match");

                }
                else
                {
                    check();

                    check_1();
                    check_2();

                }
            }


    }

        private void PictureBox9_Click(object sender, EventArgs e)
        {
            { 
            pics[8] = "";
            if (PictureBox9.Name == "")
            {
                pics[8] = "6";
                PictureBox9.Image = Image.FromFile("C:\\apple.jpeg");
                PictureBox9.Name = ("C:\\apple.jpeg");
                conter2++;
                    conter++;
                }
            else
            {

                PictureBox9.Image = Image.FromFile("C:\\z.jpeg");
                pics[8] = "";
                conter--;
                PictureBox9.Name = "";
                conter2 = 0;
            }
                if (conter == 1)
                {
                    MessageBox.Show("choose another picture - find the match");

                }
                else
                {
                    check();

                    check_1();
                    check_2();

                }
            }


    }
}
}

