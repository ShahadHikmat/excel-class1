
// // Reverse 1
function _Reverse(sum){
  var sum ="";
  var number_input=document.getElementById("Reverse").value;
  console.log(number_input)
  for(var i=number_input.length-1;i >=0;i--)
  {console.log(number_input[i])
    sum =sum + number_input[i];
   }
 document.getElementById("result_").innerText=`${sum}`;
  }
  document.getElementById("ok-shape2").addEventListener("click", _Reverse);
console.log(_Reverse)


// // Reverse 2--------------------------------------------------------------------------------------
// function _Reverse(){
//     var number_input=document.getElementById("Reverse").value;
//  var rever_number=  number_input.split("").reverse().join(""); /// got it copy ---->(.reverse() ///
// document.getElementById("result_").innerText=rever_number;
// }
// document.getElementById("ok-shape2").addEventListener("click", _Reverse);



// // Reverse---- trying ----to more work on return value and string 3--------------------------------------------------------------------
//   var i=0;
//   function _Reverse(){  
// var rever_number=document.getElementById("Reverse").value;
// console.log(rever_number, typeof rever_number);
// var Array_change =rever_number.split('');
// i=Array_change.length;
//  for(i=0;i <= Array_change.length;i++)
//  {
//   var x= Array_change[0];
// var rever_number4=`${x}`;
// var y= Array_change[1];
//   rever_number4=`${y}${x}`;
//   var z= Array_change[2];
//   rever_number4=`${z}${y}${x}`;
//   var z2= Array_change[3];
//   // rever_number4=`${z2}${z}${y}${x}`;
//   // var z3= Array_change[4];
//   // rever_number4=`${z3}${z2}${z}${y}${x}`;
//   // var z4= Array_change[5];
//   // rever_number4=`${z4}${z3}${z2}${z}${y}${x}`;
// //   console.log("out off the rang ");
// //  }
//     console.log("change to string = ",rever_number4);
// }
// console.log(Array_change);
// console.log("input number",rever_number, typeof rever_number);
// document.getElementById("result_").innerText=rever_number4;
// }
// document.getElementById("ok-shape2").addEventListener("click", _Reverse);
//--------------------------------------------------------------------------------------------------------------------------------------//


// change background -random color for whole body 
//randomColor-------The Decimal color 16777215 is a light color, and the websafe version is hex FFFFFF,
//  and the color name is white. ... A 20% lighter version of the original color is 16777215,
//  and 13027014 is the 20% darker color. If you saturate the color by 10%, you get 16770790, and if you desaturate by 10%, it is 16777215.

const _randomColor = () => {
    const randomColor = Math.floor(Math.random()*16777215).toString(16);
    document.body.style.backgroundColor = "#" + randomColor;
  }
  document.getElementById("ok-shape2").addEventListener("click", _randomColor);
 _randomColor();

// ----------------------------------------------------------------------------------------
 // change color for specific

 function clickFunction() { 
    
  document.getElementById("background").onclick=function()
  {
      var x, y, z, random;
      x = Math.round(Math.random()*256);
      y = Math.round(Math.random()*256);
      z = Math.round(Math.random()*256);
      random = 'rgb('+x+','+y+','+z+')';

      document.getElementById("background").style.backgroundColor = random;

      
  }}

  //---------------------------- another way 
  //   function clickFunction() {
//     let _background = document.getElementById('background');
//     console.log(_background);
//     let colors = ["red", "green", "blue", "yellow","gray","black","pink","brown","orange"];
//     const colorIndex = parseInt(Math.random() * colors.length);
//     _background.style.backgroundColor = colors[colorIndex];
//  }  
//-------------------------------------------

var counter = 0;
// // counter 1
var sub = (function () {
 
  return function () {return counter -= 1;}
})();

function myFunction2(){
  document.getElementById("demo").innerHTML = sub();
}

//-----------------------------------
var add = (function () {

  return function () {return counter += 1;}
})();

function myFunction(){
  document.getElementById("demo").innerHTML = add();
}

// //-----------------------------------
var rest = (function () {
 
  return function () {return counter =0;}
})();

function myFunction3(){
document.getElementById("demo").innerHTML = rest();

}



// --------------------------



// --------------------------
var sum3=0;
function _Calculator2(sum3){
  var number_input=document.getElementById("Calculator").value; //height in meters
  var number_input2=document.getElementById("Calculator2").value; // your weight in Kg
  
  console.log(number_input,number_input2)
    var sum3 = number_input2/(number_input*number_input);
    console.log(sum3)
    sum3=Math.round(sum3,1);
    


 if (sum3 <=18.5){
 console.log("Underweight")
 }else if (18.5<=sum3  && sum3<=24.9){
   
   console.log("Normal weight")
   }else if (25<=sum3 && sum3 <=29.9){
   
     console.log("Overweight")
     }
     else if (sum3>=30){
   
       console.log("Obesity")
       }
 document.getElementById("result_").innerText=`${sum3}`;
  }

var sum4 =0;
function _Calculator(sum4){
  var number_input3=document.getElementById("Calculator3").value; //height in inches
  var number_input4=document.getElementById("Calculator4").value; //your weight inpounds
  console.log(number_input3,number_input4,"befor-change")
 var number_input5=number_input3/39.37;   // inches to meter
var number_input6=number_input4/2.205;   // pound to kg
  console.log(number_input5,number_input6,"after-change")
  var sum4 = number_input6/(number_input5*number_input5);
    console.log(sum4)
    sum4=Math.round(sum4,1);
    
 if (sum4 <=18.5){
  console.log("Underweight")
  }else if (18.5<=sum4  && sum4<=24.9){
    
    console.log("Normal weight")
    }else if (25<=sum4 && sum4<=29.9){
    
      console.log("Overweight")
      }
      else if (sum4>=30){
    
        console.log("Obesity")
        }
 document.getElementById("result_2").innerText=`${sum4}`;
  }

  
 document.getElementById("ok-shape2").addEventListener("click", _Calculator2);
 
 document.getElementById("ok-shape3").addEventListener("click", _Calculator);

//-----------------------------------------


var img = document.createElement("img");
img.src = "2.jpeg";

var div = document.getElementById("x");
div.appendChild(img);

