﻿Public Class Form1
    Dim year As Integer
    Dim month As Integer
    Dim day As Integer
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click


        year = Convert.ToInt32(TextBox1.Text)
        month = Convert.ToInt32(TextBox2.Text)
        day = Convert.ToInt32(TextBox3.Text)






        If (1000 >= year Or year <= 3000) And (year <> 0 And year > 1000) Then

            If ((year Mod 2 = 0) And (year Mod 100 <> 0) And (year Mod 4 = 0)) Or ((year Mod 2 = 0) And (year Mod 100 = 0) And (year Mod 4 = 0) And (year Mod 400 = 0)) Then
                '   MessageBox.Show("Correct input", "Help Caption", MessageBoxButtons.OK,MessageBoxIcon.Information)
                TextBox4.Text = " Leap Year"
                RichTextBox1.Text = year

                ' MessageBox.Show("Yes , It is a Leap Year.", "Help Caption", MessageBoxButtons.OK, MessageBoxIcon.Information)
                If (1 >= month Or month <= 12) And (month <> 0 And month > 0) Then
                    RichTextBox2.Text = month

                    If (month = 1) Or (month = 3) Or (month = 5) Or (month = 7) Or (month = 8) Or (month = 10) Or (month = 12) Then
                        If (1 >= day Or day <= 31) And (day <> 0 And day > 0) Then
                            RichTextBox3.Text = day
                        Else
                            RichTextBox3.Text = "error in  your input @ day  -out off my range-"
                            TextBox4.Text = ""
                            MessageBox.Show("error in  your input @ day.",
                                   "Help Caption", MessageBoxButtons.OK,
                                   MessageBoxIcon.Error
                                   )
                        End If

                    ElseIf (month = 4) Or (month = 6) Or (month = 9) Or (month = 11) Then
                        If (1 >= day Or day <= 30) And (day <> 0 And day > 0) Then
                            RichTextBox3.Text = day
                        Else
                            RichTextBox3.Text = "error in  your input @ day -out off my range-"
                            TextBox4.Text = ""
                            MessageBox.Show("error in  your input @ day.",
                                   "Help Caption", MessageBoxButtons.OK,
                                   MessageBoxIcon.Error
                                   )
                        End If

                    ElseIf month = 2 Then
                        If ((year Mod 2 = 0) And (year Mod 100 <> 0) And (year Mod 4 = 0)) Or ((year Mod 2 = 0) And (year Mod 100 = 0) And (year Mod 4 = 0) And (year Mod 400 = 0)) Then
                            If (1 >= day Or day <= 29) And (day <> 0 And day > 0) Then
                                RichTextBox3.Text = day
                                TextBox4.Text = " Leap Year"
                            Else
                                RichTextBox3.Text = "error in  your input @ day -out off my range-"
                                TextBox4.Text = ""
                                MessageBox.Show("error in  your input @ day.",
                                   "Help Caption", MessageBoxButtons.OK,
                                   MessageBoxIcon.Error
                                   )
                            End If
                        Else
                            If (1 >= day Or day <= 28) And (day <> 0 And day > 0) Then
                                RichTextBox3.Text = day
                            Else
                                RichTextBox3.Text = "error in  your input @ day -out off my range-"
                                TextBox4.Text = ""
                                MessageBox.Show("error in  your input @ day.",
                                   "Help Caption", MessageBoxButtons.OK,
                                   MessageBoxIcon.Error
                                   )
                            End If
                        End If

                    End If

                Else
                    RichTextBox2.Text = "error in  your input @ month -out off my range-"
                    TextBox4.Text = ""
                    MessageBox.Show("error in  your input @ Month.",
                                   "Help Caption", MessageBoxButtons.OK,
                                   MessageBoxIcon.Error
                                   )
                End If

            Else
                'MessageBox.Show("Correct input",
                '                   "Help Caption", MessageBoxButtons.OK,
                '                   MessageBoxIcon.Information)
                TextBox4.Text = "Comman Year"
                RichTextBox1.Text = year
                'MessageBox.Show("Yes , It is a Comman Year.",
                '                   "Help Caption", MessageBoxButtons.OK,
                '                   MessageBoxIcon.Information)
                If (1 >= month Or month <= 12) And (month <> 0 And month > 0) Then
                    RichTextBox2.Text = month

                    If (month = 1) Or (month = 3) Or (month = 5) Or (month = 7) Or (month = 8) Or (month = 10) Or (month = 12) Then
                        If (1 >= day Or day <= 31) And (day <> 0 And day > 0) Then
                            RichTextBox3.Text = day
                        Else
                            RichTextBox3.Text = "error in  your input @ day  -out off my range-"
                            TextBox4.Text = ""
                            MessageBox.Show("error in  your input @ day.",
                                   "Help Caption", MessageBoxButtons.OK,
                                   MessageBoxIcon.Error
                                   )
                        End If

                    ElseIf ((month = 4) Or (month = 6) Or (month = 9) Or (month = 11)) Then
                        If (1 >= day Or day <= 30) And (day <> 0 And day > 0) Then
                            RichTextBox3.Text = day
                        Else
                            RichTextBox3.Text = "error in  your input @ day -out off my range-"
                            TextBox4.Text = ""
                            MessageBox.Show("error in  your input @ day.",
                                   "Help Caption", MessageBoxButtons.OK,
                                   MessageBoxIcon.Error
                                   )
                        End If

                    ElseIf month = 2 Then
                        If ((year Mod 2 = 0) And (year Mod 100 <> 0) And (year Mod 4 = 0)) Or ((year Mod 2 = 0) And (year Mod 100 = 0) And (year Mod 4 = 0) And (year Mod 400 = 0)) Then
                            If (1 >= day Or day <= 29) And (day <> 0 And day > 0) Then
                                RichTextBox3.Text = day
                                TextBox4.Text = " Leap Year"
                            Else
                                RichTextBox3.Text = "error in  your input @ day -out off my range-"
                                TextBox4.Text = ""
                                MessageBox.Show("error in  your input @ day.",
                                   "Help Caption", MessageBoxButtons.OK,
                                   MessageBoxIcon.Error
                                   )
                            End If
                        Else
                            If (1 >= day Or day <= 28) And (day <> 0 And day > 0) Then
                                RichTextBox3.Text = day
                            Else
                                RichTextBox3.Text = "error in  your input @ day -out off my range-"
                                TextBox4.Text = ""
                                MessageBox.Show("error in  your input @ day.",
                                   "Help Caption", MessageBoxButtons.OK,
                                   MessageBoxIcon.Error
                                   )
                            End If
                        End If

                    End If

                Else
                    RichTextBox2.Text = "error in  your input @ month -out off my range-"

                    TextBox4.Text = ""
                    MessageBox.Show("error in  your input @ Month.",
                                   "Help Caption", MessageBoxButtons.OK,
                                   MessageBoxIcon.Error
                                   )

                End If

            End If

        Else
            If (1 >= month Or month <= 12) And (month <> 0 And month > 0) Then
                RichTextBox2.Text = month

                If (month = 1) Or (month = 3) Or (month = 5) Or (month = 7) Or (month = 8) Or (month = 10) Or (month = 12) Then
                    If (1 >= day Or day <= 31) And (day <> 0 And day > 0) Then
                        RichTextBox3.Text = day
                    Else
                        RichTextBox3.Text = "error in  your input @ day  -out off my range-"
                        TextBox4.Text = ""
                        MessageBox.Show("error in  your input @ Month.",
                                   "Help Caption", MessageBoxButtons.OK,
                                   MessageBoxIcon.Error
                                   )
                    End If

                ElseIf (month = 4) Or (month = 6) Or (month = 9) Or (month = 11) Then
                    If (1 >= day Or day <= 30) And (day <> 0 And day > 0) Then
                        RichTextBox3.Text = day
                    Else
                        RichTextBox3.Text = "error in  your input @ day -out off my range-"
                        TextBox4.Text = ""
                        MessageBox.Show("error in  your input @day.",
                                   "Help Caption", MessageBoxButtons.OK,
                                   MessageBoxIcon.Error
                                   )
                    End If

                ElseIf month = 2 Then
                    If ((year Mod 2 = 0) And (year Mod 100 <> 0) And (year Mod 4 = 0)) Or ((year Mod 2 = 0) And (year Mod 100 = 0) And (year Mod 4 = 0) And (year Mod 400 = 0)) Then
                        If (1 >= day Or day <= 29) And (day <> 0 And day > 0) Then
                            RichTextBox3.Text = day
                            TextBox4.Text = " Leap Year"
                        Else
                            RichTextBox3.Text = "error in  your input @ day -out off my range-"
                            TextBox4.Text = ""
                            MessageBox.Show("error in  your input @ day.",
                                   "Help Caption", MessageBoxButtons.OK,
                                   MessageBoxIcon.Error
                                   )
                        End If
                    Else
                        If (1 >= day Or day <= 28) And (day <> 0 And day > 0) Then
                            RichTextBox3.Text = day
                        Else
                            RichTextBox3.Text = "error in  your input @ day -out off my range-"
                            TextBox4.Text = ""
                            MessageBox.Show("error in  your input @ day.",
                                   "Help Caption", MessageBoxButtons.OK,
                                   MessageBoxIcon.Error
                                   )
                        End If
                    End If

                End If

            Else
                RichTextBox2.Text = "error in  your input @ month -out off my range-"
                TextBox4.Text = ""
                MessageBox.Show("error in  your input @ Month.",
                                   "Help Caption", MessageBoxButtons.OK,
                                   MessageBoxIcon.Error
                                   )
            End If

            RichTextBox1.Text = "error in  your input @  year -out off my range-"
            TextBox4.Text = ""
            MessageBox.Show("Error in Your input .",
                                   "Help Caption", MessageBoxButtons.OK,
                                   MessageBoxIcon.Error)
        End If












    End Sub

    Private Sub RichTextBox1_TextChanged(sender As Object, e As EventArgs) Handles RichTextBox1.TextChanged

    End Sub

    Private Sub TextBox5_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub RichTextBox2_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub RichTextBox3_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub RichTextBox2_TextChanged_1(sender As Object, e As EventArgs)

    End Sub

    Private Sub RichTextBox3_TextChanged_1(sender As Object, e As EventArgs)

    End Sub

    Private Sub TextBox6_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub TextBox5_TextChanged_1(sender As Object, e As EventArgs)

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click


        year = Convert.ToInt32(TextBox1.Text)
        month = Convert.ToInt32(TextBox2.Text)
        day = Convert.ToInt32(TextBox3.Text)

        If (1000 >= year Or year <= 3000) And (year <> 0 And year > 1000) Then
            RichTextBox1.Text = year
            MessageBox.Show(" Your input is correct @Year .",
                                   "Help Caption", MessageBoxButtons.OK,
                                   MessageBoxIcon.Information)
        Else
            RichTextBox1.Text = "error in  your input @  year -out off my range-"
            MessageBox.Show("Error in Your input @Year .",
                                   "Help Caption", MessageBoxButtons.OK,
                                   MessageBoxIcon.Error)


        End If



        If (1 >= month Or month <= 12) And (month <> 0 And month > 0) Then
            RichTextBox2.Text = month
            MessageBox.Show(" Your input is correct @ Month .",
                             "Help Caption", MessageBoxButtons.OK,
                             MessageBoxIcon.Information)
        Else
            RichTextBox2.Text = "error in  your input @ month -out off my range-"
            MessageBox.Show("Error in Your input @ Month .",
                                   "Help Caption", MessageBoxButtons.OK,
                                   MessageBoxIcon.Error)
        End If






        If month = 1 Then
            If (1 >= day Or day <= 31) And (day <> 0 And day > 0) Then
                RichTextBox3.Text = day
                MessageBox.Show(" Your input is correct @  day .",
                             "Help Caption", MessageBoxButtons.OK,
                             MessageBoxIcon.Information)
            Else
                RichTextBox3.Text = "error in  your input @ day  -out off my range-"
                MessageBox.Show("Error in Your input @ Day.",
                                   "Help Caption", MessageBoxButtons.OK,
                                   MessageBoxIcon.Error)
            End If
        ElseIf month = 3 Then
            If (1 >= day Or day <= 31) And (day <> 0 And day > 0) Then
                RichTextBox3.Text = day
                MessageBox.Show(" Your input is correct @  day .",
                            "Help Caption", MessageBoxButtons.OK,
                            MessageBoxIcon.Information)
            Else
                RichTextBox3.Text = "error in  your input @ day  -out off my range-"
                MessageBox.Show("Error in Your input @ Day.",
                                   "Help Caption", MessageBoxButtons.OK,
                                   MessageBoxIcon.Error)
            End If
        ElseIf month = 4 Then
            If (1 >= day Or day <= 30) And (day <> 0 And day > 0) Then
                RichTextBox3.Text = day
                MessageBox.Show(" Your input is correct @  day .",
                            "Help Caption", MessageBoxButtons.OK,
                            MessageBoxIcon.Information)
            Else
                RichTextBox3.Text = "error in  your input @ day -out off my range-"
                MessageBox.Show("Error in Your input @ Day.",
                                   "Help Caption", MessageBoxButtons.OK,
                                   MessageBoxIcon.Error)
            End If
        ElseIf month = 5 Then
            If (1 >= day Or day <= 31) And (day <> 0 And day > 0) Then
                RichTextBox3.Text = day
                MessageBox.Show(" Your input is correct @  day .",
                            "Help Caption", MessageBoxButtons.OK,
                            MessageBoxIcon.Information)
            Else
                RichTextBox3.Text = "error in  your input @ day -out off my range-"
                MessageBox.Show("Error in Your input @ Day.",
                                   "Help Caption", MessageBoxButtons.OK,
                                   MessageBoxIcon.Error)
            End If
        ElseIf month = 6 Then
            If (1 >= day Or day <= 30) And (day <> 0 And day > 0) Then

                RichTextBox3.Text = day
                MessageBox.Show(" Your input is correct @  day .",
                            "Help Caption", MessageBoxButtons.OK,
                            MessageBoxIcon.Information)
            Else
                RichTextBox3.Text = "error in  your input @ day  -out off my range-"
                MessageBox.Show("Error in Your input @ Day.",
                                   "Help Caption", MessageBoxButtons.OK,
                                   MessageBoxIcon.Error)
            End If
        ElseIf month = 7 Then
            If (1 >= day Or day <= 31) And (day <> 0 And day > 0) Then
                RichTextBox3.Text = day
                MessageBox.Show(" Your input is correct @  day .",
                            "Help Caption", MessageBoxButtons.OK,
                            MessageBoxIcon.Information)
            Else
                RichTextBox3.Text = "error in  your input @ day  -out off my range-"
                MessageBox.Show("Error in Your input @ Day.",
                                   "Help Caption", MessageBoxButtons.OK,
                                   MessageBoxIcon.Error)
            End If
        ElseIf month = 8 Then
            If (1 >= day Or day <= 31) And (day <> 0 And day > 0) Then
                RichTextBox3.Text = day
                MessageBox.Show(" Your input is correct @  day .",
                            "Help Caption", MessageBoxButtons.OK,
                            MessageBoxIcon.Information)
            Else
                RichTextBox3.Text = "error in  your input @ day  -out off my range-"
                MessageBox.Show("Error in Your input @ Day.",
                                   "Help Caption", MessageBoxButtons.OK,
                                   MessageBoxIcon.Error)
            End If
        ElseIf month = 9 Then
            If (1 >= day Or day <= 30) And (day <> 0 And day > 0) Then
                RichTextBox3.Text = day
                MessageBox.Show(" Your input is correct @  day .",
                            "Help Caption", MessageBoxButtons.OK,
                            MessageBoxIcon.Information)
            Else
                RichTextBox3.Text = "error in  your input @ day  -out off my range-"
                MessageBox.Show("Error in Your input @ Day.",
                                   "Help Caption", MessageBoxButtons.OK,
                                   MessageBoxIcon.Error)
            End If
        ElseIf month = 10 Then
            If (1 >= day Or day <= 31) And (day <> 0 And day > 0) Then
                RichTextBox3.Text = day
                MessageBox.Show(" Your input is correct @  day .",
                            "Help Caption", MessageBoxButtons.OK,
                            MessageBoxIcon.Information)
            Else
                RichTextBox3.Text = "error in  your input @ day  -out off my range-"
                MessageBox.Show("Error in Your input @ Day.",
                                   "Help Caption", MessageBoxButtons.OK,
                                   MessageBoxIcon.Error)
            End If
        ElseIf month = 11 Then
            If (1 >= day Or day <= 30) And (day <> 0 And day > 0) Then
                RichTextBox3.Text = day
                MessageBox.Show(" Your input is correct @  day .",
                            "Help Caption", MessageBoxButtons.OK,
                            MessageBoxIcon.Information)
            Else
                RichTextBox3.Text = "error in  your input @ day  -out off my range-"
                MessageBox.Show("Error in Your input @ Day.",
                                   "Help Caption", MessageBoxButtons.OK,
                                   MessageBoxIcon.Error)
            End If
        ElseIf month = 12 Then
            If (1 >= day Or day <= 31) And (day <> 0 And day > 0) Then
                RichTextBox3.Text = day
                MessageBox.Show(" Your input is correct @  day .",
                            "Help Caption", MessageBoxButtons.OK,
                            MessageBoxIcon.Information)
            Else
                RichTextBox3.Text = "error in  your input @ day  -out off my range-"
                MessageBox.Show("Error in Your input @ Day.",
                                   "Help Caption", MessageBoxButtons.OK,
                                   MessageBoxIcon.Error)
            End If
        ElseIf month = 2 Then
            If ((year Mod 2 = 0) And (year Mod 100 <> 0) And (year Mod 4 = 0)) Or ((year Mod 2 = 0) And (year Mod 100 = 0) And (year Mod 4 = 0) And (year Mod 400 = 0)) Then
                If (1 >= day Or day <= 29) And (day <> 0 And day > 0) Then
                    RichTextBox3.Text = day
                    TextBox4.Text = " Leap Year"
                    MessageBox.Show(" Your input is correct @  day .",
                             "Help Caption", MessageBoxButtons.OK,
                             MessageBoxIcon.Information)

                Else
                    RichTextBox3.Text = "error in  your input @ day -out off my range-"
                    MessageBox.Show("Error in Your input @ Day.",
                                   "Help Caption", MessageBoxButtons.OK,
                                   MessageBoxIcon.Error)
                End If
            Else
                If (1 >= day Or day <= 28) And (day <> 0 And day > 0) Then
                    RichTextBox3.Text = day
                    MessageBox.Show(" Your input is correct @  day .",
                            "Help Caption", MessageBoxButtons.OK,
                            MessageBoxIcon.Information)
                Else
                    RichTextBox3.Text = "error in  your input @ day -out off my range-"

                    MessageBox.Show("Error in Your input @ Day.",
                                 "Help Caption", MessageBoxButtons.OK,
                                 MessageBoxIcon.Error)
                End If

            End If
        ElseIf month > 13 Or month = 0 Or month < 1 Then

            If ((1 >= day Or day <= 31) Or (1 >= day Or day <= 30)) And (day <> 0 And day > 0) Then
                RichTextBox3.Text = day
                MessageBox.Show(" Your input is correct @  day .",
                        "Help Caption", MessageBoxButtons.OK,
                        MessageBoxIcon.Information)

            Else
                RichTextBox3.Text = "error in  your input @ day -out off my range-"
                MessageBox.Show("Error in Your input @ Day.",
                               "Help Caption", MessageBoxButtons.OK,
                               MessageBoxIcon.Error)

            End If
        ElseIf month > 13 Or month = 0 Or month < 1 Then

            If (day >= 31) Or (day >= 30) And (day = 0 Or day < 1) Then

                RichTextBox3.Text = "error in  your input @ day -out off my range-"
                MessageBox.Show("Error in Your input @ Day.",
                           "Help Caption", MessageBoxButtons.OK,
                           MessageBoxIcon.Error)
            Else
                RichTextBox3.Text = "error in  your input @ day -out off my range-"
                MessageBox.Show("Error in Your input @ Day.",
                               "Help Caption", MessageBoxButtons.OK,
                             MessageBoxIcon.Error)

            End If
        End If
    End Sub


    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs) Handles TextBox3.TextChanged

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

        year = 0
        month = 0
        day = 0
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        RichTextBox3.Text = ""
        RichTextBox2.Text = ""
        RichTextBox1.Text = ""
    End Sub
End Class
