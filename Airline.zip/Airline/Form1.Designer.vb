﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.TextBox127 = New System.Windows.Forms.TextBox()
        Me.TextBox128 = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.TextBox120 = New System.Windows.Forms.TextBox()
        Me.TextBox110 = New System.Windows.Forms.TextBox()
        Me.TextBox100 = New System.Windows.Forms.TextBox()
        Me.TextBox90 = New System.Windows.Forms.TextBox()
        Me.TextBox80 = New System.Windows.Forms.TextBox()
        Me.TextBox70 = New System.Windows.Forms.TextBox()
        Me.TextBox60 = New System.Windows.Forms.TextBox()
        Me.TextBox50 = New System.Windows.Forms.TextBox()
        Me.TextBox40 = New System.Windows.Forms.TextBox()
        Me.TextBox30 = New System.Windows.Forms.TextBox()
        Me.TextBox119 = New System.Windows.Forms.TextBox()
        Me.TextBox109 = New System.Windows.Forms.TextBox()
        Me.TextBox99 = New System.Windows.Forms.TextBox()
        Me.TextBox89 = New System.Windows.Forms.TextBox()
        Me.TextBox79 = New System.Windows.Forms.TextBox()
        Me.TextBox69 = New System.Windows.Forms.TextBox()
        Me.TextBox59 = New System.Windows.Forms.TextBox()
        Me.TextBox49 = New System.Windows.Forms.TextBox()
        Me.TextBox39 = New System.Windows.Forms.TextBox()
        Me.TextBox29 = New System.Windows.Forms.TextBox()
        Me.TextBox118 = New System.Windows.Forms.TextBox()
        Me.TextBox108 = New System.Windows.Forms.TextBox()
        Me.TextBox98 = New System.Windows.Forms.TextBox()
        Me.TextBox88 = New System.Windows.Forms.TextBox()
        Me.TextBox78 = New System.Windows.Forms.TextBox()
        Me.TextBox68 = New System.Windows.Forms.TextBox()
        Me.TextBox58 = New System.Windows.Forms.TextBox()
        Me.TextBox48 = New System.Windows.Forms.TextBox()
        Me.TextBox38 = New System.Windows.Forms.TextBox()
        Me.TextBox28 = New System.Windows.Forms.TextBox()
        Me.TextBox117 = New System.Windows.Forms.TextBox()
        Me.TextBox107 = New System.Windows.Forms.TextBox()
        Me.TextBox97 = New System.Windows.Forms.TextBox()
        Me.TextBox87 = New System.Windows.Forms.TextBox()
        Me.TextBox77 = New System.Windows.Forms.TextBox()
        Me.TextBox67 = New System.Windows.Forms.TextBox()
        Me.TextBox57 = New System.Windows.Forms.TextBox()
        Me.TextBox47 = New System.Windows.Forms.TextBox()
        Me.TextBox37 = New System.Windows.Forms.TextBox()
        Me.TextBox27 = New System.Windows.Forms.TextBox()
        Me.TextBox116 = New System.Windows.Forms.TextBox()
        Me.TextBox106 = New System.Windows.Forms.TextBox()
        Me.TextBox96 = New System.Windows.Forms.TextBox()
        Me.TextBox86 = New System.Windows.Forms.TextBox()
        Me.TextBox76 = New System.Windows.Forms.TextBox()
        Me.TextBox66 = New System.Windows.Forms.TextBox()
        Me.TextBox56 = New System.Windows.Forms.TextBox()
        Me.TextBox46 = New System.Windows.Forms.TextBox()
        Me.TextBox36 = New System.Windows.Forms.TextBox()
        Me.TextBox26 = New System.Windows.Forms.TextBox()
        Me.PictureBox29 = New System.Windows.Forms.PictureBox()
        Me.PictureBox116 = New System.Windows.Forms.PictureBox()
        Me.PictureBox106 = New System.Windows.Forms.PictureBox()
        Me.PictureBox96 = New System.Windows.Forms.PictureBox()
        Me.PictureBox86 = New System.Windows.Forms.PictureBox()
        Me.PictureBox76 = New System.Windows.Forms.PictureBox()
        Me.PictureBox66 = New System.Windows.Forms.PictureBox()
        Me.PictureBox56 = New System.Windows.Forms.PictureBox()
        Me.PictureBox46 = New System.Windows.Forms.PictureBox()
        Me.PictureBox36 = New System.Windows.Forms.PictureBox()
        Me.PictureBox26 = New System.Windows.Forms.PictureBox()
        Me.PictureBox115 = New System.Windows.Forms.PictureBox()
        Me.PictureBox105 = New System.Windows.Forms.PictureBox()
        Me.PictureBox95 = New System.Windows.Forms.PictureBox()
        Me.PictureBox85 = New System.Windows.Forms.PictureBox()
        Me.PictureBox75 = New System.Windows.Forms.PictureBox()
        Me.PictureBox65 = New System.Windows.Forms.PictureBox()
        Me.PictureBox55 = New System.Windows.Forms.PictureBox()
        Me.PictureBox45 = New System.Windows.Forms.PictureBox()
        Me.PictureBox35 = New System.Windows.Forms.PictureBox()
        Me.PictureBox25 = New System.Windows.Forms.PictureBox()
        Me.PictureBox114 = New System.Windows.Forms.PictureBox()
        Me.PictureBox104 = New System.Windows.Forms.PictureBox()
        Me.PictureBox94 = New System.Windows.Forms.PictureBox()
        Me.PictureBox84 = New System.Windows.Forms.PictureBox()
        Me.PictureBox74 = New System.Windows.Forms.PictureBox()
        Me.PictureBox64 = New System.Windows.Forms.PictureBox()
        Me.PictureBox54 = New System.Windows.Forms.PictureBox()
        Me.PictureBox44 = New System.Windows.Forms.PictureBox()
        Me.PictureBox34 = New System.Windows.Forms.PictureBox()
        Me.PictureBox24 = New System.Windows.Forms.PictureBox()
        Me.PictureBox113 = New System.Windows.Forms.PictureBox()
        Me.PictureBox103 = New System.Windows.Forms.PictureBox()
        Me.PictureBox93 = New System.Windows.Forms.PictureBox()
        Me.PictureBox83 = New System.Windows.Forms.PictureBox()
        Me.PictureBox73 = New System.Windows.Forms.PictureBox()
        Me.PictureBox63 = New System.Windows.Forms.PictureBox()
        Me.PictureBox53 = New System.Windows.Forms.PictureBox()
        Me.PictureBox43 = New System.Windows.Forms.PictureBox()
        Me.PictureBox33 = New System.Windows.Forms.PictureBox()
        Me.PictureBox22 = New System.Windows.Forms.PictureBox()
        Me.PictureBox112 = New System.Windows.Forms.PictureBox()
        Me.PictureBox102 = New System.Windows.Forms.PictureBox()
        Me.PictureBox92 = New System.Windows.Forms.PictureBox()
        Me.PictureBox82 = New System.Windows.Forms.PictureBox()
        Me.PictureBox72 = New System.Windows.Forms.PictureBox()
        Me.PictureBox62 = New System.Windows.Forms.PictureBox()
        Me.PictureBox52 = New System.Windows.Forms.PictureBox()
        Me.PictureBox42 = New System.Windows.Forms.PictureBox()
        Me.PictureBox32 = New System.Windows.Forms.PictureBox()
        Me.PictureBox23 = New System.Windows.Forms.PictureBox()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.TextBox25 = New System.Windows.Forms.TextBox()
        Me.TextBox24 = New System.Windows.Forms.TextBox()
        Me.TextBox23 = New System.Windows.Forms.TextBox()
        Me.TextBox22 = New System.Windows.Forms.TextBox()
        Me.TextBox21 = New System.Windows.Forms.TextBox()
        Me.TextBox20 = New System.Windows.Forms.TextBox()
        Me.TextBox19 = New System.Windows.Forms.TextBox()
        Me.TextBox18 = New System.Windows.Forms.TextBox()
        Me.TextBox17 = New System.Windows.Forms.TextBox()
        Me.TextBox16 = New System.Windows.Forms.TextBox()
        Me.TextBox15 = New System.Windows.Forms.TextBox()
        Me.TextBox14 = New System.Windows.Forms.TextBox()
        Me.TextBox13 = New System.Windows.Forms.TextBox()
        Me.TextBox12 = New System.Windows.Forms.TextBox()
        Me.TextBox11 = New System.Windows.Forms.TextBox()
        Me.TextBox10 = New System.Windows.Forms.TextBox()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.PictureBox20 = New System.Windows.Forms.PictureBox()
        Me.PictureBox19 = New System.Windows.Forms.PictureBox()
        Me.PictureBox18 = New System.Windows.Forms.PictureBox()
        Me.PictureBox17 = New System.Windows.Forms.PictureBox()
        Me.PictureBox16 = New System.Windows.Forms.PictureBox()
        Me.PictureBox15 = New System.Windows.Forms.PictureBox()
        Me.PictureBox14 = New System.Windows.Forms.PictureBox()
        Me.PictureBox13 = New System.Windows.Forms.PictureBox()
        Me.PictureBox12 = New System.Windows.Forms.PictureBox()
        Me.PictureBox11 = New System.Windows.Forms.PictureBox()
        Me.PictureBox10 = New System.Windows.Forms.PictureBox()
        Me.PictureBox9 = New System.Windows.Forms.PictureBox()
        Me.PictureBox8 = New System.Windows.Forms.PictureBox()
        Me.PictureBox7 = New System.Windows.Forms.PictureBox()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Eco = New System.Windows.Forms.TabControl()
        Me.TabPage2.SuspendLayout()
        CType(Me.PictureBox29, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox116, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox106, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox96, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox86, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox76, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox66, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox56, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox46, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox36, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox26, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox115, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox105, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox95, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox85, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox75, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox65, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox55, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox45, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox35, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox25, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox114, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox104, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox94, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox84, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox74, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox64, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox54, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox44, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox34, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox24, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox113, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox103, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox93, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox83, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox73, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox63, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox53, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox43, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox33, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox22, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox112, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox102, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox92, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox82, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox72, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox62, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox52, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox42, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox32, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox23, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage1.SuspendLayout()
        CType(Me.PictureBox20, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox19, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox18, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox17, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox16, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox15, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox13, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Eco.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.Silver
        Me.TabPage2.Controls.Add(Me.Label17)
        Me.TabPage2.Controls.Add(Me.Button5)
        Me.TabPage2.Controls.Add(Me.Button6)
        Me.TabPage2.Controls.Add(Me.TextBox127)
        Me.TabPage2.Controls.Add(Me.TextBox128)
        Me.TabPage2.Controls.Add(Me.Label14)
        Me.TabPage2.Controls.Add(Me.Label13)
        Me.TabPage2.Controls.Add(Me.Label12)
        Me.TabPage2.Controls.Add(Me.Label9)
        Me.TabPage2.Controls.Add(Me.TextBox120)
        Me.TabPage2.Controls.Add(Me.TextBox110)
        Me.TabPage2.Controls.Add(Me.TextBox100)
        Me.TabPage2.Controls.Add(Me.TextBox90)
        Me.TabPage2.Controls.Add(Me.TextBox80)
        Me.TabPage2.Controls.Add(Me.TextBox70)
        Me.TabPage2.Controls.Add(Me.TextBox60)
        Me.TabPage2.Controls.Add(Me.TextBox50)
        Me.TabPage2.Controls.Add(Me.TextBox40)
        Me.TabPage2.Controls.Add(Me.TextBox30)
        Me.TabPage2.Controls.Add(Me.TextBox119)
        Me.TabPage2.Controls.Add(Me.TextBox109)
        Me.TabPage2.Controls.Add(Me.TextBox99)
        Me.TabPage2.Controls.Add(Me.TextBox89)
        Me.TabPage2.Controls.Add(Me.TextBox79)
        Me.TabPage2.Controls.Add(Me.TextBox69)
        Me.TabPage2.Controls.Add(Me.TextBox59)
        Me.TabPage2.Controls.Add(Me.TextBox49)
        Me.TabPage2.Controls.Add(Me.TextBox39)
        Me.TabPage2.Controls.Add(Me.TextBox29)
        Me.TabPage2.Controls.Add(Me.TextBox118)
        Me.TabPage2.Controls.Add(Me.TextBox108)
        Me.TabPage2.Controls.Add(Me.TextBox98)
        Me.TabPage2.Controls.Add(Me.TextBox88)
        Me.TabPage2.Controls.Add(Me.TextBox78)
        Me.TabPage2.Controls.Add(Me.TextBox68)
        Me.TabPage2.Controls.Add(Me.TextBox58)
        Me.TabPage2.Controls.Add(Me.TextBox48)
        Me.TabPage2.Controls.Add(Me.TextBox38)
        Me.TabPage2.Controls.Add(Me.TextBox28)
        Me.TabPage2.Controls.Add(Me.TextBox117)
        Me.TabPage2.Controls.Add(Me.TextBox107)
        Me.TabPage2.Controls.Add(Me.TextBox97)
        Me.TabPage2.Controls.Add(Me.TextBox87)
        Me.TabPage2.Controls.Add(Me.TextBox77)
        Me.TabPage2.Controls.Add(Me.TextBox67)
        Me.TabPage2.Controls.Add(Me.TextBox57)
        Me.TabPage2.Controls.Add(Me.TextBox47)
        Me.TabPage2.Controls.Add(Me.TextBox37)
        Me.TabPage2.Controls.Add(Me.TextBox27)
        Me.TabPage2.Controls.Add(Me.TextBox116)
        Me.TabPage2.Controls.Add(Me.TextBox106)
        Me.TabPage2.Controls.Add(Me.TextBox96)
        Me.TabPage2.Controls.Add(Me.TextBox86)
        Me.TabPage2.Controls.Add(Me.TextBox76)
        Me.TabPage2.Controls.Add(Me.TextBox66)
        Me.TabPage2.Controls.Add(Me.TextBox56)
        Me.TabPage2.Controls.Add(Me.TextBox46)
        Me.TabPage2.Controls.Add(Me.TextBox36)
        Me.TabPage2.Controls.Add(Me.TextBox26)
        Me.TabPage2.Controls.Add(Me.PictureBox29)
        Me.TabPage2.Controls.Add(Me.PictureBox116)
        Me.TabPage2.Controls.Add(Me.PictureBox106)
        Me.TabPage2.Controls.Add(Me.PictureBox96)
        Me.TabPage2.Controls.Add(Me.PictureBox86)
        Me.TabPage2.Controls.Add(Me.PictureBox76)
        Me.TabPage2.Controls.Add(Me.PictureBox66)
        Me.TabPage2.Controls.Add(Me.PictureBox56)
        Me.TabPage2.Controls.Add(Me.PictureBox46)
        Me.TabPage2.Controls.Add(Me.PictureBox36)
        Me.TabPage2.Controls.Add(Me.PictureBox26)
        Me.TabPage2.Controls.Add(Me.PictureBox115)
        Me.TabPage2.Controls.Add(Me.PictureBox105)
        Me.TabPage2.Controls.Add(Me.PictureBox95)
        Me.TabPage2.Controls.Add(Me.PictureBox85)
        Me.TabPage2.Controls.Add(Me.PictureBox75)
        Me.TabPage2.Controls.Add(Me.PictureBox65)
        Me.TabPage2.Controls.Add(Me.PictureBox55)
        Me.TabPage2.Controls.Add(Me.PictureBox45)
        Me.TabPage2.Controls.Add(Me.PictureBox35)
        Me.TabPage2.Controls.Add(Me.PictureBox25)
        Me.TabPage2.Controls.Add(Me.PictureBox114)
        Me.TabPage2.Controls.Add(Me.PictureBox104)
        Me.TabPage2.Controls.Add(Me.PictureBox94)
        Me.TabPage2.Controls.Add(Me.PictureBox84)
        Me.TabPage2.Controls.Add(Me.PictureBox74)
        Me.TabPage2.Controls.Add(Me.PictureBox64)
        Me.TabPage2.Controls.Add(Me.PictureBox54)
        Me.TabPage2.Controls.Add(Me.PictureBox44)
        Me.TabPage2.Controls.Add(Me.PictureBox34)
        Me.TabPage2.Controls.Add(Me.PictureBox24)
        Me.TabPage2.Controls.Add(Me.PictureBox113)
        Me.TabPage2.Controls.Add(Me.PictureBox103)
        Me.TabPage2.Controls.Add(Me.PictureBox93)
        Me.TabPage2.Controls.Add(Me.PictureBox83)
        Me.TabPage2.Controls.Add(Me.PictureBox73)
        Me.TabPage2.Controls.Add(Me.PictureBox63)
        Me.TabPage2.Controls.Add(Me.PictureBox53)
        Me.TabPage2.Controls.Add(Me.PictureBox43)
        Me.TabPage2.Controls.Add(Me.PictureBox33)
        Me.TabPage2.Controls.Add(Me.PictureBox22)
        Me.TabPage2.Controls.Add(Me.PictureBox112)
        Me.TabPage2.Controls.Add(Me.PictureBox102)
        Me.TabPage2.Controls.Add(Me.PictureBox92)
        Me.TabPage2.Controls.Add(Me.PictureBox82)
        Me.TabPage2.Controls.Add(Me.PictureBox72)
        Me.TabPage2.Controls.Add(Me.PictureBox62)
        Me.TabPage2.Controls.Add(Me.PictureBox52)
        Me.TabPage2.Controls.Add(Me.PictureBox42)
        Me.TabPage2.Controls.Add(Me.PictureBox32)
        Me.TabPage2.Controls.Add(Me.PictureBox23)
        Me.TabPage2.Location = New System.Drawing.Point(4, 29)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(1341, 998)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Eco"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Segoe UI", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label17.Location = New System.Drawing.Point(1155, 291)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(79, 25)
        Me.Label17.TabIndex = 67
        Me.Label17.Text = "seat no."
        '
        'Button5
        '
        Me.Button5.Font = New System.Drawing.Font("Segoe UI", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Button5.Location = New System.Drawing.Point(1030, 358)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(117, 36)
        Me.Button5.TabIndex = 66
        Me.Button5.Text = "delet"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button6
        '
        Me.Button6.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Button6.Location = New System.Drawing.Point(1179, 355)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(141, 36)
        Me.Button6.TabIndex = 65
        Me.Button6.Text = "OK"
        Me.Button6.UseVisualStyleBackColor = True
        '
        'TextBox127
        '
        Me.TextBox127.Location = New System.Drawing.Point(1248, 289)
        Me.TextBox127.Name = "TextBox127"
        Me.TextBox127.Size = New System.Drawing.Size(70, 27)
        Me.TextBox127.TabIndex = 63
        '
        'TextBox128
        '
        Me.TextBox128.AccessibleName = ""
        Me.TextBox128.BackColor = System.Drawing.SystemColors.HighlightText
        Me.TextBox128.Location = New System.Drawing.Point(1072, 256)
        Me.TextBox128.Name = "TextBox128"
        Me.TextBox128.Size = New System.Drawing.Size(248, 27)
        Me.TextBox128.TabIndex = 61
        '
        'Label14
        '
        Me.Label14.BackColor = System.Drawing.Color.Snow
        Me.Label14.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label14.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Label14.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label14.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Label14.Location = New System.Drawing.Point(1072, 206)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(248, 33)
        Me.Label14.TabIndex = 23
        Me.Label14.Text = "Input your First  and Last name"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.BackColor = System.Drawing.Color.Silver
        Me.Label13.Font = New System.Drawing.Font("Segoe UI", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label13.Location = New System.Drawing.Point(1003, 137)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(315, 25)
        Me.Label13.TabIndex = 16
        Me.Label13.Text = " and cancelation of the reservation."
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.BackColor = System.Drawing.Color.Silver
        Me.Label12.Font = New System.Drawing.Font("Segoe UI", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label12.Location = New System.Drawing.Point(893, 102)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(299, 25)
        Me.Label12.TabIndex = 15
        Me.Label12.Text = "An application for reserving seats"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.BackColor = System.Drawing.Color.LightCoral
        Me.Label9.Font = New System.Drawing.Font("Wide Latin", 13.8!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point)
        Me.Label9.Location = New System.Drawing.Point(968, 42)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(308, 28)
        Me.Label9.TabIndex = 14
        Me.Label9.Text = "ACME airlines "
        '
        'TextBox120
        '
        Me.TextBox120.BackColor = System.Drawing.Color.Silver
        Me.TextBox120.Location = New System.Drawing.Point(787, 403)
        Me.TextBox120.Name = "TextBox120"
        Me.TextBox120.Size = New System.Drawing.Size(70, 27)
        Me.TextBox120.TabIndex = 8
        '
        'TextBox110
        '
        Me.TextBox110.BackColor = System.Drawing.Color.Silver
        Me.TextBox110.Location = New System.Drawing.Point(699, 403)
        Me.TextBox110.Name = "TextBox110"
        Me.TextBox110.Size = New System.Drawing.Size(70, 27)
        Me.TextBox110.TabIndex = 8
        '
        'TextBox100
        '
        Me.TextBox100.BackColor = System.Drawing.Color.Silver
        Me.TextBox100.Location = New System.Drawing.Point(598, 403)
        Me.TextBox100.Name = "TextBox100"
        Me.TextBox100.Size = New System.Drawing.Size(70, 27)
        Me.TextBox100.TabIndex = 8
        '
        'TextBox90
        '
        Me.TextBox90.BackColor = System.Drawing.Color.Silver
        Me.TextBox90.Location = New System.Drawing.Point(522, 403)
        Me.TextBox90.Name = "TextBox90"
        Me.TextBox90.Size = New System.Drawing.Size(70, 27)
        Me.TextBox90.TabIndex = 8
        '
        'TextBox80
        '
        Me.TextBox80.BackColor = System.Drawing.Color.Silver
        Me.TextBox80.Location = New System.Drawing.Point(437, 403)
        Me.TextBox80.Name = "TextBox80"
        Me.TextBox80.Size = New System.Drawing.Size(70, 27)
        Me.TextBox80.TabIndex = 8
        '
        'TextBox70
        '
        Me.TextBox70.BackColor = System.Drawing.Color.Silver
        Me.TextBox70.Location = New System.Drawing.Point(361, 403)
        Me.TextBox70.Name = "TextBox70"
        Me.TextBox70.Size = New System.Drawing.Size(70, 27)
        Me.TextBox70.TabIndex = 8
        '
        'TextBox60
        '
        Me.TextBox60.BackColor = System.Drawing.Color.Silver
        Me.TextBox60.Location = New System.Drawing.Point(271, 403)
        Me.TextBox60.Name = "TextBox60"
        Me.TextBox60.Size = New System.Drawing.Size(70, 27)
        Me.TextBox60.TabIndex = 8
        '
        'TextBox50
        '
        Me.TextBox50.BackColor = System.Drawing.Color.Silver
        Me.TextBox50.Location = New System.Drawing.Point(184, 403)
        Me.TextBox50.Name = "TextBox50"
        Me.TextBox50.Size = New System.Drawing.Size(70, 27)
        Me.TextBox50.TabIndex = 8
        '
        'TextBox40
        '
        Me.TextBox40.BackColor = System.Drawing.Color.Silver
        Me.TextBox40.Location = New System.Drawing.Point(108, 403)
        Me.TextBox40.Name = "TextBox40"
        Me.TextBox40.Size = New System.Drawing.Size(70, 27)
        Me.TextBox40.TabIndex = 8
        '
        'TextBox30
        '
        Me.TextBox30.BackColor = System.Drawing.Color.Silver
        Me.TextBox30.Location = New System.Drawing.Point(32, 403)
        Me.TextBox30.Name = "TextBox30"
        Me.TextBox30.Size = New System.Drawing.Size(70, 27)
        Me.TextBox30.TabIndex = 8
        '
        'TextBox119
        '
        Me.TextBox119.BackColor = System.Drawing.Color.Silver
        Me.TextBox119.Location = New System.Drawing.Point(787, 310)
        Me.TextBox119.Name = "TextBox119"
        Me.TextBox119.Size = New System.Drawing.Size(70, 27)
        Me.TextBox119.TabIndex = 7
        '
        'TextBox109
        '
        Me.TextBox109.BackColor = System.Drawing.Color.Silver
        Me.TextBox109.Location = New System.Drawing.Point(699, 310)
        Me.TextBox109.Name = "TextBox109"
        Me.TextBox109.Size = New System.Drawing.Size(70, 27)
        Me.TextBox109.TabIndex = 7
        '
        'TextBox99
        '
        Me.TextBox99.BackColor = System.Drawing.Color.Silver
        Me.TextBox99.Location = New System.Drawing.Point(598, 310)
        Me.TextBox99.Name = "TextBox99"
        Me.TextBox99.Size = New System.Drawing.Size(70, 27)
        Me.TextBox99.TabIndex = 7
        '
        'TextBox89
        '
        Me.TextBox89.BackColor = System.Drawing.Color.Silver
        Me.TextBox89.Location = New System.Drawing.Point(522, 310)
        Me.TextBox89.Name = "TextBox89"
        Me.TextBox89.Size = New System.Drawing.Size(70, 27)
        Me.TextBox89.TabIndex = 7
        '
        'TextBox79
        '
        Me.TextBox79.BackColor = System.Drawing.Color.Silver
        Me.TextBox79.Location = New System.Drawing.Point(437, 310)
        Me.TextBox79.Name = "TextBox79"
        Me.TextBox79.Size = New System.Drawing.Size(70, 27)
        Me.TextBox79.TabIndex = 7
        '
        'TextBox69
        '
        Me.TextBox69.BackColor = System.Drawing.Color.Silver
        Me.TextBox69.Location = New System.Drawing.Point(361, 310)
        Me.TextBox69.Name = "TextBox69"
        Me.TextBox69.Size = New System.Drawing.Size(70, 27)
        Me.TextBox69.TabIndex = 7
        '
        'TextBox59
        '
        Me.TextBox59.BackColor = System.Drawing.Color.Silver
        Me.TextBox59.Location = New System.Drawing.Point(271, 310)
        Me.TextBox59.Name = "TextBox59"
        Me.TextBox59.Size = New System.Drawing.Size(70, 27)
        Me.TextBox59.TabIndex = 7
        '
        'TextBox49
        '
        Me.TextBox49.BackColor = System.Drawing.Color.Silver
        Me.TextBox49.Location = New System.Drawing.Point(184, 310)
        Me.TextBox49.Name = "TextBox49"
        Me.TextBox49.Size = New System.Drawing.Size(70, 27)
        Me.TextBox49.TabIndex = 7
        '
        'TextBox39
        '
        Me.TextBox39.BackColor = System.Drawing.Color.Silver
        Me.TextBox39.Location = New System.Drawing.Point(108, 310)
        Me.TextBox39.Name = "TextBox39"
        Me.TextBox39.Size = New System.Drawing.Size(70, 27)
        Me.TextBox39.TabIndex = 7
        '
        'TextBox29
        '
        Me.TextBox29.BackColor = System.Drawing.Color.Silver
        Me.TextBox29.Location = New System.Drawing.Point(32, 310)
        Me.TextBox29.Name = "TextBox29"
        Me.TextBox29.Size = New System.Drawing.Size(70, 27)
        Me.TextBox29.TabIndex = 7
        '
        'TextBox118
        '
        Me.TextBox118.BackColor = System.Drawing.Color.Silver
        Me.TextBox118.Location = New System.Drawing.Point(787, 232)
        Me.TextBox118.Name = "TextBox118"
        Me.TextBox118.Size = New System.Drawing.Size(70, 27)
        Me.TextBox118.TabIndex = 6
        '
        'TextBox108
        '
        Me.TextBox108.BackColor = System.Drawing.Color.Silver
        Me.TextBox108.Location = New System.Drawing.Point(699, 232)
        Me.TextBox108.Name = "TextBox108"
        Me.TextBox108.Size = New System.Drawing.Size(70, 27)
        Me.TextBox108.TabIndex = 6
        '
        'TextBox98
        '
        Me.TextBox98.BackColor = System.Drawing.Color.Silver
        Me.TextBox98.Location = New System.Drawing.Point(598, 232)
        Me.TextBox98.Name = "TextBox98"
        Me.TextBox98.Size = New System.Drawing.Size(70, 27)
        Me.TextBox98.TabIndex = 6
        '
        'TextBox88
        '
        Me.TextBox88.BackColor = System.Drawing.Color.Silver
        Me.TextBox88.Location = New System.Drawing.Point(522, 232)
        Me.TextBox88.Name = "TextBox88"
        Me.TextBox88.Size = New System.Drawing.Size(70, 27)
        Me.TextBox88.TabIndex = 6
        '
        'TextBox78
        '
        Me.TextBox78.BackColor = System.Drawing.Color.Silver
        Me.TextBox78.Location = New System.Drawing.Point(437, 232)
        Me.TextBox78.Name = "TextBox78"
        Me.TextBox78.Size = New System.Drawing.Size(70, 27)
        Me.TextBox78.TabIndex = 6
        '
        'TextBox68
        '
        Me.TextBox68.BackColor = System.Drawing.Color.Silver
        Me.TextBox68.Location = New System.Drawing.Point(361, 232)
        Me.TextBox68.Name = "TextBox68"
        Me.TextBox68.Size = New System.Drawing.Size(70, 27)
        Me.TextBox68.TabIndex = 6
        '
        'TextBox58
        '
        Me.TextBox58.BackColor = System.Drawing.Color.Silver
        Me.TextBox58.Location = New System.Drawing.Point(271, 232)
        Me.TextBox58.Name = "TextBox58"
        Me.TextBox58.Size = New System.Drawing.Size(70, 27)
        Me.TextBox58.TabIndex = 6
        '
        'TextBox48
        '
        Me.TextBox48.BackColor = System.Drawing.Color.Silver
        Me.TextBox48.Location = New System.Drawing.Point(184, 232)
        Me.TextBox48.Name = "TextBox48"
        Me.TextBox48.Size = New System.Drawing.Size(70, 27)
        Me.TextBox48.TabIndex = 6
        '
        'TextBox38
        '
        Me.TextBox38.BackColor = System.Drawing.Color.Silver
        Me.TextBox38.Location = New System.Drawing.Point(108, 232)
        Me.TextBox38.Name = "TextBox38"
        Me.TextBox38.Size = New System.Drawing.Size(70, 27)
        Me.TextBox38.TabIndex = 6
        '
        'TextBox28
        '
        Me.TextBox28.BackColor = System.Drawing.Color.Silver
        Me.TextBox28.Location = New System.Drawing.Point(32, 232)
        Me.TextBox28.Name = "TextBox28"
        Me.TextBox28.Size = New System.Drawing.Size(70, 27)
        Me.TextBox28.TabIndex = 6
        '
        'TextBox117
        '
        Me.TextBox117.BackColor = System.Drawing.Color.Silver
        Me.TextBox117.Location = New System.Drawing.Point(787, 154)
        Me.TextBox117.Name = "TextBox117"
        Me.TextBox117.Size = New System.Drawing.Size(70, 27)
        Me.TextBox117.TabIndex = 5
        '
        'TextBox107
        '
        Me.TextBox107.BackColor = System.Drawing.Color.Silver
        Me.TextBox107.Location = New System.Drawing.Point(699, 154)
        Me.TextBox107.Name = "TextBox107"
        Me.TextBox107.Size = New System.Drawing.Size(70, 27)
        Me.TextBox107.TabIndex = 5
        '
        'TextBox97
        '
        Me.TextBox97.BackColor = System.Drawing.Color.Silver
        Me.TextBox97.Location = New System.Drawing.Point(598, 154)
        Me.TextBox97.Name = "TextBox97"
        Me.TextBox97.Size = New System.Drawing.Size(70, 27)
        Me.TextBox97.TabIndex = 5
        '
        'TextBox87
        '
        Me.TextBox87.BackColor = System.Drawing.Color.Silver
        Me.TextBox87.Location = New System.Drawing.Point(522, 154)
        Me.TextBox87.Name = "TextBox87"
        Me.TextBox87.Size = New System.Drawing.Size(70, 27)
        Me.TextBox87.TabIndex = 5
        '
        'TextBox77
        '
        Me.TextBox77.BackColor = System.Drawing.Color.Silver
        Me.TextBox77.Location = New System.Drawing.Point(437, 154)
        Me.TextBox77.Name = "TextBox77"
        Me.TextBox77.Size = New System.Drawing.Size(70, 27)
        Me.TextBox77.TabIndex = 5
        '
        'TextBox67
        '
        Me.TextBox67.BackColor = System.Drawing.Color.Silver
        Me.TextBox67.Location = New System.Drawing.Point(361, 154)
        Me.TextBox67.Name = "TextBox67"
        Me.TextBox67.Size = New System.Drawing.Size(70, 27)
        Me.TextBox67.TabIndex = 5
        '
        'TextBox57
        '
        Me.TextBox57.BackColor = System.Drawing.Color.Silver
        Me.TextBox57.Location = New System.Drawing.Point(271, 154)
        Me.TextBox57.Name = "TextBox57"
        Me.TextBox57.Size = New System.Drawing.Size(70, 27)
        Me.TextBox57.TabIndex = 5
        '
        'TextBox47
        '
        Me.TextBox47.BackColor = System.Drawing.Color.Silver
        Me.TextBox47.Location = New System.Drawing.Point(184, 154)
        Me.TextBox47.Name = "TextBox47"
        Me.TextBox47.Size = New System.Drawing.Size(70, 27)
        Me.TextBox47.TabIndex = 5
        '
        'TextBox37
        '
        Me.TextBox37.BackColor = System.Drawing.Color.Silver
        Me.TextBox37.Location = New System.Drawing.Point(108, 154)
        Me.TextBox37.Name = "TextBox37"
        Me.TextBox37.Size = New System.Drawing.Size(70, 27)
        Me.TextBox37.TabIndex = 5
        '
        'TextBox27
        '
        Me.TextBox27.BackColor = System.Drawing.Color.Silver
        Me.TextBox27.Location = New System.Drawing.Point(32, 154)
        Me.TextBox27.Name = "TextBox27"
        Me.TextBox27.Size = New System.Drawing.Size(70, 27)
        Me.TextBox27.TabIndex = 5
        '
        'TextBox116
        '
        Me.TextBox116.BackColor = System.Drawing.Color.Silver
        Me.TextBox116.Location = New System.Drawing.Point(787, 76)
        Me.TextBox116.Name = "TextBox116"
        Me.TextBox116.Size = New System.Drawing.Size(70, 27)
        Me.TextBox116.TabIndex = 4
        '
        'TextBox106
        '
        Me.TextBox106.BackColor = System.Drawing.Color.Silver
        Me.TextBox106.Location = New System.Drawing.Point(699, 76)
        Me.TextBox106.Name = "TextBox106"
        Me.TextBox106.Size = New System.Drawing.Size(70, 27)
        Me.TextBox106.TabIndex = 4
        '
        'TextBox96
        '
        Me.TextBox96.BackColor = System.Drawing.Color.Silver
        Me.TextBox96.Location = New System.Drawing.Point(598, 76)
        Me.TextBox96.Name = "TextBox96"
        Me.TextBox96.Size = New System.Drawing.Size(70, 27)
        Me.TextBox96.TabIndex = 4
        '
        'TextBox86
        '
        Me.TextBox86.BackColor = System.Drawing.Color.Silver
        Me.TextBox86.Location = New System.Drawing.Point(522, 76)
        Me.TextBox86.Name = "TextBox86"
        Me.TextBox86.Size = New System.Drawing.Size(70, 27)
        Me.TextBox86.TabIndex = 4
        '
        'TextBox76
        '
        Me.TextBox76.BackColor = System.Drawing.Color.Silver
        Me.TextBox76.Location = New System.Drawing.Point(437, 76)
        Me.TextBox76.Name = "TextBox76"
        Me.TextBox76.Size = New System.Drawing.Size(70, 27)
        Me.TextBox76.TabIndex = 4
        '
        'TextBox66
        '
        Me.TextBox66.BackColor = System.Drawing.Color.Silver
        Me.TextBox66.Location = New System.Drawing.Point(361, 76)
        Me.TextBox66.Name = "TextBox66"
        Me.TextBox66.Size = New System.Drawing.Size(70, 27)
        Me.TextBox66.TabIndex = 4
        '
        'TextBox56
        '
        Me.TextBox56.BackColor = System.Drawing.Color.Silver
        Me.TextBox56.Location = New System.Drawing.Point(271, 76)
        Me.TextBox56.Name = "TextBox56"
        Me.TextBox56.Size = New System.Drawing.Size(70, 27)
        Me.TextBox56.TabIndex = 4
        '
        'TextBox46
        '
        Me.TextBox46.BackColor = System.Drawing.Color.Silver
        Me.TextBox46.Location = New System.Drawing.Point(184, 76)
        Me.TextBox46.Name = "TextBox46"
        Me.TextBox46.Size = New System.Drawing.Size(70, 27)
        Me.TextBox46.TabIndex = 4
        '
        'TextBox36
        '
        Me.TextBox36.BackColor = System.Drawing.Color.Silver
        Me.TextBox36.Location = New System.Drawing.Point(108, 76)
        Me.TextBox36.Name = "TextBox36"
        Me.TextBox36.Size = New System.Drawing.Size(70, 27)
        Me.TextBox36.TabIndex = 4
        '
        'TextBox26
        '
        Me.TextBox26.BackColor = System.Drawing.Color.Silver
        Me.TextBox26.Location = New System.Drawing.Point(32, 76)
        Me.TextBox26.Name = "TextBox26"
        Me.TextBox26.Size = New System.Drawing.Size(70, 27)
        Me.TextBox26.TabIndex = 4
        '
        'PictureBox29
        '
        Me.PictureBox29.Location = New System.Drawing.Point(-467, 785)
        Me.PictureBox29.Name = "PictureBox29"
        Me.PictureBox29.Size = New System.Drawing.Size(98, 57)
        Me.PictureBox29.TabIndex = 3
        Me.PictureBox29.TabStop = False
        '
        'PictureBox116
        '
        Me.PictureBox116.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox116.Location = New System.Drawing.Point(787, 358)
        Me.PictureBox116.Name = "PictureBox116"
        Me.PictureBox116.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox116.TabIndex = 2
        Me.PictureBox116.TabStop = False
        '
        'PictureBox106
        '
        Me.PictureBox106.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox106.Location = New System.Drawing.Point(699, 358)
        Me.PictureBox106.Name = "PictureBox106"
        Me.PictureBox106.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox106.TabIndex = 2
        Me.PictureBox106.TabStop = False
        '
        'PictureBox96
        '
        Me.PictureBox96.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox96.Location = New System.Drawing.Point(598, 358)
        Me.PictureBox96.Name = "PictureBox96"
        Me.PictureBox96.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox96.TabIndex = 2
        Me.PictureBox96.TabStop = False
        '
        'PictureBox86
        '
        Me.PictureBox86.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox86.Location = New System.Drawing.Point(522, 358)
        Me.PictureBox86.Name = "PictureBox86"
        Me.PictureBox86.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox86.TabIndex = 2
        Me.PictureBox86.TabStop = False
        '
        'PictureBox76
        '
        Me.PictureBox76.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox76.Location = New System.Drawing.Point(437, 358)
        Me.PictureBox76.Name = "PictureBox76"
        Me.PictureBox76.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox76.TabIndex = 2
        Me.PictureBox76.TabStop = False
        '
        'PictureBox66
        '
        Me.PictureBox66.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox66.Location = New System.Drawing.Point(361, 358)
        Me.PictureBox66.Name = "PictureBox66"
        Me.PictureBox66.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox66.TabIndex = 2
        Me.PictureBox66.TabStop = False
        '
        'PictureBox56
        '
        Me.PictureBox56.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox56.Location = New System.Drawing.Point(271, 358)
        Me.PictureBox56.Name = "PictureBox56"
        Me.PictureBox56.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox56.TabIndex = 2
        Me.PictureBox56.TabStop = False
        '
        'PictureBox46
        '
        Me.PictureBox46.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox46.Location = New System.Drawing.Point(184, 358)
        Me.PictureBox46.Name = "PictureBox46"
        Me.PictureBox46.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox46.TabIndex = 2
        Me.PictureBox46.TabStop = False
        '
        'PictureBox36
        '
        Me.PictureBox36.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox36.Location = New System.Drawing.Point(108, 358)
        Me.PictureBox36.Name = "PictureBox36"
        Me.PictureBox36.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox36.TabIndex = 2
        Me.PictureBox36.TabStop = False
        '
        'PictureBox26
        '
        Me.PictureBox26.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox26.Location = New System.Drawing.Point(32, 358)
        Me.PictureBox26.Name = "PictureBox26"
        Me.PictureBox26.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox26.TabIndex = 2
        Me.PictureBox26.TabStop = False
        '
        'PictureBox115
        '
        Me.PictureBox115.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox115.Location = New System.Drawing.Point(787, 265)
        Me.PictureBox115.Name = "PictureBox115"
        Me.PictureBox115.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox115.TabIndex = 2
        Me.PictureBox115.TabStop = False
        '
        'PictureBox105
        '
        Me.PictureBox105.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox105.Location = New System.Drawing.Point(699, 265)
        Me.PictureBox105.Name = "PictureBox105"
        Me.PictureBox105.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox105.TabIndex = 2
        Me.PictureBox105.TabStop = False
        '
        'PictureBox95
        '
        Me.PictureBox95.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox95.Location = New System.Drawing.Point(598, 265)
        Me.PictureBox95.Name = "PictureBox95"
        Me.PictureBox95.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox95.TabIndex = 2
        Me.PictureBox95.TabStop = False
        '
        'PictureBox85
        '
        Me.PictureBox85.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox85.Location = New System.Drawing.Point(522, 265)
        Me.PictureBox85.Name = "PictureBox85"
        Me.PictureBox85.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox85.TabIndex = 2
        Me.PictureBox85.TabStop = False
        '
        'PictureBox75
        '
        Me.PictureBox75.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox75.Location = New System.Drawing.Point(437, 265)
        Me.PictureBox75.Name = "PictureBox75"
        Me.PictureBox75.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox75.TabIndex = 2
        Me.PictureBox75.TabStop = False
        '
        'PictureBox65
        '
        Me.PictureBox65.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox65.Location = New System.Drawing.Point(361, 265)
        Me.PictureBox65.Name = "PictureBox65"
        Me.PictureBox65.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox65.TabIndex = 2
        Me.PictureBox65.TabStop = False
        '
        'PictureBox55
        '
        Me.PictureBox55.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox55.Location = New System.Drawing.Point(271, 265)
        Me.PictureBox55.Name = "PictureBox55"
        Me.PictureBox55.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox55.TabIndex = 2
        Me.PictureBox55.TabStop = False
        '
        'PictureBox45
        '
        Me.PictureBox45.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox45.Location = New System.Drawing.Point(184, 265)
        Me.PictureBox45.Name = "PictureBox45"
        Me.PictureBox45.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox45.TabIndex = 2
        Me.PictureBox45.TabStop = False
        '
        'PictureBox35
        '
        Me.PictureBox35.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox35.Location = New System.Drawing.Point(108, 265)
        Me.PictureBox35.Name = "PictureBox35"
        Me.PictureBox35.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox35.TabIndex = 2
        Me.PictureBox35.TabStop = False
        '
        'PictureBox25
        '
        Me.PictureBox25.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox25.Location = New System.Drawing.Point(32, 265)
        Me.PictureBox25.Name = "PictureBox25"
        Me.PictureBox25.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox25.TabIndex = 2
        Me.PictureBox25.TabStop = False
        '
        'PictureBox114
        '
        Me.PictureBox114.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox114.Location = New System.Drawing.Point(787, 187)
        Me.PictureBox114.Name = "PictureBox114"
        Me.PictureBox114.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox114.TabIndex = 2
        Me.PictureBox114.TabStop = False
        '
        'PictureBox104
        '
        Me.PictureBox104.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox104.Location = New System.Drawing.Point(699, 187)
        Me.PictureBox104.Name = "PictureBox104"
        Me.PictureBox104.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox104.TabIndex = 2
        Me.PictureBox104.TabStop = False
        '
        'PictureBox94
        '
        Me.PictureBox94.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox94.Location = New System.Drawing.Point(598, 187)
        Me.PictureBox94.Name = "PictureBox94"
        Me.PictureBox94.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox94.TabIndex = 2
        Me.PictureBox94.TabStop = False
        '
        'PictureBox84
        '
        Me.PictureBox84.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox84.Location = New System.Drawing.Point(522, 187)
        Me.PictureBox84.Name = "PictureBox84"
        Me.PictureBox84.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox84.TabIndex = 2
        Me.PictureBox84.TabStop = False
        '
        'PictureBox74
        '
        Me.PictureBox74.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox74.Location = New System.Drawing.Point(437, 187)
        Me.PictureBox74.Name = "PictureBox74"
        Me.PictureBox74.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox74.TabIndex = 2
        Me.PictureBox74.TabStop = False
        '
        'PictureBox64
        '
        Me.PictureBox64.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox64.Location = New System.Drawing.Point(361, 187)
        Me.PictureBox64.Name = "PictureBox64"
        Me.PictureBox64.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox64.TabIndex = 2
        Me.PictureBox64.TabStop = False
        '
        'PictureBox54
        '
        Me.PictureBox54.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox54.Location = New System.Drawing.Point(271, 187)
        Me.PictureBox54.Name = "PictureBox54"
        Me.PictureBox54.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox54.TabIndex = 2
        Me.PictureBox54.TabStop = False
        '
        'PictureBox44
        '
        Me.PictureBox44.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox44.Location = New System.Drawing.Point(184, 187)
        Me.PictureBox44.Name = "PictureBox44"
        Me.PictureBox44.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox44.TabIndex = 2
        Me.PictureBox44.TabStop = False
        '
        'PictureBox34
        '
        Me.PictureBox34.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox34.Location = New System.Drawing.Point(108, 187)
        Me.PictureBox34.Name = "PictureBox34"
        Me.PictureBox34.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox34.TabIndex = 2
        Me.PictureBox34.TabStop = False
        '
        'PictureBox24
        '
        Me.PictureBox24.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox24.Location = New System.Drawing.Point(32, 187)
        Me.PictureBox24.Name = "PictureBox24"
        Me.PictureBox24.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox24.TabIndex = 2
        Me.PictureBox24.TabStop = False
        '
        'PictureBox113
        '
        Me.PictureBox113.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox113.Location = New System.Drawing.Point(787, 109)
        Me.PictureBox113.Name = "PictureBox113"
        Me.PictureBox113.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox113.TabIndex = 2
        Me.PictureBox113.TabStop = False
        '
        'PictureBox103
        '
        Me.PictureBox103.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox103.Location = New System.Drawing.Point(699, 109)
        Me.PictureBox103.Name = "PictureBox103"
        Me.PictureBox103.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox103.TabIndex = 2
        Me.PictureBox103.TabStop = False
        '
        'PictureBox93
        '
        Me.PictureBox93.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox93.Location = New System.Drawing.Point(598, 109)
        Me.PictureBox93.Name = "PictureBox93"
        Me.PictureBox93.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox93.TabIndex = 2
        Me.PictureBox93.TabStop = False
        '
        'PictureBox83
        '
        Me.PictureBox83.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox83.Location = New System.Drawing.Point(522, 109)
        Me.PictureBox83.Name = "PictureBox83"
        Me.PictureBox83.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox83.TabIndex = 2
        Me.PictureBox83.TabStop = False
        '
        'PictureBox73
        '
        Me.PictureBox73.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox73.Location = New System.Drawing.Point(437, 109)
        Me.PictureBox73.Name = "PictureBox73"
        Me.PictureBox73.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox73.TabIndex = 2
        Me.PictureBox73.TabStop = False
        '
        'PictureBox63
        '
        Me.PictureBox63.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox63.Location = New System.Drawing.Point(361, 109)
        Me.PictureBox63.Name = "PictureBox63"
        Me.PictureBox63.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox63.TabIndex = 2
        Me.PictureBox63.TabStop = False
        '
        'PictureBox53
        '
        Me.PictureBox53.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox53.Location = New System.Drawing.Point(271, 109)
        Me.PictureBox53.Name = "PictureBox53"
        Me.PictureBox53.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox53.TabIndex = 2
        Me.PictureBox53.TabStop = False
        '
        'PictureBox43
        '
        Me.PictureBox43.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox43.Location = New System.Drawing.Point(184, 109)
        Me.PictureBox43.Name = "PictureBox43"
        Me.PictureBox43.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox43.TabIndex = 2
        Me.PictureBox43.TabStop = False
        '
        'PictureBox33
        '
        Me.PictureBox33.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox33.Location = New System.Drawing.Point(108, 109)
        Me.PictureBox33.Name = "PictureBox33"
        Me.PictureBox33.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox33.TabIndex = 2
        Me.PictureBox33.TabStop = False
        '
        'PictureBox22
        '
        Me.PictureBox22.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox22.Location = New System.Drawing.Point(32, 109)
        Me.PictureBox22.Name = "PictureBox22"
        Me.PictureBox22.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox22.TabIndex = 2
        Me.PictureBox22.TabStop = False
        '
        'PictureBox112
        '
        Me.PictureBox112.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox112.Location = New System.Drawing.Point(787, 31)
        Me.PictureBox112.Name = "PictureBox112"
        Me.PictureBox112.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox112.TabIndex = 2
        Me.PictureBox112.TabStop = False
        '
        'PictureBox102
        '
        Me.PictureBox102.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox102.Location = New System.Drawing.Point(699, 31)
        Me.PictureBox102.Name = "PictureBox102"
        Me.PictureBox102.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox102.TabIndex = 2
        Me.PictureBox102.TabStop = False
        '
        'PictureBox92
        '
        Me.PictureBox92.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox92.Location = New System.Drawing.Point(598, 31)
        Me.PictureBox92.Name = "PictureBox92"
        Me.PictureBox92.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox92.TabIndex = 2
        Me.PictureBox92.TabStop = False
        '
        'PictureBox82
        '
        Me.PictureBox82.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox82.Location = New System.Drawing.Point(522, 31)
        Me.PictureBox82.Name = "PictureBox82"
        Me.PictureBox82.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox82.TabIndex = 2
        Me.PictureBox82.TabStop = False
        '
        'PictureBox72
        '
        Me.PictureBox72.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox72.Location = New System.Drawing.Point(437, 31)
        Me.PictureBox72.Name = "PictureBox72"
        Me.PictureBox72.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox72.TabIndex = 2
        Me.PictureBox72.TabStop = False
        '
        'PictureBox62
        '
        Me.PictureBox62.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox62.Location = New System.Drawing.Point(361, 31)
        Me.PictureBox62.Name = "PictureBox62"
        Me.PictureBox62.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox62.TabIndex = 2
        Me.PictureBox62.TabStop = False
        '
        'PictureBox52
        '
        Me.PictureBox52.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox52.Location = New System.Drawing.Point(271, 31)
        Me.PictureBox52.Name = "PictureBox52"
        Me.PictureBox52.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox52.TabIndex = 2
        Me.PictureBox52.TabStop = False
        '
        'PictureBox42
        '
        Me.PictureBox42.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox42.Location = New System.Drawing.Point(184, 31)
        Me.PictureBox42.Name = "PictureBox42"
        Me.PictureBox42.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox42.TabIndex = 2
        Me.PictureBox42.TabStop = False
        '
        'PictureBox32
        '
        Me.PictureBox32.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox32.Location = New System.Drawing.Point(108, 31)
        Me.PictureBox32.Name = "PictureBox32"
        Me.PictureBox32.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox32.TabIndex = 2
        Me.PictureBox32.TabStop = False
        '
        'PictureBox23
        '
        Me.PictureBox23.Image = Global.Airline.My.Resources.Resources.eco1
        Me.PictureBox23.Location = New System.Drawing.Point(32, 31)
        Me.PictureBox23.Name = "PictureBox23"
        Me.PictureBox23.Size = New System.Drawing.Size(70, 39)
        Me.PictureBox23.TabIndex = 2
        Me.PictureBox23.TabStop = False
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.TabPage1.Controls.Add(Me.Button4)
        Me.TabPage1.Controls.Add(Me.TextBox25)
        Me.TabPage1.Controls.Add(Me.TextBox24)
        Me.TabPage1.Controls.Add(Me.TextBox23)
        Me.TabPage1.Controls.Add(Me.TextBox22)
        Me.TabPage1.Controls.Add(Me.TextBox21)
        Me.TabPage1.Controls.Add(Me.TextBox20)
        Me.TabPage1.Controls.Add(Me.TextBox19)
        Me.TabPage1.Controls.Add(Me.TextBox18)
        Me.TabPage1.Controls.Add(Me.TextBox17)
        Me.TabPage1.Controls.Add(Me.TextBox16)
        Me.TabPage1.Controls.Add(Me.TextBox15)
        Me.TabPage1.Controls.Add(Me.TextBox14)
        Me.TabPage1.Controls.Add(Me.TextBox13)
        Me.TabPage1.Controls.Add(Me.TextBox12)
        Me.TabPage1.Controls.Add(Me.TextBox11)
        Me.TabPage1.Controls.Add(Me.TextBox10)
        Me.TabPage1.Controls.Add(Me.TextBox9)
        Me.TabPage1.Controls.Add(Me.TextBox8)
        Me.TabPage1.Controls.Add(Me.TextBox7)
        Me.TabPage1.Controls.Add(Me.TextBox6)
        Me.TabPage1.Controls.Add(Me.Button3)
        Me.TabPage1.Controls.Add(Me.Label11)
        Me.TabPage1.Controls.Add(Me.TextBox5)
        Me.TabPage1.Controls.Add(Me.Label10)
        Me.TabPage1.Controls.Add(Me.TextBox4)
        Me.TabPage1.Controls.Add(Me.Button2)
        Me.TabPage1.Controls.Add(Me.Label8)
        Me.TabPage1.Controls.Add(Me.Label7)
        Me.TabPage1.Controls.Add(Me.Label6)
        Me.TabPage1.Controls.Add(Me.TextBox3)
        Me.TabPage1.Controls.Add(Me.TextBox2)
        Me.TabPage1.Controls.Add(Me.Label5)
        Me.TabPage1.Controls.Add(Me.Label4)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Controls.Add(Me.Button1)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Controls.Add(Me.TextBox1)
        Me.TabPage1.Controls.Add(Me.RichTextBox1)
        Me.TabPage1.Controls.Add(Me.PictureBox20)
        Me.TabPage1.Controls.Add(Me.PictureBox19)
        Me.TabPage1.Controls.Add(Me.PictureBox18)
        Me.TabPage1.Controls.Add(Me.PictureBox17)
        Me.TabPage1.Controls.Add(Me.PictureBox16)
        Me.TabPage1.Controls.Add(Me.PictureBox15)
        Me.TabPage1.Controls.Add(Me.PictureBox14)
        Me.TabPage1.Controls.Add(Me.PictureBox13)
        Me.TabPage1.Controls.Add(Me.PictureBox12)
        Me.TabPage1.Controls.Add(Me.PictureBox11)
        Me.TabPage1.Controls.Add(Me.PictureBox10)
        Me.TabPage1.Controls.Add(Me.PictureBox9)
        Me.TabPage1.Controls.Add(Me.PictureBox8)
        Me.TabPage1.Controls.Add(Me.PictureBox7)
        Me.TabPage1.Controls.Add(Me.PictureBox6)
        Me.TabPage1.Controls.Add(Me.PictureBox5)
        Me.TabPage1.Controls.Add(Me.PictureBox4)
        Me.TabPage1.Controls.Add(Me.PictureBox3)
        Me.TabPage1.Controls.Add(Me.PictureBox2)
        Me.TabPage1.Controls.Add(Me.PictureBox1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 29)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1341, 998)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Business class"
        '
        'Button4
        '
        Me.Button4.Font = New System.Drawing.Font("Segoe UI", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Button4.Location = New System.Drawing.Point(1013, 251)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(118, 36)
        Me.Button4.TabIndex = 59
        Me.Button4.Text = "delet"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'TextBox25
        '
        Me.TextBox25.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.TextBox25.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox25.Location = New System.Drawing.Point(591, 609)
        Me.TextBox25.Multiline = True
        Me.TextBox25.Name = "TextBox25"
        Me.TextBox25.Size = New System.Drawing.Size(125, 27)
        Me.TextBox25.TabIndex = 58
        '
        'TextBox24
        '
        Me.TextBox24.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.TextBox24.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox24.Location = New System.Drawing.Point(435, 609)
        Me.TextBox24.Multiline = True
        Me.TextBox24.Name = "TextBox24"
        Me.TextBox24.Size = New System.Drawing.Size(125, 27)
        Me.TextBox24.TabIndex = 57
        '
        'TextBox23
        '
        Me.TextBox23.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.TextBox23.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox23.Location = New System.Drawing.Point(212, 609)
        Me.TextBox23.Multiline = True
        Me.TextBox23.Name = "TextBox23"
        Me.TextBox23.Size = New System.Drawing.Size(125, 27)
        Me.TextBox23.TabIndex = 56
        '
        'TextBox22
        '
        Me.TextBox22.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.TextBox22.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox22.Location = New System.Drawing.Point(72, 609)
        Me.TextBox22.Multiline = True
        Me.TextBox22.Name = "TextBox22"
        Me.TextBox22.Size = New System.Drawing.Size(125, 27)
        Me.TextBox22.TabIndex = 55
        '
        'TextBox21
        '
        Me.TextBox21.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.TextBox21.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox21.Location = New System.Drawing.Point(591, 482)
        Me.TextBox21.Multiline = True
        Me.TextBox21.Name = "TextBox21"
        Me.TextBox21.Size = New System.Drawing.Size(125, 27)
        Me.TextBox21.TabIndex = 54
        '
        'TextBox20
        '
        Me.TextBox20.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.TextBox20.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox20.Location = New System.Drawing.Point(435, 482)
        Me.TextBox20.Multiline = True
        Me.TextBox20.Name = "TextBox20"
        Me.TextBox20.Size = New System.Drawing.Size(125, 27)
        Me.TextBox20.TabIndex = 53
        '
        'TextBox19
        '
        Me.TextBox19.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.TextBox19.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox19.Location = New System.Drawing.Point(212, 482)
        Me.TextBox19.Multiline = True
        Me.TextBox19.Name = "TextBox19"
        Me.TextBox19.Size = New System.Drawing.Size(125, 27)
        Me.TextBox19.TabIndex = 52
        '
        'TextBox18
        '
        Me.TextBox18.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.TextBox18.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox18.Location = New System.Drawing.Point(72, 482)
        Me.TextBox18.Multiline = True
        Me.TextBox18.Name = "TextBox18"
        Me.TextBox18.Size = New System.Drawing.Size(125, 27)
        Me.TextBox18.TabIndex = 51
        '
        'TextBox17
        '
        Me.TextBox17.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.TextBox17.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox17.Location = New System.Drawing.Point(596, 357)
        Me.TextBox17.Multiline = True
        Me.TextBox17.Name = "TextBox17"
        Me.TextBox17.Size = New System.Drawing.Size(125, 27)
        Me.TextBox17.TabIndex = 50
        '
        'TextBox16
        '
        Me.TextBox16.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.TextBox16.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox16.Location = New System.Drawing.Point(435, 357)
        Me.TextBox16.Multiline = True
        Me.TextBox16.Name = "TextBox16"
        Me.TextBox16.Size = New System.Drawing.Size(125, 27)
        Me.TextBox16.TabIndex = 49
        '
        'TextBox15
        '
        Me.TextBox15.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.TextBox15.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox15.Location = New System.Drawing.Point(212, 357)
        Me.TextBox15.Multiline = True
        Me.TextBox15.Name = "TextBox15"
        Me.TextBox15.Size = New System.Drawing.Size(125, 27)
        Me.TextBox15.TabIndex = 48
        '
        'TextBox14
        '
        Me.TextBox14.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.TextBox14.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox14.Location = New System.Drawing.Point(72, 357)
        Me.TextBox14.Multiline = True
        Me.TextBox14.Name = "TextBox14"
        Me.TextBox14.Size = New System.Drawing.Size(125, 27)
        Me.TextBox14.TabIndex = 47
        '
        'TextBox13
        '
        Me.TextBox13.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.TextBox13.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox13.Location = New System.Drawing.Point(596, 230)
        Me.TextBox13.Multiline = True
        Me.TextBox13.Name = "TextBox13"
        Me.TextBox13.Size = New System.Drawing.Size(125, 27)
        Me.TextBox13.TabIndex = 46
        '
        'TextBox12
        '
        Me.TextBox12.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.TextBox12.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox12.Location = New System.Drawing.Point(435, 230)
        Me.TextBox12.Multiline = True
        Me.TextBox12.Name = "TextBox12"
        Me.TextBox12.Size = New System.Drawing.Size(125, 27)
        Me.TextBox12.TabIndex = 45
        '
        'TextBox11
        '
        Me.TextBox11.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.TextBox11.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox11.Location = New System.Drawing.Point(212, 230)
        Me.TextBox11.Multiline = True
        Me.TextBox11.Name = "TextBox11"
        Me.TextBox11.Size = New System.Drawing.Size(125, 27)
        Me.TextBox11.TabIndex = 44
        '
        'TextBox10
        '
        Me.TextBox10.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.TextBox10.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox10.Location = New System.Drawing.Point(72, 230)
        Me.TextBox10.Multiline = True
        Me.TextBox10.Name = "TextBox10"
        Me.TextBox10.Size = New System.Drawing.Size(125, 27)
        Me.TextBox10.TabIndex = 43
        '
        'TextBox9
        '
        Me.TextBox9.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.TextBox9.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox9.Location = New System.Drawing.Point(596, 98)
        Me.TextBox9.Multiline = True
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(125, 27)
        Me.TextBox9.TabIndex = 42
        '
        'TextBox8
        '
        Me.TextBox8.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.TextBox8.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox8.Location = New System.Drawing.Point(435, 98)
        Me.TextBox8.Multiline = True
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(125, 27)
        Me.TextBox8.TabIndex = 41
        '
        'TextBox7
        '
        Me.TextBox7.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.TextBox7.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox7.Location = New System.Drawing.Point(222, 98)
        Me.TextBox7.Multiline = True
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(125, 27)
        Me.TextBox7.TabIndex = 40
        '
        'TextBox6
        '
        Me.TextBox6.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.TextBox6.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox6.Location = New System.Drawing.Point(72, 89)
        Me.TextBox6.Multiline = True
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(134, 27)
        Me.TextBox6.TabIndex = 39
        '
        'Button3
        '
        Me.Button3.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Button3.Location = New System.Drawing.Point(1162, 248)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(142, 36)
        Me.Button3.TabIndex = 38
        Me.Button3.Text = "OK"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Segoe UI", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label11.Location = New System.Drawing.Point(1148, 217)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(77, 25)
        Me.Label11.TabIndex = 37
        Me.Label11.Text = "Column"
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(1231, 215)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(71, 27)
        Me.TextBox5.TabIndex = 36
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Segoe UI", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label10.Location = New System.Drawing.Point(1176, 184)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(49, 25)
        Me.Label10.TabIndex = 35
        Me.Label10.Text = "Row"
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(1231, 182)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(71, 27)
        Me.TextBox4.TabIndex = 34
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Button2.Location = New System.Drawing.Point(949, 731)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(206, 45)
        Me.Button2.TabIndex = 33
        Me.Button2.Text = "Cancel All Reservation"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.BackColor = System.Drawing.Color.Snow
        Me.Label8.Font = New System.Drawing.Font("Segoe UI", 13.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.Label8.Location = New System.Drawing.Point(879, 572)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(346, 31)
        Me.Label8.TabIndex = 32
        Me.Label8.Text = "Cancelation of the reservation."
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Segoe UI", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label7.Location = New System.Drawing.Point(1054, 627)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(77, 25)
        Me.Label7.TabIndex = 31
        Me.Label7.Text = "Column"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Segoe UI", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label6.Location = New System.Drawing.Point(842, 625)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(49, 25)
        Me.Label6.TabIndex = 30
        Me.Label6.Text = "Row"
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(1137, 626)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(71, 27)
        Me.TextBox3.TabIndex = 29
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(910, 625)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(71, 27)
        Me.TextBox2.TabIndex = 28
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label5.Location = New System.Drawing.Point(780, 277)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(181, 28)
        Me.Label5.TabIndex = 27
        Me.Label5.Text = "Seat Reservations"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Segoe UI", 10.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point)
        Me.Label4.Location = New System.Drawing.Point(1013, 76)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(312, 25)
        Me.Label4.TabIndex = 26
        Me.Label4.Text = " and cancelation of the reservation."
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Segoe UI", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label3.Location = New System.Drawing.Point(799, 51)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(299, 25)
        Me.Label3.TabIndex = 25
        Me.Label3.Text = "An application for reserving seats"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Wide Latin", 13.8!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point)
        Me.Label2.Location = New System.Drawing.Point(929, 3)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(308, 28)
        Me.Label2.TabIndex = 24
        Me.Label2.Text = "ACME airlines "
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.DarkGray
        Me.Button1.Font = New System.Drawing.Font("Segoe UI", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Button1.Location = New System.Drawing.Point(826, 677)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(460, 39)
        Me.Button1.TabIndex = 23
        Me.Button1.Text = "Cancel"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Snow
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label1.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.Label1.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.Label1.ForeColor = System.Drawing.Color.MidnightBlue
        Me.Label1.Location = New System.Drawing.Point(1054, 113)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(248, 33)
        Me.Label1.TabIndex = 22
        Me.Label1.Text = "Input your First  and Last name"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'TextBox1
        '
        Me.TextBox1.AccessibleName = ""
        Me.TextBox1.BackColor = System.Drawing.SystemColors.HighlightText
        Me.TextBox1.Location = New System.Drawing.Point(1055, 149)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(249, 27)
        Me.TextBox1.TabIndex = 21
        '
        'RichTextBox1
        '
        Me.RichTextBox1.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.RichTextBox1.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point)
        Me.RichTextBox1.ForeColor = System.Drawing.SystemColors.InactiveCaptionText
        Me.RichTextBox1.Location = New System.Drawing.Point(780, 320)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(533, 217)
        Me.RichTextBox1.TabIndex = 20
        Me.RichTextBox1.Text = ""
        '
        'PictureBox20
        '
        Me.PictureBox20.Image = Global.Airline.My.Resources.Resources.Business1
        Me.PictureBox20.Location = New System.Drawing.Point(591, 541)
        Me.PictureBox20.Name = "PictureBox20"
        Me.PictureBox20.Size = New System.Drawing.Size(142, 62)
        Me.PictureBox20.TabIndex = 19
        Me.PictureBox20.TabStop = False
        '
        'PictureBox19
        '
        Me.PictureBox19.Image = Global.Airline.My.Resources.Resources.Business1
        Me.PictureBox19.Location = New System.Drawing.Point(596, 414)
        Me.PictureBox19.Name = "PictureBox19"
        Me.PictureBox19.Size = New System.Drawing.Size(137, 62)
        Me.PictureBox19.TabIndex = 18
        Me.PictureBox19.TabStop = False
        '
        'PictureBox18
        '
        Me.PictureBox18.Image = Global.Airline.My.Resources.Resources.Business1
        Me.PictureBox18.Location = New System.Drawing.Point(596, 289)
        Me.PictureBox18.Name = "PictureBox18"
        Me.PictureBox18.Size = New System.Drawing.Size(137, 62)
        Me.PictureBox18.TabIndex = 17
        Me.PictureBox18.TabStop = False
        '
        'PictureBox17
        '
        Me.PictureBox17.Image = Global.Airline.My.Resources.Resources.Business1
        Me.PictureBox17.Location = New System.Drawing.Point(596, 162)
        Me.PictureBox17.Name = "PictureBox17"
        Me.PictureBox17.Size = New System.Drawing.Size(137, 62)
        Me.PictureBox17.TabIndex = 16
        Me.PictureBox17.TabStop = False
        '
        'PictureBox16
        '
        Me.PictureBox16.Image = Global.Airline.My.Resources.Resources.Business1
        Me.PictureBox16.Location = New System.Drawing.Point(596, 30)
        Me.PictureBox16.Name = "PictureBox16"
        Me.PictureBox16.Size = New System.Drawing.Size(137, 62)
        Me.PictureBox16.TabIndex = 15
        Me.PictureBox16.TabStop = False
        '
        'PictureBox15
        '
        Me.PictureBox15.Image = Global.Airline.My.Resources.Resources.Business1
        Me.PictureBox15.Location = New System.Drawing.Point(435, 541)
        Me.PictureBox15.Name = "PictureBox15"
        Me.PictureBox15.Size = New System.Drawing.Size(145, 62)
        Me.PictureBox15.TabIndex = 14
        Me.PictureBox15.TabStop = False
        '
        'PictureBox14
        '
        Me.PictureBox14.Image = Global.Airline.My.Resources.Resources.Business1
        Me.PictureBox14.Location = New System.Drawing.Point(435, 414)
        Me.PictureBox14.Name = "PictureBox14"
        Me.PictureBox14.Size = New System.Drawing.Size(145, 62)
        Me.PictureBox14.TabIndex = 13
        Me.PictureBox14.TabStop = False
        '
        'PictureBox13
        '
        Me.PictureBox13.Image = Global.Airline.My.Resources.Resources.Business1
        Me.PictureBox13.Location = New System.Drawing.Point(435, 289)
        Me.PictureBox13.Name = "PictureBox13"
        Me.PictureBox13.Size = New System.Drawing.Size(145, 62)
        Me.PictureBox13.TabIndex = 12
        Me.PictureBox13.TabStop = False
        '
        'PictureBox12
        '
        Me.PictureBox12.Image = Global.Airline.My.Resources.Resources.Business1
        Me.PictureBox12.Location = New System.Drawing.Point(435, 162)
        Me.PictureBox12.Name = "PictureBox12"
        Me.PictureBox12.Size = New System.Drawing.Size(145, 62)
        Me.PictureBox12.TabIndex = 11
        Me.PictureBox12.TabStop = False
        '
        'PictureBox11
        '
        Me.PictureBox11.Image = Global.Airline.My.Resources.Resources.Business1
        Me.PictureBox11.Location = New System.Drawing.Point(435, 30)
        Me.PictureBox11.Name = "PictureBox11"
        Me.PictureBox11.Size = New System.Drawing.Size(145, 62)
        Me.PictureBox11.TabIndex = 10
        Me.PictureBox11.TabStop = False
        '
        'PictureBox10
        '
        Me.PictureBox10.Image = Global.Airline.My.Resources.Resources.Business1
        Me.PictureBox10.Location = New System.Drawing.Point(212, 541)
        Me.PictureBox10.Name = "PictureBox10"
        Me.PictureBox10.Size = New System.Drawing.Size(145, 62)
        Me.PictureBox10.TabIndex = 9
        Me.PictureBox10.TabStop = False
        '
        'PictureBox9
        '
        Me.PictureBox9.Image = Global.Airline.My.Resources.Resources.Business1
        Me.PictureBox9.Location = New System.Drawing.Point(212, 414)
        Me.PictureBox9.Name = "PictureBox9"
        Me.PictureBox9.Size = New System.Drawing.Size(145, 62)
        Me.PictureBox9.TabIndex = 8
        Me.PictureBox9.TabStop = False
        '
        'PictureBox8
        '
        Me.PictureBox8.Image = Global.Airline.My.Resources.Resources.Business1
        Me.PictureBox8.Location = New System.Drawing.Point(212, 289)
        Me.PictureBox8.Name = "PictureBox8"
        Me.PictureBox8.Size = New System.Drawing.Size(145, 62)
        Me.PictureBox8.TabIndex = 7
        Me.PictureBox8.TabStop = False
        '
        'PictureBox7
        '
        Me.PictureBox7.Image = Global.Airline.My.Resources.Resources.Business1
        Me.PictureBox7.Location = New System.Drawing.Point(212, 162)
        Me.PictureBox7.Name = "PictureBox7"
        Me.PictureBox7.Size = New System.Drawing.Size(145, 62)
        Me.PictureBox7.TabIndex = 6
        Me.PictureBox7.TabStop = False
        '
        'PictureBox6
        '
        Me.PictureBox6.Image = Global.Airline.My.Resources.Resources.Business1
        Me.PictureBox6.Location = New System.Drawing.Point(222, 30)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(135, 62)
        Me.PictureBox6.TabIndex = 5
        Me.PictureBox6.TabStop = False
        '
        'PictureBox5
        '
        Me.PictureBox5.Image = Global.Airline.My.Resources.Resources.Business1
        Me.PictureBox5.Location = New System.Drawing.Point(72, 541)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(134, 62)
        Me.PictureBox5.TabIndex = 4
        Me.PictureBox5.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.Image = Global.Airline.My.Resources.Resources.Business1
        Me.PictureBox4.Location = New System.Drawing.Point(72, 414)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(134, 62)
        Me.PictureBox4.TabIndex = 3
        Me.PictureBox4.TabStop = False
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = Global.Airline.My.Resources.Resources.Business1
        Me.PictureBox3.Location = New System.Drawing.Point(72, 289)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(134, 62)
        Me.PictureBox3.TabIndex = 2
        Me.PictureBox3.TabStop = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.Airline.My.Resources.Resources.Business1
        Me.PictureBox2.Location = New System.Drawing.Point(72, 162)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(134, 62)
        Me.PictureBox2.TabIndex = 1
        Me.PictureBox2.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Airline.My.Resources.Resources.Business1
        Me.PictureBox1.Location = New System.Drawing.Point(72, 30)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(134, 62)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Eco
        '
        Me.Eco.Controls.Add(Me.TabPage1)
        Me.Eco.Controls.Add(Me.TabPage2)
        Me.Eco.Location = New System.Drawing.Point(1, 12)
        Me.Eco.Name = "Eco"
        Me.Eco.SelectedIndex = 0
        Me.Eco.Size = New System.Drawing.Size(1349, 1031)
        Me.Eco.TabIndex = 0
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1362, 1055)
        Me.Controls.Add(Me.Eco)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.PictureBox29, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox116, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox106, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox96, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox86, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox76, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox66, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox56, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox46, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox36, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox26, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox115, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox105, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox95, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox85, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox75, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox65, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox55, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox45, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox35, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox25, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox114, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox104, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox94, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox84, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox74, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox64, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox54, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox44, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox34, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox24, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox113, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox103, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox93, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox83, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox73, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox63, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox53, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox43, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox33, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox22, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox112, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox102, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox92, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox82, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox72, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox62, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox52, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox42, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox32, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox23, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        CType(Me.PictureBox20, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox19, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox18, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox17, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox16, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox15, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox13, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Eco.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents PictureBox16 As PictureBox
    Friend WithEvents PictureBox11 As PictureBox
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents Eco As TabControl
    Friend WithEvents RichTextBox1 As RichTextBox
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents TextBox5 As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents TextBox4 As TextBox
    Friend WithEvents Button3 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents Button1 As Button
    Friend WithEvents PictureBox20 As PictureBox
    Friend WithEvents PictureBox19 As PictureBox
    Friend WithEvents PictureBox18 As PictureBox
    Friend WithEvents PictureBox17 As PictureBox
    Friend WithEvents PictureBox15 As PictureBox
    Friend WithEvents PictureBox14 As PictureBox
    Friend WithEvents PictureBox13 As PictureBox
    Friend WithEvents PictureBox12 As PictureBox
    Friend WithEvents PictureBox10 As PictureBox
    Friend WithEvents PictureBox9 As PictureBox
    Friend WithEvents PictureBox8 As PictureBox
    Friend WithEvents PictureBox7 As PictureBox
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents TextBox25 As TextBox
    Friend WithEvents TextBox24 As TextBox
    Friend WithEvents TextBox23 As TextBox
    Friend WithEvents TextBox22 As TextBox
    Friend WithEvents TextBox21 As TextBox
    Friend WithEvents TextBox20 As TextBox
    Friend WithEvents TextBox19 As TextBox
    Friend WithEvents TextBox18 As TextBox
    Friend WithEvents TextBox17 As TextBox
    Friend WithEvents TextBox16 As TextBox
    Friend WithEvents TextBox15 As TextBox
    Friend WithEvents TextBox14 As TextBox
    Friend WithEvents TextBox13 As TextBox
    Friend WithEvents TextBox12 As TextBox
    Friend WithEvents TextBox11 As TextBox
    Friend WithEvents TextBox10 As TextBox
    Friend WithEvents TextBox9 As TextBox
    Friend WithEvents TextBox8 As TextBox
    Friend WithEvents TextBox7 As TextBox
    Friend WithEvents TextBox6 As TextBox
    Friend WithEvents Button4 As Button
    Friend WithEvents PictureBox29 As PictureBox
    Friend WithEvents PictureBox26 As PictureBox
    Friend WithEvents PictureBox25 As PictureBox
    Friend WithEvents PictureBox24 As PictureBox
    Friend WithEvents PictureBox22 As PictureBox
    Friend WithEvents PictureBox23 As PictureBox
    Friend WithEvents TextBox120 As TextBox
    Friend WithEvents TextBox110 As TextBox
    Friend WithEvents TextBox100 As TextBox
    Friend WithEvents TextBox90 As TextBox
    Friend WithEvents TextBox80 As TextBox
    Friend WithEvents TextBox70 As TextBox
    Friend WithEvents TextBox60 As TextBox
    Friend WithEvents TextBox50 As TextBox
    Friend WithEvents TextBox40 As TextBox
    Friend WithEvents TextBox30 As TextBox
    Friend WithEvents TextBox119 As TextBox
    Friend WithEvents TextBox109 As TextBox
    Friend WithEvents TextBox99 As TextBox
    Friend WithEvents TextBox89 As TextBox
    Friend WithEvents TextBox79 As TextBox
    Friend WithEvents TextBox69 As TextBox
    Friend WithEvents TextBox59 As TextBox
    Friend WithEvents TextBox49 As TextBox
    Friend WithEvents TextBox39 As TextBox
    Friend WithEvents TextBox29 As TextBox
    Friend WithEvents TextBox118 As TextBox
    Friend WithEvents TextBox108 As TextBox
    Friend WithEvents TextBox98 As TextBox
    Friend WithEvents TextBox88 As TextBox
    Friend WithEvents TextBox78 As TextBox
    Friend WithEvents TextBox68 As TextBox
    Friend WithEvents TextBox58 As TextBox
    Friend WithEvents TextBox48 As TextBox
    Friend WithEvents TextBox38 As TextBox
    Friend WithEvents TextBox28 As TextBox
    Friend WithEvents TextBox117 As TextBox
    Friend WithEvents TextBox107 As TextBox
    Friend WithEvents TextBox97 As TextBox
    Friend WithEvents TextBox87 As TextBox
    Friend WithEvents TextBox77 As TextBox
    Friend WithEvents TextBox67 As TextBox
    Friend WithEvents TextBox57 As TextBox
    Friend WithEvents TextBox47 As TextBox
    Friend WithEvents TextBox37 As TextBox
    Friend WithEvents TextBox27 As TextBox
    Friend WithEvents TextBox116 As TextBox
    Friend WithEvents TextBox106 As TextBox
    Friend WithEvents TextBox96 As TextBox
    Friend WithEvents TextBox86 As TextBox
    Friend WithEvents TextBox76 As TextBox
    Friend WithEvents TextBox66 As TextBox
    Friend WithEvents TextBox56 As TextBox
    Friend WithEvents TextBox46 As TextBox
    Friend WithEvents TextBox36 As TextBox
    Friend WithEvents TextBox26 As TextBox
    Friend WithEvents PictureBox116 As PictureBox
    Friend WithEvents PictureBox106 As PictureBox
    Friend WithEvents PictureBox96 As PictureBox
    Friend WithEvents PictureBox86 As PictureBox
    Friend WithEvents PictureBox76 As PictureBox
    Friend WithEvents PictureBox66 As PictureBox
    Friend WithEvents PictureBox56 As PictureBox
    Friend WithEvents PictureBox46 As PictureBox
    Friend WithEvents PictureBox36 As PictureBox
    Friend WithEvents PictureBox115 As PictureBox
    Friend WithEvents PictureBox105 As PictureBox
    Friend WithEvents PictureBox95 As PictureBox
    Friend WithEvents PictureBox85 As PictureBox
    Friend WithEvents PictureBox75 As PictureBox
    Friend WithEvents PictureBox65 As PictureBox
    Friend WithEvents PictureBox55 As PictureBox
    Friend WithEvents PictureBox45 As PictureBox
    Friend WithEvents PictureBox35 As PictureBox
    Friend WithEvents PictureBox114 As PictureBox
    Friend WithEvents PictureBox104 As PictureBox
    Friend WithEvents PictureBox94 As PictureBox
    Friend WithEvents PictureBox84 As PictureBox
    Friend WithEvents PictureBox74 As PictureBox
    Friend WithEvents PictureBox64 As PictureBox
    Friend WithEvents PictureBox54 As PictureBox
    Friend WithEvents PictureBox44 As PictureBox
    Friend WithEvents PictureBox34 As PictureBox
    Friend WithEvents PictureBox113 As PictureBox
    Friend WithEvents PictureBox103 As PictureBox
    Friend WithEvents PictureBox93 As PictureBox
    Friend WithEvents PictureBox83 As PictureBox
    Friend WithEvents PictureBox73 As PictureBox
    Friend WithEvents PictureBox63 As PictureBox
    Friend WithEvents PictureBox53 As PictureBox
    Friend WithEvents PictureBox43 As PictureBox
    Friend WithEvents PictureBox33 As PictureBox
    Friend WithEvents PictureBox112 As PictureBox
    Friend WithEvents PictureBox102 As PictureBox
    Friend WithEvents PictureBox92 As PictureBox
    Friend WithEvents PictureBox82 As PictureBox
    Friend WithEvents PictureBox72 As PictureBox
    Friend WithEvents PictureBox62 As PictureBox
    Friend WithEvents PictureBox52 As PictureBox
    Friend WithEvents PictureBox42 As PictureBox
    Friend WithEvents PictureBox32 As PictureBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Button5 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents TextBox127 As TextBox
    Friend WithEvents TextBox128 As TextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents Label17 As Label
End Class
