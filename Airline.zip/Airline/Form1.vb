﻿Public Class Form1
    Dim _Araay(4, 3) As String
    Dim I As Integer
    Dim J As Integer
    Dim count As Integer = 0
    Dim _Araay2(99) As String
    Dim eco_index As Integer
    Dim eco_count As Integer = 0
    Private Sub TabPage1_Click_1(sender As Object, e As EventArgs) Handles TabPage1.Click

    End Sub
    Private Sub PictureBox1_Click_1(sender As Object, e As EventArgs) Handles PictureBox1.Click


        count = 1
        If _Araay(0, 0) = "" Then

            Check_input2()
            Position2()
        Else
            delet2()
        End If

    End Sub
    Private Sub PictureBox2_Click_1(sender As Object, e As EventArgs) Handles PictureBox2.Click
        count = 5
        If _Araay(1, 0) = "" Then

            Check_input2()
            Position2() '
        Else
            delet2()
        End If
    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        count = 9
        If _Araay(2, 0) = "" Then

            Check_input2()
            Position2()
        Else
            delet2()
        End If
    End Sub

    Private Sub PictureBox4_Click(sender As Object, e As EventArgs) Handles PictureBox4.Click
        count = 13
        If _Araay(3, 0) = "" Then

            Check_input2()
            Position2()
        Else
            delet2()
        End If
    End Sub

    Private Sub PictureBox5_Click(sender As Object, e As EventArgs) Handles PictureBox5.Click
        count = 17
        If _Araay(4, 0) = "" Then

            Check_input2()
            Position2()
        Else
            delet2()
        End If
    End Sub
    Private Sub PictureBox6_Click_1(sender As Object, e As EventArgs) Handles PictureBox6.Click
        count = 2
        If _Araay(0, 1) = "" Then

            Check_input2()
            Position2()
        Else
            delet2()
        End If
    End Sub

    Private Sub PictureBox7_Click(sender As Object, e As EventArgs) Handles PictureBox7.Click
        count = 6
        If _Araay(1, 1) = "" Then

            Check_input2()
            Position2() '
        Else
            delet2()
        End If
    End Sub

    Private Sub PictureBox8_Click(sender As Object, e As EventArgs) Handles PictureBox8.Click
        count = 10
        If _Araay(2, 1) = "" Then

            Check_input2()
            Position2()
        Else
            delet2()
        End If
    End Sub

    Private Sub PictureBox9_Click(sender As Object, e As EventArgs) Handles PictureBox9.Click
        count = 14
        If _Araay(3, 1) = "" Then

            Check_input2()
            Position2()
        Else
            delet2()
        End If
    End Sub
    Private Sub PictureBox10_Click(sender As Object, e As EventArgs) Handles PictureBox10.Click
        count = 18
        If _Araay(4, 1) = "" Then

            Check_input2()
            Position2()
        Else
            delet2()
        End If
    End Sub

    Private Sub PictureBox11_Click(sender As Object, e As EventArgs) Handles PictureBox11.Click
        count = 3
        If _Araay(0, 2) = "" Then

            Check_input2()
            Position2()
        Else
            delet2()
        End If
    End Sub


    Private Sub PictureBox16_Click(sender As Object, e As EventArgs) Handles PictureBox16.Click
        count = 4
        If _Araay(0, 3) = "" Then

            Check_input2()
            Position2()
        Else
            delet2()
        End If
    End Sub
    Private Sub PictureBox12_Click(sender As Object, e As EventArgs) Handles PictureBox12.Click
        count = 7
        If _Araay(1, 2) = "" Then

            Check_input2()
            Position2()


        Else
            delet2()
        End If
    End Sub
    Private Sub PictureBox17_Click(sender As Object, e As EventArgs) Handles PictureBox17.Click
        count = 8
        If _Araay(1, 3) = "" Then

            Check_input2()
            Position2()
        Else
            delet2()
        End If
    End Sub
    Private Sub PictureBox13_Click(sender As Object, e As EventArgs) Handles PictureBox13.Click
        count = 11
        If _Araay(2, 2) = "" Then

            Check_input2()
            Position2()
        Else
            delet2()
        End If
    End Sub
    Private Sub PictureBox18_Click(sender As Object, e As EventArgs) Handles PictureBox18.Click
        count = 12
        If _Araay(2, 3) = "" Then

            Check_input2()
            Position2()
        Else
            delet2()
        End If
    End Sub

    Private Sub PictureBox14_Click(sender As Object, e As EventArgs) Handles PictureBox14.Click
        count = 15
        If _Araay(3, 2) = "" Then

            Check_input2()
            Position2()
        Else
            delet2()
        End If
    End Sub

    Private Sub PictureBox19_Click(sender As Object, e As EventArgs) Handles PictureBox19.Click
        count = 16
        If _Araay(3, 3) = "" Then

            Check_input2()
            Position2()
        Else
            delet2()
        End If
    End Sub

    Private Sub PictureBox15_Click(sender As Object, e As EventArgs) Handles PictureBox15.Click
        count = 19
        If _Araay(4, 2) = "" Then

            Check_input2()
            Position2()
        Else
            delet2()
        End If
    End Sub

    Private Sub PictureBox20_Click(sender As Object, e As EventArgs) Handles PictureBox20.Click
        count = 20
        If _Araay(4, 3) = "" Then

            Check_input2()
            Position2()
        Else
            delet2()
        End If

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim ii As String = TextBox2.Text
        Dim jj As String = TextBox3.Text
        Dim count As Integer = 0
        Dim R(ii, jj) As String
        If 4 < ii Or 3 < jj Or 0 > ii Or 0 > jj Then
            MessageBox.Show("Error")
        Else
            For I = 0 To 4
                For J = 0 To 3
                    count = count + 1
                    If I = ii And J = jj And _Araay(I, J) <> "" Then
                        _Araay(I, J) = ""
                        If count = 1 Then

                            PictureBox1.Image = Image.FromFile("C:\pic2\Business.jpeg")
                            TextBox6.Text = ""
                            _Araay(I, J) = ""
                        ElseIf count = 2 Then
                            PictureBox6.Image = Image.FromFile("C:\pic2\Business.jpeg")
                            TextBox7.Text = ""
                            _Araay(I, J) = ""
                        ElseIf count = 3 Then
                            PictureBox11.Image = Image.FromFile("C:\pic2\Business.jpeg")
                            TextBox8.Text = ""
                            _Araay(I, J) = ""
                        ElseIf count = 4 Then
                            PictureBox16.Image = Image.FromFile("C:\pic2\Business.jpeg")
                            TextBox9.Text = ""
                            _Araay(I, J) = ""
                        ElseIf count = 5 Then
                            PictureBox2.Image = Image.FromFile("C:\pic2\Business.jpeg")
                            TextBox10.Text = ""
                            _Araay(I, J) = ""
                        ElseIf count = 6 Then
                            PictureBox7.Image = Image.FromFile("C:\pic2\Business.jpeg")
                            TextBox11.Text = ""
                            _Araay(I, J) = ""
                        ElseIf count = 7 Then
                            PictureBox12.Image = Image.FromFile("C:\pic2\Business.jpeg")
                            TextBox12.Text = ""
                            _Araay(I, J) = ""
                        ElseIf count = 8 Then
                            PictureBox17.Image = Image.FromFile("C:\pic2\Business.jpeg")
                            TextBox13.Text = ""
                            _Araay(I, J) = ""
                        ElseIf count = 9 Then
                            PictureBox3.Image = Image.FromFile("C:\pic2\Business.jpeg")
                            TextBox14.Text = ""
                            _Araay(I, J) = ""
                        ElseIf count = 10 Then
                            PictureBox8.Image = Image.FromFile("C:\pic2\Business.jpeg")
                            TextBox15.Text = ""
                            _Araay(I, J) = ""
                        ElseIf count = 11 Then
                            PictureBox13.Image = Image.FromFile("C:\pic2\Business.jpeg")
                            TextBox16.Text = ""
                            _Araay(I, J) = ""
                        ElseIf count = 12 Then
                            PictureBox18.Image = Image.FromFile("C:\pic2\Business.jpeg")
                            TextBox17.Text = ""
                            _Araay(I, J) = ""
                        ElseIf count = 13 Then
                            PictureBox4.Image = Image.FromFile("C:\pic2\Business.jpeg")
                            TextBox18.Text = ""
                            _Araay(I, J) = ""
                        ElseIf count = 14 Then
                            PictureBox9.Image = Image.FromFile("C:\pic2\Business.jpeg")
                            TextBox19.Text = ""
                            _Araay(I, J) = ""
                        ElseIf count = 15 Then
                            PictureBox14.Image = Image.FromFile("C:\pic2\Business.jpeg")
                            TextBox20.Text = ""
                            _Araay(I, J) = ""
                        ElseIf count = 16 Then
                            PictureBox19.Image = Image.FromFile("C:\pic2\Business.jpeg")
                            TextBox21.Text = ""
                            _Araay(I, J) = ""
                        ElseIf count = 17 Then
                            PictureBox5.Image = Image.FromFile("C:\pic2\Business.jpeg")
                            TextBox22.Text = ""
                            _Araay(I, J) = ""
                        ElseIf count = 18 Then
                            PictureBox10.Image = Image.FromFile("C:\pic2\Business.jpeg")
                            TextBox23.Text = ""
                            _Araay(I, J) = ""
                        ElseIf count = 19 Then
                            PictureBox15.Image = Image.FromFile("C:\pic2\Business.jpeg")
                            TextBox24.Text = ""
                            _Araay(I, J) = ""
                        ElseIf count = 20 Then
                            PictureBox20.Image = Image.FromFile("C:\pic2\Business.jpeg")
                            TextBox25.Text = ""
                            _Araay(I, J) = ""
                        End If
                        MessageBox.Show("Cancel")
                    End If
                Next
            Next
        End If
        RichTextBox1.Text = Space(25) & "ACME airlines" & vbCrLf & Space(6) & "Wellcome to  for reserving seats" & vbCrLf & TextBox6.Text & Space(2) & TextBox7.Text & Space(2) & TextBox8.Text & Space(2) & TextBox9.Text & Space(2) & TextBox10.Text & Space(2) & TextBox11.Text & Space(2) & TextBox12.Text & Space(2) & TextBox13.Text & Space(2) & TextBox14.Text & Space(2) & TextBox15.Text & Space(2) & TextBox16.Text & Space(2) & TextBox17.Text & Space(2) & TextBox18.Text & Space(2) & TextBox19.Text & Space(2) & TextBox20.Text & Space(2) & TextBox21.Text & Space(2) & TextBox22.Text & Space(2) & TextBox23.Text & Space(2) & TextBox24.Text & Space(2) & TextBox25.Text


    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        count = 0
        For I = 0 To 4
            For J = 0 To 3
                count = count + 1
                _Araay(I, J) = ""
                If count = 1 Then

                    PictureBox1.Image = Image.FromFile("C:\pic2\Business.jpeg")
                    TextBox6.Text = ""
                    _Araay(I, J) = ""
                ElseIf count = 2 Then
                    PictureBox6.Image = Image.FromFile("C:\pic2\Business.jpeg")
                    TextBox7.Text = ""
                    _Araay(I, J) = ""
                ElseIf count = 3 Then
                    PictureBox11.Image = Image.FromFile("C:\pic2\Business.jpeg")
                    TextBox8.Text = ""
                    _Araay(I, J) = ""
                ElseIf count = 4 Then
                    PictureBox16.Image = Image.FromFile("C:\pic2\Business.jpeg")
                    TextBox9.Text = ""
                    _Araay(I, J) = ""
                ElseIf count = 5 Then
                    PictureBox2.Image = Image.FromFile("C:\pic2\Business.jpeg")
                    TextBox10.Text = ""
                    _Araay(I, J) = ""
                ElseIf count = 6 Then
                    PictureBox7.Image = Image.FromFile("C:\pic2\Business.jpeg")
                    TextBox11.Text = ""
                    _Araay(I, J) = ""
                ElseIf count = 7 Then
                    PictureBox12.Image = Image.FromFile("C:\pic2\Business.jpeg")
                    TextBox12.Text = ""
                    _Araay(I, J) = ""
                ElseIf count = 8 Then
                    PictureBox17.Image = Image.FromFile("C:\pic2\Business.jpeg")
                    TextBox13.Text = ""
                    _Araay(I, J) = ""
                ElseIf count = 9 Then
                    PictureBox3.Image = Image.FromFile("C:\pic2\Business.jpeg")
                    TextBox14.Text = ""
                    _Araay(I, J) = ""
                ElseIf count = 10 Then
                    PictureBox8.Image = Image.FromFile("C:\pic2\Business.jpeg")
                    TextBox15.Text = ""
                    _Araay(I, J) = ""
                ElseIf count = 11 Then
                    PictureBox13.Image = Image.FromFile("C:\pic2\Business.jpeg")
                    TextBox16.Text = ""
                    _Araay(I, J) = ""
                ElseIf count = 12 Then
                    PictureBox18.Image = Image.FromFile("C:\pic2\Business.jpeg")
                    TextBox17.Text = ""
                    _Araay(I, J) = ""
                ElseIf count = 13 Then
                    PictureBox4.Image = Image.FromFile("C:\pic2\Business.jpeg")
                    TextBox18.Text = ""
                    _Araay(I, J) = ""
                ElseIf count = 14 Then
                    PictureBox9.Image = Image.FromFile("C:\pic2\Business.jpeg")
                    TextBox19.Text = ""
                    _Araay(I, J) = ""
                ElseIf count = 15 Then
                    PictureBox14.Image = Image.FromFile("C:\pic2\Business.jpeg")
                    TextBox20.Text = ""
                    _Araay(I, J) = ""
                ElseIf count = 16 Then
                    PictureBox19.Image = Image.FromFile("C:\pic2\Business.jpeg")
                    TextBox21.Text = ""
                    _Araay(I, J) = ""
                ElseIf count = 17 Then
                    PictureBox5.Image = Image.FromFile("C:\pic2\Business.jpeg")
                    TextBox22.Text = ""
                    _Araay(I, J) = ""
                ElseIf count = 18 Then
                    PictureBox10.Image = Image.FromFile("C:\pic2\Business.jpeg")
                    TextBox23.Text = ""
                    _Araay(I, J) = ""
                ElseIf count = 19 Then
                    PictureBox15.Image = Image.FromFile("C:\pic2\Business.jpeg")
                    TextBox24.Text = ""
                    _Araay(I, J) = ""
                ElseIf count = 20 Then
                    PictureBox20.Image = Image.FromFile("C:\pic2\Business.jpeg")
                    TextBox25.Text = ""
                    _Araay(I, J) = ""
                End If
            Next
        Next
        MessageBox.Show("Cancel All !")

        RichTextBox1.Text = Space(25) & "ACME airlines" & vbCrLf & Space(6) & "Wellcome to  for reserving seats" & vbCrLf & TextBox6.Text & Space(2) & TextBox7.Text & Space(2) & TextBox8.Text & Space(2) & TextBox9.Text & Space(2) & TextBox10.Text & Space(2) & TextBox11.Text & Space(2) & TextBox12.Text & Space(2) & TextBox13.Text & Space(2) & TextBox14.Text & Space(2) & TextBox15.Text & Space(2) & TextBox16.Text & Space(2) & TextBox17.Text & Space(2) & TextBox18.Text & Space(2) & TextBox19.Text & Space(2) & TextBox20.Text & Space(2) & TextBox21.Text & Space(2) & TextBox22.Text & Space(2) & TextBox23.Text & Space(2) & TextBox24.Text & Space(2) & TextBox25.Text
    End Sub
    Private Sub Button3_Click_1(sender As Object, e As EventArgs) Handles Button3.Click
        Check_input()
        Position()
    End Sub
    Sub Check_input2()

        If TextBox1.Text = "" Then
            MessageBox.Show("Input Your Info", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else

            MessageBox.Show("Your Input is Correct information", "Checked the input", MessageBoxButtons.OK, MessageBoxIcon.Information)

        End If
    End Sub
    Sub Position2()


        If count = 1 And _Araay(0, 0) = "" Then

            PictureBox1.Image = Image.FromFile("C:\pic2\XBusiness.jpeg")
            TextBox6.Text = TextBox1.Text & "(0, 0) "
            _Araay(0, 0) = "1"
        ElseIf count = 2 And _Araay(0, 1) = "" Then
            PictureBox6.Image = Image.FromFile("C:\pic2\XBusiness.jpeg")
            TextBox7.Text = TextBox1.Text & "(0, 1) "
            _Araay(0, 1) = "2"
        ElseIf count = 3 And _Araay(0, 2) = "" Then
            PictureBox11.Image = Image.FromFile("C:\pic2\XBusiness.jpeg")
            TextBox8.Text = TextBox1.Text & "(0, 2) "
            _Araay(0, 2) = "3"
        ElseIf count = 4 And _Araay(0, 3) = "" Then
            PictureBox16.Image = Image.FromFile("C:\pic2\XBusiness.jpeg")
            TextBox9.Text = TextBox1.Text & "(0, 3) "
            _Araay(0, 3) = "4"
        ElseIf count = 5 And _Araay(1, 0) = "" Then
            PictureBox2.Image = Image.FromFile("C:\pic2\XBusiness.jpeg")
            TextBox10.Text = TextBox1.Text & "(1, 0) "
            _Araay(1, 0) = "5"
        ElseIf count = 6 And _Araay(1, 1) = "" Then
            PictureBox7.Image = Image.FromFile("C:\pic2\XBusiness.jpeg")
            TextBox11.Text = TextBox1.Text & "(1, 1) "
            _Araay(1, 1) = "6"
        ElseIf count = 7 And _Araay(1, 2) = "" Then
            PictureBox12.Image = Image.FromFile("C:\pic2\XBusiness.jpeg")
            TextBox12.Text = TextBox1.Text & "(1, 2) "
            _Araay(1, 2) = "7"
        ElseIf count = 8 And _Araay(1, 3) = "" Then
            PictureBox17.Image = Image.FromFile("C:\pic2\XBusiness.jpeg")
            TextBox13.Text = TextBox1.Text & "(1, 3) "
            _Araay(1, 3) = "8"
        ElseIf count = 9 And _Araay(2, 0) = "" Then
            PictureBox3.Image = Image.FromFile("C:\pic2\XBusiness.jpeg")
            TextBox14.Text = TextBox1.Text & "(2, 0) "
            _Araay(2, 0) = "9"
        ElseIf count = 10 And _Araay(2, 1) = "" Then
            PictureBox8.Image = Image.FromFile("C:\pic2\XBusiness.jpeg")
            TextBox15.Text = TextBox1.Text & "(2, 1) "
            _Araay(2, 1) = "10"
        ElseIf count = 11 And _Araay(2, 2) = "" Then
            PictureBox13.Image = Image.FromFile("C:\pic2\XBusiness.jpeg")
            TextBox16.Text = TextBox1.Text & "(2, 2) "
            _Araay(2, 2) = "11"
        ElseIf count = 12 And _Araay(2, 3) = "" Then
            PictureBox18.Image = Image.FromFile("C:\pic2\XBusiness.jpeg")
            TextBox17.Text = TextBox1.Text & "(2, 3) "
            _Araay(2, 3) = "12"
        ElseIf count = 13 And _Araay(3, 0) = "" Then
            PictureBox4.Image = Image.FromFile("C:\pic2\XBusiness.jpeg")
            TextBox18.Text = TextBox1.Text & "(3, 0) "
            _Araay(3, 0) = "13"
        ElseIf count = 14 And _Araay(3, 1) = "" Then
            PictureBox9.Image = Image.FromFile("C:\pic2\XBusiness.jpeg")
            TextBox19.Text = TextBox1.Text & "(3, 1) "
            _Araay(3, 1) = "14"
        ElseIf count = 15 And _Araay(3, 2) = "" Then
            PictureBox14.Image = Image.FromFile("C:\pic2\XBusiness.jpeg")
            TextBox20.Text = TextBox1.Text & "(3, 2) "
            _Araay(3, 2) = "15"
        ElseIf count = 16 And _Araay(3, 3) = "" Then
            PictureBox19.Image = Image.FromFile("C:\pic2\XBusiness.jpeg")
            TextBox21.Text = TextBox1.Text & "(3, 3) "
            _Araay(3, 3) = "16"
        ElseIf count = 17 And _Araay(4, 0) = "" Then
            PictureBox5.Image = Image.FromFile("C:\pic2\XBusiness.jpeg")
            TextBox22.Text = TextBox1.Text & "(4, 0) "
            _Araay(4, 0) = "17"
        ElseIf count = 18 And _Araay(4, 1) = "" Then
            PictureBox10.Image = Image.FromFile("C:\pic2\XBusiness.jpeg")
            TextBox23.Text = TextBox1.Text & "(4, 1) "
            _Araay(4, 1) = "18"
        ElseIf count = 19 And _Araay(4, 2) = "" Then
            PictureBox15.Image = Image.FromFile("C:\pic2\XBusiness.jpeg")
            TextBox24.Text = TextBox1.Text & "(4, 2) "
            _Araay(4, 2) = "19"
        ElseIf count = 20 And _Araay(4, 3) = "" Then
            PictureBox20.Image = Image.FromFile("C:\pic2\XBusiness.jpeg")
            TextBox25.Text = TextBox1.Text & "(4, 3) "
            _Araay(4, 3) = "20"

        Else
            MessageBox.Show(" Sorry, The Seat is  NOT  available ", "Booking information", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If
        MessageBox.Show(" Yes, The Seat is available" & vbCrLf & " You have reserved the seat " & count, "Booking information", MessageBoxButtons.OK, MessageBoxIcon.Information)


        RichTextBox1.Text = Space(25) & "ACME airlines" & vbCrLf & Space(6) & "Wellcome to  for reserving seats" & vbCrLf & TextBox6.Text & Space(2) & TextBox7.Text & Space(2) & TextBox8.Text & Space(2) & TextBox9.Text & Space(2) & TextBox10.Text & Space(2) & TextBox11.Text & Space(2) & TextBox12.Text & Space(2) & TextBox13.Text & Space(2) & TextBox14.Text & Space(2) & TextBox15.Text & Space(2) & TextBox16.Text & Space(2) & TextBox17.Text & Space(2) & TextBox18.Text & Space(2) & TextBox19.Text & Space(2) & TextBox20.Text & Space(2) & TextBox21.Text & Space(2) & TextBox22.Text & Space(2) & TextBox23.Text & Space(2) & TextBox24.Text & Space(2) & TextBox25.Text
    End Sub
    Sub Check_input()
        Dim ii As String = TextBox4.Text
        Dim jj As String = TextBox5.Text
        If TextBox4.Text = "" Or TextBox5.Text = "" Or TextBox1.Text = "" Then
            MessageBox.Show("Input Your Info", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Else
            If 4 <ii Or 3 <jj Or 0 > ii Or 0 > jj Then
                MessageBox.Show("out of My Array ( Raw,Column) ", "Checked the input", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Else
                MessageBox.Show("Your Input is Correct information", "Checked the input", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        End If
    End Sub
    Sub Position()
        Dim ii As String = TextBox4.Text
        Dim jj As String = TextBox5.Text
        Dim index1 As Integer
        Dim index2 As Integer
        index1 = Convert.ToInt32(ii)
        index2 = Convert.ToInt32(jj)
        Dim count As Integer = 0
        For I = 0 To 4
            For J = 0 To 3
                count += 1
                If I = index1 And J = index2 Then
                    If _Araay(I, J) = "" Then
                        MessageBox.Show(" Yes, The Seat is available" & vbCrLf & " You have reserved the seat " & count, "Booking information", MessageBoxButtons.OK, MessageBoxIcon.Information)

                        If count = 1 Then

                            PictureBox1.Image = Image.FromFile("C:\pic2\XBusiness.jpeg")
                            TextBox6.Text = TextBox1.Text & " ( " & I & "," & J & ")"
                            _Araay(I, J) = "1"
                        ElseIf count = 2 Then
                            PictureBox6.Image = Image.FromFile("C:\pic2\XBusiness.jpeg")
                            TextBox7.Text = TextBox1.Text & " ( " & I & "," & J & ")"
                            _Araay(I, J) = "2"
                        ElseIf count = 3 Then
                            PictureBox11.Image = Image.FromFile("C:\pic2\XBusiness.jpeg")
                            TextBox8.Text = TextBox1.Text & " ( " & I & "," & J & ")"
                            _Araay(I, J) = "3"
                        ElseIf count = 4 Then
                            PictureBox16.Image = Image.FromFile("C:\pic2\XBusiness.jpeg")
                            TextBox9.Text = TextBox1.Text & " ( " & I & "," & J & ")"
                            _Araay(I, J) = "4"
                        ElseIf count = 5 Then
                            PictureBox2.Image = Image.FromFile("C:\pic2\XBusiness.jpeg")
                            TextBox10.Text = TextBox1.Text & " ( " & I & "," & J & ")"
                            _Araay(I, J) = "5"
                        ElseIf count = 6 Then
                            PictureBox7.Image = Image.FromFile("C:\pic2\XBusiness.jpeg")
                            TextBox11.Text = TextBox1.Text & " ( " & I & "," & J & ")"
                            _Araay(I, J) = "6"
                        ElseIf count = 7 Then
                            PictureBox12.Image = Image.FromFile("C:\pic2\XBusiness.jpeg")
                            TextBox12.Text = TextBox1.Text & " ( " & I & "," & J & ")"
                            _Araay(I, J) = "7"
                        ElseIf count = 8 Then
                            PictureBox17.Image = Image.FromFile("C:\pic2\XBusiness.jpeg")
                            TextBox13.Text = TextBox1.Text & " ( " & I & "," & J & ")"
                            _Araay(I, J) = "8"
                        ElseIf count = 9 Then
                            PictureBox3.Image = Image.FromFile("C:\pic2\XBusiness.jpeg")
                            TextBox14.Text = TextBox1.Text & " ( " & I & "," & J & ")"
                            _Araay(I, J) = "9"
                        ElseIf count = 10 Then
                            PictureBox8.Image = Image.FromFile("C:\pic2\XBusiness.jpeg")
                            TextBox15.Text = TextBox1.Text & " ( " & I & "," & J & ")"
                            _Araay(I, J) = "10"
                        ElseIf count = 11 Then
                            PictureBox13.Image = Image.FromFile("C:\pic2\XBusiness.jpeg")
                            TextBox16.Text = TextBox1.Text & " ( " & I & "," & J & ")"
                            _Araay(I, J) = "11"
                        ElseIf count = 12 Then
                            PictureBox18.Image = Image.FromFile("C:\pic2\XBusiness.jpeg")
                            TextBox17.Text = TextBox1.Text & " ( " & I & "," & J & ")"
                            _Araay(I, J) = "12"
                        ElseIf count = 13 Then
                            PictureBox4.Image = Image.FromFile("C:\pic2\XBusiness.jpeg")
                            TextBox18.Text = TextBox1.Text & " ( " & I & "," & J & ")"
                            _Araay(I, J) = "13"
                        ElseIf count = 14 Then
                            PictureBox9.Image = Image.FromFile("C:\pic2\XBusiness.jpeg")
                            TextBox19.Text = TextBox1.Text & " ( " & I & "," & J & ")"
                            _Araay(I, J) = "14"
                        ElseIf count = 15 Then
                            PictureBox14.Image = Image.FromFile("C:\pic2\XBusiness.jpeg")
                            TextBox20.Text = TextBox1.Text & " ( " & I & "," & J & ")"
                            _Araay(I, J) = "15"
                        ElseIf count = 16 Then
                            PictureBox19.Image = Image.FromFile("C:\pic2\XBusiness.jpeg")
                            TextBox21.Text = TextBox1.Text & " ( " & I & "," & J & ")"
                            _Araay(I, J) = "16"
                        ElseIf count = 17 Then
                            PictureBox5.Image = Image.FromFile("C:\pic2\XBusiness.jpeg")
                            TextBox22.Text = TextBox1.Text & " ( " & I & "," & J & ")"
                            _Araay(I, J) = "17"
                        ElseIf count = 18 Then
                            PictureBox10.Image = Image.FromFile("C:\pic2\XBusiness.jpeg")
                            TextBox23.Text = TextBox1.Text & " ( " & I & "," & J & ")"
                            _Araay(I, J) = "18"
                        ElseIf count = 19 Then
                            PictureBox15.Image = Image.FromFile("C:\pic2\XBusiness.jpeg")
                            TextBox24.Text = TextBox1.Text & " ( " & I & "," & J & ")"
                            _Araay(I, J) = "19"
                        ElseIf count = 20 Then
                            PictureBox20.Image = Image.FromFile("C:\pic2\XBusiness.jpeg")
                            TextBox25.Text = TextBox1.Text & " ( " & I & "," & J & ")"
                            _Araay(I, J) = "20"
                        End If
                    Else
                        MessageBox.Show(" Sorry, The Seat is  NOT  available ", "Booking information", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End If
                End If
            Next
        Next
        RichTextBox1.Text = Space(25) & "ACME airlines" & vbCrLf & Space(6) & "Wellcome to  for reserving seats" & vbCrLf & TextBox6.Text & Space(2) & TextBox7.Text & Space(2) & TextBox8.Text & Space(2) & TextBox9.Text & Space(2) & TextBox10.Text & Space(2) & TextBox11.Text & Space(2) & TextBox12.Text & Space(2) & TextBox13.Text & Space(2) & TextBox14.Text & Space(2) & TextBox15.Text & Space(2) & TextBox16.Text & Space(2) & TextBox17.Text & Space(2) & TextBox18.Text & Space(2) & TextBox19.Text & Space(2) & TextBox20.Text & Space(2) & TextBox21.Text & Space(2) & TextBox22.Text & Space(2) & TextBox23.Text & Space(2) & TextBox24.Text & Space(2) & TextBox25.Text
    End Sub

    Sub delet2()


        If count = 1 And TextBox6.Text <> "" Then

            If TextBox6.Text <> TextBox1.Text & "(0, 0) " Then
                MessageBox.Show("You can NOT delete , Sorry, You can Not cancel - check the name ")
            Else
                PictureBox1.Image = Image.FromFile("C:\pic2\Business.jpeg")
                TextBox6.Text = ""
                _Araay(0, 0) = ""
            End If
        ElseIf count = 2 And _Araay(0, 1) <> "" Then
            If TextBox7.Text <> TextBox1.Text & "(0, 1) " Then
                MessageBox.Show("You can NOT delete , Sorry, You can Not cancel - check the name ")
            Else
                PictureBox6.Image = Image.FromFile("C:\pic2\Business.jpeg")
                TextBox7.Text = ""
                _Araay(0, 1) = ""
            End If
        ElseIf count = 3 And _Araay(0, 2) <> "" Then
            If TextBox8.Text = TextBox1.Text & "(0, 2)" Then
                MessageBox.Show("You can NOT delete , Sorry, You can Not cancel - check the name ")
            Else
                PictureBox11.Image = Image.FromFile("C:\pic2\Business.jpeg")
                TextBox8.Text = ""
                _Araay(0, 2) = ""
            End If
        ElseIf count = 4 And _Araay(0, 3) <> "" Then
            If TextBox9.Text <> TextBox1.Text & "(0, 3) " Then
                MessageBox.Show("You can NOT delete , Sorry, You can Not cancel - check the name ")
            Else
                PictureBox16.Image = Image.FromFile("C:\pic2\Business.jpeg")
                TextBox9.Text = ""
                _Araay(0, 3) = "4"
            End If
        ElseIf count = 5 And _Araay(1, 0) <> "" Then
            If TextBox10.Text <> TextBox1.Text & "(1, 0) " Then
                MessageBox.Show("You can NOT delete , Sorry, You can Not cancel - check the name ")
            Else
                PictureBox2.Image = Image.FromFile("C:\pic2\Business.jpeg")
                TextBox10.Text = ""
                _Araay(1, 0) = ""
            End If
        ElseIf count = 6 And _Araay(1, 1) <> "" Then

            If TextBox11.Text <> TextBox1.Text & "(1, 1) " Then
                MessageBox.Show("You can NOT delete , Sorry, You can Not cancel - check the name ")
            Else
                PictureBox7.Image = Image.FromFile("C:\pic2\Business.jpeg")
                TextBox11.Text = ""
                _Araay(1, 1) = ""
            End If
        ElseIf count = 7 And _Araay(1, 2) <> "" Then
            If TextBox12.Text <> TextBox1.Text & "(1, 2) " Then
                MessageBox.Show("You can NOT delete , Sorry, You can Not cancel - check the name ")
            Else
                PictureBox12.Image = Image.FromFile("C:\pic2\Business.jpeg")
                TextBox12.Text = ""
                _Araay(1, 2) = ""
            End If
        ElseIf count = 8 And _Araay(1, 3) <> "" Then
            If TextBox13.Text <> TextBox1.Text & "(1, 3)" Then
                MessageBox.Show("You can NOT delete , Sorry, You can Not cancel - check the name ")
            Else
                PictureBox17.Image = Image.FromFile("C:\pic2\Business.jpeg")
                TextBox13.Text = ""
                _Araay(1, 3) = ""
            End If
        ElseIf count = 9 And _Araay(2, 0) <> "" Then
            If TextBox14.Text <> TextBox1.Text & "(2, 0) " Then
                MessageBox.Show("You can NOT delete , Sorry, You can Not cancel - check the name ")
            Else
                PictureBox3.Image = Image.FromFile("C:\pic2\Business.jpeg")
                TextBox14.Text = ""
                _Araay(2, 0) = ""
            End If
        ElseIf count = 10 And _Araay(2, 1) <> "" Then
            If TextBox15.Text <> TextBox1.Text & "(2, 1) " Then
                MessageBox.Show("You can NOT delete , Sorry, You can Not cancel - check the name ")
            Else
                PictureBox8.Image = Image.FromFile("C:\pic2\Business.jpeg")
                TextBox15.Text = ""
                _Araay(2, 1) = ""
            End If
        ElseIf count = 11 And _Araay(2, 2) <> "" Then
            If TextBox16.Text <> TextBox1.Text & "(2, 2) " Then
                MessageBox.Show("You can NOT delete , Sorry, You can Not cancel - check the name ")
            Else
                PictureBox13.Image = Image.FromFile("C:\pic2\Business.jpeg")
                TextBox16.Text = ""
                _Araay(2, 2) = ""
            End If
        ElseIf count = 12 And _Araay(2, 3) <> "" Then
            If TextBox17.Text <> TextBox1.Text & "(2, 3) " Then
                MessageBox.Show("You can NOT delete , Sorry, You can Not cancel - check the name ")
            Else
                PictureBox18.Image = Image.FromFile("C:\pic2\Business.jpeg")
                TextBox17.Text = ""
                _Araay(2, 3) = ""
            End If
        ElseIf count = 13 And _Araay(3, 0) <> "" Then
            If TextBox18.Text <> TextBox1.Text & "(3, 0) " Then
                MessageBox.Show("You can NOT delete , Sorry, You can Not cancel - check the name ")
            Else
                PictureBox4.Image = Image.FromFile("C:\pic2\Business.jpeg")
                TextBox18.Text = ""
                _Araay(3, 0) = ""
            End If
        ElseIf count = 14 And _Araay(3, 1) <> "" Then
            If TextBox19.Text <> TextBox1.Text & "(3, 1) " Then
                MessageBox.Show("You can NOT delete , Sorry, You can Not cancel - check the name ")
            Else
                PictureBox9.Image = Image.FromFile("C:\pic2\Business.jpeg")
                TextBox19.Text = ""
                _Araay(3, 1) = ""
            End If
        ElseIf count = 15 And _Araay(3, 2) <> "" Then
            If TextBox20.Text <> TextBox1.Text & "(3, 2) " Then
                MessageBox.Show("You can NOT delete , Sorry, You can Not cancel - check the name ")
            Else
                PictureBox14.Image = Image.FromFile("C:\pic2\Business.jpeg")
                TextBox20.Text = ""
                _Araay(3, 2) = ""
            End If
        ElseIf count = 16 And _Araay(3, 3) <> "" Then
            If TextBox21.Text <> TextBox1.Text & "(3, 3) " Then
                MessageBox.Show("You can NOT delete , Sorry, You can Not cancel - check the name ")
            Else
                PictureBox19.Image = Image.FromFile("C:\pic2\Business.jpeg")
                TextBox21.Text = ""
                _Araay(3, 3) = ""
            End If
        ElseIf count = 17 And _Araay(4, 0) <> "" Then
            If TextBox22.Text <> TextBox1.Text & "(4, 0) " Then
                MessageBox.Show("You can NOT delete , Sorry, You can Not cancel - check the name ")
            Else
                PictureBox5.Image = Image.FromFile("C:\pic2\Business.jpeg")
                TextBox22.Text = ""
                _Araay(4, 0) = ""
            End If
        ElseIf count = 18 And _Araay(4, 1) <> "" Then
            If TextBox23.Text <> TextBox1.Text & "(4, 1) " Then
                MessageBox.Show("You can NOT delete , Sorry, You can Not cancel - check the name ")
            Else
                PictureBox10.Image = Image.FromFile("C:\pic2\Business.jpeg")
                TextBox23.Text = ""
                _Araay(4, 1) = ""
            End If
        ElseIf count = 19 And _Araay(4, 2) <> "" Then
            If TextBox24.Text <> TextBox1.Text & "(4, 2) " Then
                MessageBox.Show("You can NOT delete , Sorry, You can Not cancel - check the name ")
            Else
                PictureBox15.Image = Image.FromFile("C:\pic2\Business.jpeg")
                TextBox24.Text = ""
                _Araay(4, 2) = ""
            End If
        ElseIf count = 20 And _Araay(4, 3) <> "" Then
            If TextBox25.Text <> TextBox1.Text & "(4, 3) " Then
                MessageBox.Show("You can NOT delete , Sorry, You can Not cancel - check the name ")
            Else
                PictureBox20.Image = Image.FromFile("C:\pic2\Business.jpeg")
                TextBox25.Text = ""
                _Araay(4, 3) = ""
            End If
        Else
            MessageBox.Show(" Sorry, The Seat is  NOT  available ", "Booking information", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End If




        RichTextBox1.Text = Space(25) & "ACME airlines" & vbCrLf & Space(6) & "Wellcome to  for reserving seats" & vbCrLf & TextBox6.Text & Space(2) & TextBox7.Text & Space(2) & TextBox8.Text & Space(2) & TextBox9.Text & Space(2) & TextBox10.Text & Space(2) & TextBox11.Text & Space(2) & TextBox12.Text & Space(2) & TextBox13.Text & Space(2) & TextBox14.Text & Space(2) & TextBox15.Text & Space(2) & TextBox16.Text & Space(2) & TextBox17.Text & Space(2) & TextBox18.Text & Space(2) & TextBox19.Text & Space(2) & TextBox20.Text & Space(2) & TextBox21.Text & Space(2) & TextBox22.Text & Space(2) & TextBox23.Text & Space(2) & TextBox24.Text & Space(2) & TextBox25.Text
    End Sub

    Sub delet()
        Dim ii As String = TextBox4.Text
        Dim jj As String = TextBox5.Text
        Dim index1 As Integer
        Dim index2 As Integer
        index1 = Convert.ToInt32(ii)
        index2 = Convert.ToInt32(jj)
        Dim count As Integer = 0
        For I = 0 To 4
            For J = 0 To 3
                count += 1
                If I = index1 And J = index2 Then
                    If _Araay(I, J) <> "" Then
                        MessageBox.Show(" Yes, The Seat is it", "Booking information", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        If count = 1 Then

                            PictureBox1.Image = Image.FromFile("C:\pic2\Business.jpeg")
                            TextBox6.Text = ""
                            _Araay(I, J) = ""
                        ElseIf count = 2 Then
                            PictureBox6.Image = Image.FromFile("C:\pic2\Business.jpeg")
                            TextBox7.Text = ""
                            _Araay(I, J) = ""
                        ElseIf count = 3 Then
                            PictureBox11.Image = Image.FromFile("C:\pic2\Business.jpeg")
                            TextBox8.Text = ""
                            _Araay(I, J) = ""
                        ElseIf count = 4 Then
                            PictureBox16.Image = Image.FromFile("C:\pic2\Business.jpeg")
                            TextBox9.Text = ""
                            _Araay(I, J) = ""
                        ElseIf count = 5 Then
                            PictureBox2.Image = Image.FromFile("C:\pic2\Business.jpeg")
                            TextBox10.Text = ""
                            _Araay(I, J) = ""
                        ElseIf count = 6 Then
                            PictureBox7.Image = Image.FromFile("C:\pic2\Business.jpeg")
                            TextBox11.Text = ""
                            _Araay(I, J) = ""
                        ElseIf count = 7 Then
                            PictureBox12.Image = Image.FromFile("C:\pic2\Business.jpeg")
                            TextBox12.Text = ""
                            _Araay(I, J) = ""
                        ElseIf count = 8 Then
                            PictureBox17.Image = Image.FromFile("C:\pic2\Business.jpeg")
                            TextBox13.Text = ""
                            _Araay(I, J) = ""
                        ElseIf count = 9 Then
                            PictureBox3.Image = Image.FromFile("C:\pic2\Business.jpeg")
                            TextBox14.Text = ""
                            _Araay(I, J) = ""
                        ElseIf count = 10 Then
                            PictureBox8.Image = Image.FromFile("C:\pic2\Business.jpeg")
                            TextBox15.Text = ""
                            _Araay(I, J) = ""
                        ElseIf count = 11 Then
                            PictureBox13.Image = Image.FromFile("C:\pic2\Business.jpeg")
                            TextBox16.Text = ""
                            _Araay(I, J) = ""
                        ElseIf count = 12 Then
                            PictureBox18.Image = Image.FromFile("C:\pic2\Business.jpeg")
                            TextBox17.Text = ""
                            _Araay(I, J) = ""
                        ElseIf count = 13 Then
                            PictureBox4.Image = Image.FromFile("C:\pic2\Business.jpeg")
                            TextBox18.Text = ""
                            _Araay(I, J) = ""
                        ElseIf count = 14 Then
                            PictureBox9.Image = Image.FromFile("C:\pic2\Business.jpeg")
                            TextBox19.Text = ""
                            _Araay(I, J) = ""
                        ElseIf count = 15 Then
                            PictureBox14.Image = Image.FromFile("C:\pic2\Business.jpeg")
                            TextBox20.Text = ""
                            _Araay(I, J) = ""
                        ElseIf count = 16 Then
                            PictureBox19.Image = Image.FromFile("C:\pic2\Business.jpeg")
                            TextBox21.Text = ""
                            _Araay(I, J) = ""
                        ElseIf count = 17 Then
                            PictureBox5.Image = Image.FromFile("C:\pic2\Business.jpeg")
                            TextBox22.Text = ""
                            _Araay(I, J) = ""
                        ElseIf count = 18 Then
                            PictureBox10.Image = Image.FromFile("C:\pic2\Business.jpeg")
                            TextBox23.Text = ""
                            _Araay(I, J) = ""
                        ElseIf count = 19 Then
                            PictureBox15.Image = Image.FromFile("C:\pic2\Business.jpeg")
                            TextBox24.Text = ""
                            _Araay(I, J) = ""
                        ElseIf count = 20 Then
                            PictureBox20.Image = Image.FromFile("C:\pic2\Business.jpeg")
                            TextBox25.Text = ""
                            _Araay(I, J) = ""
                        End If
                    Else
                        MessageBox.Show(" Sorry, The Seat is  NOT  available ", "Booking information", MessageBoxButtons.OK, MessageBoxIcon.Error)

                    End If
                End If
            Next
        Next
        RichTextBox1.Text = Space(25) & "ACME airlines" & vbCrLf & Space(6) & "Wellcome to  for reserving seats" & vbCrLf & TextBox6.Text & Space(2) & TextBox7.Text & Space(2) & TextBox8.Text & Space(2) & TextBox9.Text & Space(2) & TextBox10.Text & Space(2) & TextBox11.Text & Space(2) & TextBox12.Text & Space(2) & TextBox13.Text & Space(2) & TextBox14.Text & Space(2) & TextBox15.Text & Space(2) & TextBox16.Text & Space(2) & TextBox17.Text & Space(2) & TextBox18.Text & Space(2) & TextBox19.Text & Space(2) & TextBox20.Text & Space(2) & TextBox21.Text & Space(2) & TextBox22.Text & Space(2) & TextBox23.Text & Space(2) & TextBox24.Text & Space(2) & TextBox25.Text

    End Sub

    Private Sub Button4_Click_1(sender As Object, e As EventArgs) Handles Button4.Click
        delet()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        For eco_index = 0 To 50
            eco_count = eco_count + 1
            _Araay2(eco_index) = ""
            If eco_count = 1 Then
                _Araay2(eco_index) = ""
                TextBox26.Text = ""
                PictureBox23.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 2 Then
                _Araay2(eco_index) = ""
                TextBox27.Text = ""
                PictureBox22.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 3 Then
                _Araay2(eco_index) = ""
                TextBox28.Text = ""
                PictureBox24.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 4 Then
                _Araay2(eco_index) = ""
                TextBox29.Text = ""
                PictureBox25.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 5 Then
                _Araay2(eco_index) = ""
                TextBox30.Text = ""
                PictureBox26.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 6 Then
                _Araay2(eco_index) = ""
                TextBox36.Text = ""
                PictureBox32.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 7 Then
                TextBox37.Text = ""
                _Araay2(eco_index) = ""
                PictureBox33.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 8 Then
                _Araay2(eco_index) = ""
                TextBox38.Text = ""
                PictureBox34.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 9 Then
                _Araay2(eco_index) = ""
                TextBox39.Text = ""
                PictureBox35.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 10 Then
                _Araay2(eco_index) = ""
                TextBox40.Text = ""
                PictureBox36.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 11 Then
                _Araay2(eco_index) = ""
                TextBox46.Text = ""
                PictureBox42.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 12 Then
                TextBox47.Text = ""
                _Araay2(eco_index) = ""
                PictureBox43.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 13 Then
                TextBox48.Text = ""
                _Araay2(eco_index) = ""
                PictureBox44.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 14 Then
                TextBox49.Text = ""
                _Araay2(eco_index) = ""
                PictureBox45.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 15 Then
                TextBox50.Text = ""
                _Araay2(eco_index) = ""
                PictureBox46.Image = Image.FromFile("C:\pic2\eco.jpeg")


            ElseIf eco_count = 16 Then
                TextBox56.Text = ""
                _Araay2(eco_index) = ""
                PictureBox52.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 17 Then
                TextBox57.Text = ""
                _Araay2(eco_index) = ""
                PictureBox53.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 18 Then
                TextBox58.Text = ""
                _Araay2(eco_index) = ""
                PictureBox54.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 19 Then
                TextBox59.Text = ""
                _Araay2(eco_index) = ""
                PictureBox55.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 20 Then
                TextBox60.Text = ""
                _Araay2(eco_index) = ""
                PictureBox56.Image = Image.FromFile("C:\pic2\eco.jpeg")

            ElseIf eco_count = 21 Then
                _Araay2(eco_index) = ""
                TextBox66.Text = ""
                PictureBox62.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 22 Then
                TextBox67.Text = ""
                _Araay2(eco_index) = ""
                PictureBox63.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 23 Then
                TextBox68.Text = ""
                _Araay2(eco_index) = ""
                PictureBox64.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 24 Then
                TextBox69.Text = ""
                _Araay2(eco_index) = ""
                PictureBox65.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 25 Then
                TextBox70.Text = ""
                _Araay2(eco_index) = ""
                PictureBox66.Image = Image.FromFile("C:\pic2\eco.jpeg")


            ElseIf eco_count = 26 Then
                TextBox76.Text = ""
                _Araay2(eco_index) = ""
                PictureBox72.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 27 Then
                TextBox77.Text = ""
                _Araay2(eco_index) = ""
                PictureBox73.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 28 Then
                TextBox78.Text = ""
                _Araay2(eco_index) = ""
                PictureBox74.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 29 Then
                TextBox79.Text = ""
                _Araay2(eco_index) = ""
                PictureBox75.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 30 Then
                TextBox80.Text = ""
                _Araay2(eco_index) = ""
                PictureBox76.Image = Image.FromFile("C:\pic2\eco.jpeg")


            ElseIf eco_count = 31 Then
                TextBox86.Text = ""
                _Araay2(eco_index) = ""
                PictureBox82.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 32 Then
                TextBox87.Text = ""
                _Araay2(eco_index) = ""
                PictureBox83.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 33 Then
                TextBox88.Text = ""
                _Araay2(eco_index) = ""
                PictureBox84.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 34 Then
                TextBox89.Text = ""
                _Araay2(eco_index) = ""
                PictureBox85.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 35 Then
                TextBox90.Text = ""
                _Araay2(eco_index) = ""
                PictureBox86.Image = Image.FromFile("C:\pic2\eco.jpeg")


            ElseIf eco_count = 36 Then
                TextBox96.Text = ""
                _Araay2(eco_index) = ""
                PictureBox92.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 37 Then
                TextBox97.Text = ""
                _Araay2(eco_index) = ""
                PictureBox93.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 38 Then
                TextBox98.Text = ""
                _Araay2(eco_index) = ""
                PictureBox94.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 39 Then
                TextBox99.Text = ""
                _Araay2(eco_index) = ""
                PictureBox95.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 40 Then
                TextBox100.Text = ""
                _Araay2(eco_index) = ""
                PictureBox96.Image = Image.FromFile("C:\pic2\eco.jpeg")

            ElseIf eco_count = 41 Then
                TextBox106.Text = ""
                _Araay2(eco_index) = ""
                PictureBox102.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 42 Then
                TextBox107.Text = ""
                _Araay2(eco_index) = ""
                PictureBox103.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 43 Then
                TextBox108.Text = ""
                _Araay2(eco_index) = ""
                PictureBox104.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 44 Then
                TextBox109.Text = ""
                _Araay2(eco_index) = ""
                PictureBox105.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 45 Then
                TextBox110.Text = ""

                _Araay2(eco_index) = ""
                PictureBox106.Image = Image.FromFile("C:\pic2\eco.jpeg")


            ElseIf eco_count = 46 Then
                TextBox116.Text = ""
                _Araay2(eco_index) = ""
                PictureBox112.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 47 Then
                TextBox117.Text = ""
                _Araay2(eco_index) = ""
                PictureBox113.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 48 Then
                TextBox118.Text = ""
                _Araay2(eco_index) = ""
                PictureBox114.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 49 Then
                TextBox119.Text = ""
                _Araay2(eco_index) = ""
                PictureBox115.Image = Image.FromFile("C:\pic2\eco.jpeg")
            ElseIf eco_count = 50 Then
                TextBox120.Text = ""
                _Araay2(eco_index) = ""
                PictureBox116.Image = Image.FromFile("C:\pic2\eco.jpeg")

            End If
        Next
        For I = 0 To 4
            For J = 0 To 3
                count = count + 1
                _Araay(I, J) = ""
                If count = 1 Then
                    _Araay(I, J) = ""
                    PictureBox1.Image = Image.FromFile("C:\pic2\Business.jpeg")
                ElseIf count = 2 Then
                    _Araay(I, J) = ""
                    PictureBox6.Image = Image.FromFile("C:\pic2\Business.jpeg")
                ElseIf count = 3 Then
                    PictureBox11.Image = Image.FromFile("C:\pic2\Business.jpeg")
                ElseIf count = 4 Then
                    PictureBox16.Image = Image.FromFile("C:\pic2\Business.jpeg")
                ElseIf count = 5 Then
                    PictureBox2.Image = Image.FromFile("C:\pic2\Business.jpeg")
                ElseIf count = 6 Then
                    PictureBox7.Image = Image.FromFile("C:\pic2\Business.jpeg")
                ElseIf count = 7 Then
                    PictureBox12.Image = Image.FromFile("C:\pic2\Business.jpeg")
                ElseIf count = 8 Then
                    PictureBox17.Image = Image.FromFile("C:\pic2\Business.jpeg")
                ElseIf count = 9 Then
                    PictureBox3.Image = Image.FromFile("C:\pic2\Business.jpeg")
                ElseIf count = 10 Then
                    PictureBox8.Image = Image.FromFile("C:\pic2\Business.jpeg")
                ElseIf count = 11 Then
                    PictureBox13.Image = Image.FromFile("C:\pic2\Business.jpeg")
                ElseIf count = 12 Then
                    PictureBox18.Image = Image.FromFile("C:\pic2\Business.jpeg")
                ElseIf count = 13 Then
                    PictureBox4.Image = Image.FromFile("C:\pic2\Business.jpeg")
                ElseIf count = 14 Then
                    PictureBox9.Image = Image.FromFile("C:\pic2\Business.jpeg")
                ElseIf count = 15 Then
                    PictureBox14.Image = Image.FromFile("C:\pic2\Business.jpeg")
                ElseIf count = 16 Then
                    PictureBox19.Image = Image.FromFile("C:\pic2\Business.jpeg")
                ElseIf count = 17 Then
                    PictureBox5.Image = Image.FromFile("C:\pic2\Business.jpeg")
                ElseIf count = 18 Then
                    PictureBox10.Image = Image.FromFile("C:\pic2\Business.jpeg")
                ElseIf count = 19 Then
                    PictureBox15.Image = Image.FromFile("C:\pic2\Business.jpeg")
                ElseIf count = 20 Then
                    PictureBox20.Image = Image.FromFile("C:\pic2\Business.jpeg")
                End If
            Next
        Next
    End Sub

    Private Sub Label5_Click(sender As Object, e As EventArgs) Handles Label5.Click

    End Sub

    Private Sub Eco_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Eco.SelectedIndexChanged

    End Sub

    Private Sub TextBox25_TextChanged(sender As Object, e As EventArgs) Handles TextBox25.TextChanged

    End Sub

    Private Sub TextBox24_TextChanged(sender As Object, e As EventArgs) Handles TextBox24.TextChanged

    End Sub

    Private Sub TextBox23_TextChanged(sender As Object, e As EventArgs) Handles TextBox23.TextChanged

    End Sub

    Private Sub TextBox22_TextChanged(sender As Object, e As EventArgs) Handles TextBox22.TextChanged

    End Sub

    Private Sub TextBox21_TextChanged(sender As Object, e As EventArgs) Handles TextBox21.TextChanged

    End Sub

    Private Sub TextBox20_TextChanged(sender As Object, e As EventArgs) Handles TextBox20.TextChanged

    End Sub

    Private Sub TextBox19_TextChanged(sender As Object, e As EventArgs) Handles TextBox19.TextChanged

    End Sub

    Private Sub TextBox18_TextChanged(sender As Object, e As EventArgs) Handles TextBox18.TextChanged

    End Sub

    Private Sub TextBox17_TextChanged(sender As Object, e As EventArgs) Handles TextBox17.TextChanged

    End Sub

    Private Sub TextBox16_TextChanged(sender As Object, e As EventArgs) Handles TextBox16.TextChanged

    End Sub

    Private Sub TextBox15_TextChanged(sender As Object, e As EventArgs) Handles TextBox15.TextChanged

    End Sub

    Private Sub TextBox14_TextChanged(sender As Object, e As EventArgs) Handles TextBox14.TextChanged

    End Sub

    Private Sub TextBox13_TextChanged(sender As Object, e As EventArgs) Handles TextBox13.TextChanged

    End Sub

    Private Sub TextBox12_TextChanged(sender As Object, e As EventArgs) Handles TextBox12.TextChanged

    End Sub

    Private Sub TextBox11_TextChanged(sender As Object, e As EventArgs) Handles TextBox11.TextChanged

    End Sub

    Private Sub TextBox10_TextChanged(sender As Object, e As EventArgs) Handles TextBox10.TextChanged

    End Sub

    Private Sub TextBox9_TextChanged(sender As Object, e As EventArgs) Handles TextBox9.TextChanged

    End Sub

    Private Sub TextBox8_TextChanged(sender As Object, e As EventArgs) Handles TextBox8.TextChanged

    End Sub

    Private Sub TextBox7_TextChanged(sender As Object, e As EventArgs) Handles TextBox7.TextChanged

    End Sub

    Private Sub TextBox6_TextChanged(sender As Object, e As EventArgs) Handles TextBox6.TextChanged

    End Sub

    Private Sub Label11_Click(sender As Object, e As EventArgs) Handles Label11.Click

    End Sub

    Private Sub TextBox5_TextChanged(sender As Object, e As EventArgs) Handles TextBox5.TextChanged

    End Sub

    Private Sub Label10_Click(sender As Object, e As EventArgs) Handles Label10.Click

    End Sub

    Private Sub TextBox4_TextChanged(sender As Object, e As EventArgs) Handles TextBox4.TextChanged

    End Sub

    Private Sub Label8_Click(sender As Object, e As EventArgs) Handles Label8.Click

    End Sub

    Private Sub Label7_Click(sender As Object, e As EventArgs) Handles Label7.Click

    End Sub

    Private Sub Label6_Click(sender As Object, e As EventArgs) Handles Label6.Click

    End Sub

    Private Sub TextBox3_TextChanged(sender As Object, e As EventArgs) Handles TextBox3.TextChanged

    End Sub

    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged

    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click

        Position3()
    End Sub

    Sub Position3()



        If TextBox128.Text = "" Then
            MessageBox.Show("Input Your Info (Name)", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        ElseIf TextBox127.Text = "" Then
            MessageBox.Show("Input Your Info (seat no.)", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        ElseIf TextBox127.Text > 51 Then
            MessageBox.Show("Input Your Info (seat no.) that's seat out of my array", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        Else
            For eco_index = 0 To 50
                eco_count = TextBox127.Text
                If eco_index = eco_count Then
                    If _Araay2(eco_index) = "" Then
                        MessageBox.Show(" Yes, The Seat is available" & vbCrLf & " You have reserved the seat " & eco_index, "Booking information", MessageBoxButtons.OK, MessageBoxIcon.Information)


                        If eco_count = 1 Then
                            _Araay2(eco_index) = "eco_count"
                            TextBox26.Text = TextBox128.Text
                            PictureBox23.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 2 Then
                            _Araay2(eco_index) = "eco_count"
                            TextBox27.Text = TextBox128.Text
                            PictureBox22.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 3 Then
                            _Araay2(eco_index) = "eco_count"
                            TextBox28.Text = TextBox128.Text
                            PictureBox24.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 4 Then
                            _Araay2(eco_index) = "eco_count"
                            TextBox29.Text = TextBox128.Text
                            PictureBox25.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 5 Then
                            _Araay2(eco_index) = "eco_count"
                            TextBox30.Text = TextBox128.Text
                            PictureBox26.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 6 Then
                            _Araay2(eco_index) = "eco_count"
                            TextBox36.Text = TextBox128.Text
                            PictureBox32.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 7 Then
                            TextBox37.Text = TextBox128.Text
                            _Araay2(eco_index) = "eco_count"
                            PictureBox33.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 8 Then
                            _Araay2(eco_index) = "eco_count"
                            TextBox38.Text = TextBox128.Text
                            PictureBox34.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 9 Then
                            _Araay2(eco_index) = "eco_count"
                            TextBox39.Text = TextBox128.Text
                            PictureBox35.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 10 Then
                            _Araay2(eco_index) = "eco_count"
                            TextBox40.Text = TextBox128.Text
                            PictureBox36.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 11 Then
                            _Araay2(eco_index) = "eco_count"
                            TextBox46.Text = TextBox128.Text
                            PictureBox42.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 12 Then
                            TextBox47.Text = TextBox128.Text
                            _Araay2(eco_index) = "eco_count"
                            PictureBox43.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 13 Then
                            TextBox48.Text = TextBox128.Text
                            _Araay2(eco_index) = "eco_count"
                            PictureBox44.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 14 Then
                            TextBox49.Text = TextBox128.Text
                            _Araay2(eco_index) = "eco_count"
                            PictureBox45.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 15 Then
                            TextBox50.Text = TextBox128.Text
                            _Araay2(eco_index) = "eco_count"
                            PictureBox46.Image = Image.FromFile("C:\pic2\xeco.jpeg")


                        ElseIf eco_count = 16 Then
                            TextBox56.Text = TextBox128.Text
                            _Araay2(eco_index) = "eco_count"
                            PictureBox52.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 17 Then
                            TextBox57.Text = TextBox128.Text
                            _Araay2(eco_index) = "eco_count"
                            PictureBox53.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 18 Then
                            TextBox58.Text = TextBox128.Text
                            _Araay2(eco_index) = "eco_count"
                            PictureBox54.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 19 Then
                            TextBox59.Text = TextBox128.Text
                            _Araay2(eco_index) = "eco_count"
                            PictureBox55.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 20 Then
                            TextBox60.Text = TextBox128.Text
                            _Araay2(eco_index) = "eco_count"
                            PictureBox56.Image = Image.FromFile("C:\pic2\xeco.jpeg")

                        ElseIf eco_count = 21 Then
                            _Araay2(eco_index) = "eco_count"
                            TextBox66.Text = TextBox128.Text
                            PictureBox62.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 22 Then
                            TextBox67.Text = TextBox128.Text
                            _Araay2(eco_index) = "eco_count"
                            PictureBox63.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 23 Then
                            TextBox68.Text = TextBox128.Text
                            _Araay2(eco_index) = "eco_count"
                            PictureBox64.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 24 Then
                            TextBox69.Text = TextBox128.Text
                            _Araay2(eco_index) = "eco_count"
                            PictureBox65.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 25 Then
                            TextBox70.Text = TextBox128.Text
                            _Araay2(eco_index) = "eco_count"
                            PictureBox66.Image = Image.FromFile("C:\pic2\xeco.jpeg")


                        ElseIf eco_count = 26 Then
                            TextBox76.Text = TextBox128.Text
                            _Araay2(eco_index) = "eco_count"
                            PictureBox72.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 27 Then
                            TextBox77.Text = TextBox128.Text
                            _Araay2(eco_index) = "eco_count"
                            PictureBox73.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 28 Then
                            TextBox78.Text = TextBox128.Text
                            _Araay2(eco_index) = "eco_count"
                            PictureBox74.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 29 Then
                            TextBox79.Text = TextBox128.Text
                            _Araay2(eco_index) = "eco_count"
                            PictureBox75.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 30 Then
                            TextBox80.Text = TextBox128.Text
                            _Araay2(eco_index) = "eco_count"
                            PictureBox76.Image = Image.FromFile("C:\pic2\xeco.jpeg")


                        ElseIf eco_count = 31 Then
                            TextBox86.Text = TextBox128.Text
                            _Araay2(eco_index) = "eco_count"
                            PictureBox82.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 32 Then
                            TextBox87.Text = TextBox128.Text
                            _Araay2(eco_index) = "eco_count"
                            PictureBox83.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 33 Then
                            TextBox88.Text = TextBox128.Text
                            _Araay2(eco_index) = "eco_count"
                            PictureBox84.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 34 Then
                            TextBox89.Text = TextBox128.Text
                            _Araay2(eco_index) = "eco_count"
                            PictureBox85.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 35 Then
                            TextBox90.Text = TextBox128.Text
                            _Araay2(eco_index) = "eco_count"
                            PictureBox86.Image = Image.FromFile("C:\pic2\xeco.jpeg")


                        ElseIf eco_count = 36 Then
                            TextBox96.Text = TextBox128.Text
                            _Araay2(eco_index) = "eco_count"
                            PictureBox92.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 37 Then
                            TextBox97.Text = TextBox128.Text
                            _Araay2(eco_index) = "eco_count"
                            PictureBox93.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 38 Then
                            TextBox98.Text = TextBox128.Text
                            _Araay2(eco_index) = "eco_count"
                            PictureBox94.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 39 Then
                            TextBox99.Text = TextBox128.Text
                            _Araay2(eco_index) = "eco_count"
                            PictureBox95.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 40 Then
                            TextBox100.Text = TextBox128.Text
                            _Araay2(eco_index) = "eco_count"
                            PictureBox96.Image = Image.FromFile("C:\pic2\xeco.jpeg")

                        ElseIf eco_count = 41 Then
                            TextBox106.Text = TextBox128.Text
                            _Araay2(eco_index) = "eco_count"
                            PictureBox102.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 42 Then
                            TextBox107.Text = TextBox128.Text
                            _Araay2(eco_index) = "eco_count"
                            PictureBox103.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 43 Then
                            TextBox108.Text = TextBox128.Text
                            _Araay2(eco_index) = "eco_count"
                            PictureBox104.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 44 Then
                            TextBox109.Text = TextBox128.Text
                            _Araay2(eco_index) = "eco_count"
                            PictureBox105.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 45 Then
                            TextBox110.Text = TextBox128.Text

                            _Araay2(eco_index) = "eco_count"
                            PictureBox106.Image = Image.FromFile("C:\pic2\xeco.jpeg")


                        ElseIf eco_count = 46 Then
                            TextBox116.Text = TextBox128.Text
                            _Araay2(eco_index) = "eco_count"
                            PictureBox112.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 47 Then
                            TextBox117.Text = TextBox128.Text
                            _Araay2(eco_index) = "eco_count"
                            PictureBox113.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 48 Then
                            TextBox118.Text = TextBox128.Text
                            _Araay2(eco_index) = "eco_count"
                            PictureBox114.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 49 Then
                            TextBox119.Text = TextBox128.Text
                            _Araay2(eco_index) = "eco_count"
                            PictureBox115.Image = Image.FromFile("C:\pic2\xeco.jpeg")
                        ElseIf eco_count = 50 Then
                            TextBox120.Text = TextBox128.Text
                            _Araay2(eco_index) = "eco_count"
                            PictureBox116.Image = Image.FromFile("C:\pic2\xeco.jpeg")

                        End If
                    ElseIf _Araay2(eco_index) <> "" Then
                        MessageBox.Show(" Sorry, The Seat is  NOT  available ", "Booking information", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If

                End If
            Next
        End If



    End Sub

    Sub delete3()


        For eco_index = 1 To 50

            If TextBox127.Text = "" Then
                MessageBox.Show("Input Your Info (seat no.)", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            ElseIf TextBox127.Text > 51 Then
                MessageBox.Show("Input Your Info (seat no.) that's seat out of my array", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub

            Else

                eco_count = TextBox127.Text
                If eco_index = eco_count Then
                    If _Araay2(eco_index) <> "" Then
                        MessageBox.Show(" Yes, The Seat is it" & vbCrLf & " You cancell the seat " & eco_index, "Booking information", MessageBoxButtons.OK, MessageBoxIcon.Information)


                        If eco_count = 1 Then
                            If TextBox128.Text = TextBox26.Text Then
                                _Araay2(eco_index) = ""
                                TextBox26.Text = ""
                                PictureBox23.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 2 Then
                            If TextBox128.Text = TextBox27.Text Then
                                _Araay2(eco_index) = ""
                                TextBox27.Text = ""
                                PictureBox22.Image = Image.FromFile("C:\pic2\eco.jpeg")

                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 3 Then
                            If TextBox128.Text = TextBox28.Text Then
                                _Araay2(eco_index) = ""
                                TextBox28.Text = ""
                                PictureBox24.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 4 Then
                            If TextBox128.Text = TextBox29.Text Then
                                _Araay2(eco_index) = ""
                                TextBox29.Text = ""
                                PictureBox25.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 5 Then
                            If TextBox128.Text = TextBox30.Text Then
                                _Araay2(eco_index) = ""
                                TextBox30.Text = ""
                                PictureBox26.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If


                        ElseIf eco_count = 6 Then
                            If TextBox128.Text = TextBox36.Text Then

                                _Araay2(eco_index) = ""
                                TextBox36.Text = ""
                                PictureBox32.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 7 Then
                            If TextBox128.Text = TextBox37.Text Then

                                TextBox37.Text = ""
                                _Araay2(eco_index) = ""
                                PictureBox33.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 8 Then
                            If TextBox128.Text = TextBox38.Text Then

                                _Araay2(eco_index) = ""
                                TextBox38.Text = ""
                                PictureBox34.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 9 Then
                            If TextBox128.Text = TextBox39.Text Then

                                _Araay2(eco_index) = ""
                                TextBox39.Text = ""
                                PictureBox35.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 10 Then
                            If TextBox128.Text = TextBox40.Text Then

                                _Araay2(eco_index) = ""
                                TextBox40.Text = ""
                                PictureBox36.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 11 Then
                            If TextBox128.Text = TextBox46.Text Then

                                _Araay2(eco_index) = ""
                                TextBox46.Text = ""
                                PictureBox42.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 12 Then
                            If TextBox128.Text = TextBox47.Text Then

                                TextBox47.Text = ""
                                _Araay2(eco_index) = ""
                                PictureBox43.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 13 Then
                            If TextBox128.Text = TextBox48.Text Then

                                TextBox48.Text = ""
                                _Araay2(eco_index) = ""
                                PictureBox44.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 14 Then
                            If TextBox128.Text = TextBox49.Text Then

                                TextBox49.Text = ""
                                _Araay2(eco_index) = ""
                                PictureBox45.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 15 Then
                            If TextBox128.Text = TextBox50.Text Then

                                TextBox50.Text = ""
                                _Araay2(eco_index) = ""
                                PictureBox46.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If

                        ElseIf eco_count = 16 Then
                            If TextBox128.Text = TextBox56.Text Then

                                TextBox56.Text = ""
                                _Araay2(eco_index) = ""
                                PictureBox52.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 17 Then
                            If TextBox128.Text = TextBox57.Text Then

                                TextBox57.Text = ""
                                _Araay2(eco_index) = ""
                                PictureBox53.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 18 Then
                            If TextBox128.Text = TextBox58.Text Then

                                TextBox58.Text = ""
                                _Araay2(eco_index) = ""
                                PictureBox54.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 19 Then
                            If TextBox128.Text = TextBox59.Text Then

                                TextBox59.Text = ""
                                _Araay2(eco_index) = ""
                                PictureBox55.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 20 Then
                            If TextBox128.Text = TextBox60.Text Then

                                TextBox60.Text = ""
                                _Araay2(eco_index) = ""
                                PictureBox56.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 21 Then
                            If TextBox128.Text = TextBox66.Text Then

                                _Araay2(eco_index) = ""
                                TextBox66.Text = ""
                                PictureBox62.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 22 Then
                            If TextBox128.Text = TextBox67.Text Then

                                TextBox67.Text = ""
                                _Araay2(eco_index) = ""
                                PictureBox63.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 23 Then
                            If TextBox128.Text = TextBox68.Text Then

                                TextBox68.Text = ""
                                _Araay2(eco_index) = ""
                                PictureBox64.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 24 Then
                            If TextBox128.Text = TextBox69.Text Then

                                TextBox69.Text = ""
                                _Araay2(eco_index) = ""
                                PictureBox65.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 25 Then
                            If TextBox128.Text = TextBox70.Text Then

                                TextBox70.Text = ""
                                _Araay2(eco_index) = ""
                                PictureBox66.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If

                        ElseIf eco_count = 26 Then
                            If TextBox128.Text = TextBox76.Text Then

                                TextBox76.Text = ""
                                _Araay2(eco_index) = ""
                                PictureBox72.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 27 Then
                            If TextBox128.Text = TextBox77.Text Then

                                TextBox77.Text = ""
                                _Araay2(eco_index) = ""
                                PictureBox73.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 28 Then
                            If TextBox128.Text = TextBox78.Text Then

                                TextBox78.Text = ""
                                _Araay2(eco_index) = ""
                                PictureBox74.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 29 Then
                            If TextBox128.Text = TextBox79.Text Then

                                TextBox79.Text = ""
                                _Araay2(eco_index) = ""
                                PictureBox75.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 30 Then
                            If TextBox128.Text = TextBox80.Text Then

                                TextBox80.Text = ""
                                _Araay2(eco_index) = ""
                                PictureBox76.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If

                        ElseIf eco_count = 31 Then
                            If TextBox128.Text = TextBox86.Text Then

                                TextBox86.Text = ""
                                _Araay2(eco_index) = ""
                                PictureBox82.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 32 Then
                            If TextBox128.Text = TextBox87.Text Then

                                TextBox87.Text = ""
                                _Araay2(eco_index) = ""
                                PictureBox83.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 33 Then
                            If TextBox128.Text = TextBox88.Text Then

                                TextBox88.Text = ""
                                _Araay2(eco_index) = ""
                                PictureBox84.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 34 Then
                            If TextBox128.Text = TextBox89.Text Then

                                TextBox89.Text = ""
                                _Araay2(eco_index) = ""
                                PictureBox85.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 35 Then
                            If TextBox128.Text = TextBox90.Text Then

                                TextBox90.Text = ""
                                _Araay2(eco_index) = ""
                                PictureBox86.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If

                        ElseIf eco_count = 36 Then
                            If TextBox128.Text = TextBox96.Text Then

                                TextBox96.Text = ""
                                _Araay2(eco_index) = ""
                                PictureBox92.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 37 Then
                            If TextBox128.Text = TextBox97.Text Then

                                TextBox97.Text = ""
                                _Araay2(eco_index) = ""
                                PictureBox93.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 38 Then
                            If TextBox128.Text = TextBox98.Text Then

                                TextBox98.Text = ""
                                _Araay2(eco_index) = ""
                                PictureBox94.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 39 Then
                            If TextBox128.Text = TextBox99.Text Then

                                TextBox99.Text = ""
                                _Araay2(eco_index) = ""
                                PictureBox95.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 40 Then
                            If TextBox128.Text = TextBox100.Text Then

                                TextBox100.Text = ""
                                _Araay2(eco_index) = ""
                                PictureBox96.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 41 Then
                            If TextBox128.Text = TextBox106.Text Then

                                TextBox106.Text = ""
                                _Araay2(eco_index) = ""
                                PictureBox102.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 42 Then
                            If TextBox128.Text = TextBox107.Text Then

                                TextBox107.Text = ""
                                _Araay2(eco_index) = ""
                                PictureBox103.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 43 Then
                            If TextBox128.Text = TextBox108.Text Then

                                TextBox108.Text = ""
                                _Araay2(eco_index) = ""
                                PictureBox104.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 44 Then
                            If TextBox128.Text = TextBox109.Text Then

                                TextBox109.Text = ""
                                _Araay2(eco_index) = ""
                                PictureBox105.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 45 Then
                            If TextBox128.Text = TextBox110.Text Then

                                TextBox110.Text = ""

                                _Araay2(eco_index) = ""
                                PictureBox106.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If

                        ElseIf eco_count = 46 Then
                            If TextBox128.Text = TextBox116.Text Then

                                TextBox116.Text = ""
                                _Araay2(eco_index) = ""
                                PictureBox112.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 47 Then
                            If TextBox128.Text = TextBox117.Text Then

                                TextBox117.Text = ""
                                _Araay2(eco_index) = ""
                                PictureBox113.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 48 Then
                            If TextBox128.Text = TextBox118.Text Then

                                TextBox118.Text = ""
                                _Araay2(eco_index) = ""
                                PictureBox114.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 49 Then
                            If TextBox128.Text = TextBox119.Text Then

                                TextBox119.Text = ""
                                _Araay2(eco_index) = ""
                                PictureBox115.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                        ElseIf eco_count = 50 Then
                            If TextBox128.Text = TextBox120.Text Then

                                TextBox120.Text = ""
                                _Araay2(eco_index) = ""
                                PictureBox116.Image = Image.FromFile("C:\pic2\eco.jpeg")
                            Else
                                MessageBox.Show("Sorry, You can Not cancel - check the name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                            End If
                    End If
                    ElseIf _Araay2(eco_index) = "" Then
                        MessageBox.Show(" Sorry, The Seat is   available ", "Booking information", MessageBoxButtons.OK, MessageBoxIcon.Error)
                        Exit Sub
                    End If

                End If

            End If
        Next


    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        delete3()
    End Sub

    Private Sub PictureBox23_Click(sender As Object, e As EventArgs) Handles PictureBox23.Click
        If _Araay2(1) = "" Then
            TextBox127.Text = 1
            Position3()
        Else
            delete3()
        End If

    End Sub

    Private Sub PictureBox22_Click(sender As Object, e As EventArgs) Handles PictureBox22.Click
        If _Araay2(2) = "" Then
            TextBox127.Text = 2
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox24_Click(sender As Object, e As EventArgs) Handles PictureBox24.Click
        If _Araay2(3) = "" Then
            TextBox127.Text = 3
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox25_Click(sender As Object, e As EventArgs) Handles PictureBox25.Click
        If _Araay2(4) = "" Then
            TextBox127.Text = 4
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox26_Click(sender As Object, e As EventArgs) Handles PictureBox26.Click
        If _Araay2(5) = "" Then
            TextBox127.Text = 5
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox32_Click(sender As Object, e As EventArgs) Handles PictureBox32.Click
        If _Araay2(6) = "" Then
            TextBox127.Text = 6
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox33_Click(sender As Object, e As EventArgs) Handles PictureBox33.Click
        If _Araay2(7) = "" Then
            TextBox127.Text = 7
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox34_Click(sender As Object, e As EventArgs) Handles PictureBox34.Click
        If _Araay2(8) = "" Then
            TextBox127.Text = 8
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox35_Click(sender As Object, e As EventArgs) Handles PictureBox35.Click
        If _Araay2(9) = "" Then
            TextBox127.Text = 9
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox36_Click(sender As Object, e As EventArgs) Handles PictureBox36.Click
        If _Araay2(10) = "" Then
            TextBox127.Text = 10
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox42_Click(sender As Object, e As EventArgs) Handles PictureBox42.Click
        If _Araay2(11) = "" Then
            TextBox127.Text = 11
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox43_Click(sender As Object, e As EventArgs) Handles PictureBox43.Click
        If _Araay2(12) = "" Then
            TextBox127.Text = 12
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox44_Click(sender As Object, e As EventArgs) Handles PictureBox44.Click
        If _Araay2(13) = "" Then
            TextBox127.Text = 13
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox45_Click(sender As Object, e As EventArgs) Handles PictureBox45.Click
        If _Araay2(14) = "" Then
            TextBox127.Text = 14
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox46_Click(sender As Object, e As EventArgs) Handles PictureBox46.Click
        If _Araay2(15) = "" Then
            TextBox127.Text = 15
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox52_Click(sender As Object, e As EventArgs) Handles PictureBox52.Click
        If _Araay2(16) = "" Then
            TextBox127.Text = 16
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox53_Click(sender As Object, e As EventArgs) Handles PictureBox53.Click
        If _Araay2(17) = "" Then
            TextBox127.Text = 17
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox54_Click(sender As Object, e As EventArgs) Handles PictureBox54.Click
        If _Araay2(18) = "" Then
            TextBox127.Text = 18
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox55_Click(sender As Object, e As EventArgs) Handles PictureBox55.Click
        If _Araay2(19) = "" Then
            TextBox127.Text = 19
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox56_Click(sender As Object, e As EventArgs) Handles PictureBox56.Click
        If _Araay2(20) = "" Then
            TextBox127.Text = 20
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox62_Click(sender As Object, e As EventArgs) Handles PictureBox62.Click
        If _Araay2(21) = "" Then
            TextBox127.Text = 21
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox63_Click(sender As Object, e As EventArgs) Handles PictureBox63.Click
        If _Araay2(22) = "" Then
            TextBox127.Text = 22
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox64_Click(sender As Object, e As EventArgs) Handles PictureBox64.Click
        If _Araay2(23) = "" Then
            TextBox127.Text = 23
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox65_Click(sender As Object, e As EventArgs) Handles PictureBox65.Click
        If _Araay2(24) = "" Then
            TextBox127.Text = 24
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox66_Click(sender As Object, e As EventArgs) Handles PictureBox66.Click
        If _Araay2(25) = "" Then
            TextBox127.Text = 25
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox72_Click(sender As Object, e As EventArgs) Handles PictureBox72.Click
        If _Araay2(26) = "" Then
            TextBox127.Text = 26
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox73_Click(sender As Object, e As EventArgs) Handles PictureBox73.Click
        If _Araay2(27) = "" Then
            TextBox127.Text = 27
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox74_Click(sender As Object, e As EventArgs) Handles PictureBox74.Click
        If _Araay2(28) = "" Then
            TextBox127.Text = 28
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox75_Click(sender As Object, e As EventArgs) Handles PictureBox75.Click
        If _Araay2(29) = "" Then
            TextBox127.Text = 29
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox76_Click(sender As Object, e As EventArgs) Handles PictureBox76.Click
        If _Araay2(30) = "" Then
            TextBox127.Text = 30
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox82_Click(sender As Object, e As EventArgs) Handles PictureBox82.Click
        If _Araay2(31) = "" Then
            TextBox127.Text = 31
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox83_Click(sender As Object, e As EventArgs) Handles PictureBox83.Click
        If _Araay2(32) = "" Then
            TextBox127.Text = 32
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox84_Click(sender As Object, e As EventArgs) Handles PictureBox84.Click
        If _Araay2(33) = "" Then
            TextBox127.Text = 33
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox85_Click(sender As Object, e As EventArgs) Handles PictureBox85.Click
        If _Araay2(34) = "" Then
            TextBox127.Text = 34
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox86_Click(sender As Object, e As EventArgs) Handles PictureBox86.Click
        If _Araay2(35) = "" Then
            TextBox127.Text = 35
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox92_Click(sender As Object, e As EventArgs) Handles PictureBox92.Click
        If _Araay2(36) = "" Then
            TextBox127.Text = 36
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox93_Click(sender As Object, e As EventArgs) Handles PictureBox93.Click
        If _Araay2(37) = "" Then
            TextBox127.Text = 37
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox94_Click(sender As Object, e As EventArgs) Handles PictureBox94.Click
        If _Araay2(38) = "" Then
            TextBox127.Text = 38
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox95_Click(sender As Object, e As EventArgs) Handles PictureBox95.Click
        If _Araay2(39) = "" Then
            TextBox127.Text = 39
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox96_Click(sender As Object, e As EventArgs) Handles PictureBox96.Click
        If _Araay2(40) = "" Then
            TextBox127.Text = 40
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox102_Click(sender As Object, e As EventArgs) Handles PictureBox102.Click
        If _Araay2(41) = "" Then
            TextBox127.Text = 41
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox103_Click(sender As Object, e As EventArgs) Handles PictureBox103.Click
        If _Araay2(42) = "" Then
            TextBox127.Text = 42
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox104_Click(sender As Object, e As EventArgs) Handles PictureBox104.Click
        If _Araay2(43) = "" Then
            TextBox127.Text = 43
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox105_Click(sender As Object, e As EventArgs) Handles PictureBox105.Click
        If _Araay2(44) = "" Then
            TextBox127.Text = 44
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox106_Click(sender As Object, e As EventArgs) Handles PictureBox106.Click
        If _Araay2(45) = "" Then
            TextBox127.Text = 45
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox112_Click(sender As Object, e As EventArgs) Handles PictureBox112.Click
        If _Araay2(46) = "" Then
            TextBox127.Text = 46
            Position3()
        Else
            delete3()
        End If
    End Sub

    Private Sub PictureBox113_Click(sender As Object, e As EventArgs) Handles PictureBox113.Click
        If _Araay2(47) = "" Then
            TextBox127.Text = 47
            Position3()
        Else
            TextBox127.Text = 47
            delete3()
        End If
    End Sub

    Private Sub PictureBox114_Click(sender As Object, e As EventArgs) Handles PictureBox114.Click
        If _Araay2(48) = "" Then
            TextBox127.Text = 48
            Position3()
        Else
            TextBox127.Text = 48
            delete3()
        End If
    End Sub

    Private Sub PictureBox115_Click(sender As Object, e As EventArgs) Handles PictureBox115.Click
        If _Araay2(49) = "" Then
            TextBox127.Text = 49
            Position3()
        Else
            TextBox127.Text = 49
            delete3()
        End If
    End Sub

    Private Sub PictureBox116_Click(sender As Object, e As EventArgs) Handles PictureBox116.Click
        If _Araay2(50) = "" Then
            TextBox127.Text = 50
            Position3()
        Else
            TextBox127.Text = 50
            delete3()
        End If
    End Sub
End Class

