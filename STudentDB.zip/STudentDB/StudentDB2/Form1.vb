﻿Public Class Form1
    Dim ConnObj As New ADODB.Connection
    Dim RecSetObj As New ADODB.Recordset
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ConnObj.Provider = "Microsoft.jet.oledb.4.0"
        ConnObj.ConnectionString = "C:\Users\User\Desktop\STudentDB\StudentDB.mdb"
        ConnObj.Open()
        RecSetObj.Open("Select * from StudentDB", ConnObj,
ADODB.CursorTypeEnum.adOpenDynamic, ADODB.LockTypeEnum.adLockOptimistic)
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click

        Dim strCriteria As String
        If TextBox1.Text = "" Then



            Dim ID As String
            ID = InputBox("Enter Student ID")
            TextBox1.Text = ID
            strCriteria = "StudentID=" + TextBox1.Text
            RecSetObj.MoveFirst()
            RecSetObj.Find(strCriteria)
            If RecSetObj.EOF Then


                MessageBox.Show("NOT Found the Record !")
                CleanForm()
            Else
                Call ShowData()
            End If
        Else
            strCriteria = "StudentID=" + TextBox1.Text
            RecSetObj.Find(strCriteria)
            If RecSetObj.EOF Then


                MessageBox.Show("NOT Found the Record !")
                CleanForm()
            Else
                Call ShowData()
            End If
        End If
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub GroupBox2_Enter(sender As Object, e As EventArgs) Handles GroupBox2.Enter

    End Sub

    Private Sub Button11_Click(sender As Object, e As EventArgs) Handles Button11.Click
        Dim strCriteria As String
        strCriteria = "StudentID=" + TextBox1.Text
        RecSetObj.Find(strCriteria)
        If RecSetObj.EOF Then
            MessageBox.Show(" please try Again!")

        Else

            Dim result As DialogResult = MessageBox.Show("Do you to delete it", "Confirm", MessageBoxButtons.YesNo)

            If result = DialogResult.No Then
                MessageBox.Show("No, you did NOT delete the Record ")
            ElseIf result = DialogResult.Yes Then
                RecSetObj.Delete()
                MessageBox.Show("Yes ,You deleted This Record !")
                CleanForm()
            End If


        End If
    End Sub

    Private Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click

        Dim strCriteria As String
        strCriteria = "StudentID=" + TextBox1.Text
        RecSetObj.Find(strCriteria)
        If RecSetObj.EOF Then
            MessageBox.Show(" please try Again!")

        Else


            Call SaveInAccessFile()
            RecSetObj.Update()
            MessageBox.Show("Updated Record Saved!")
        End If
    End Sub

    Private Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        If TextBox1.Text = "" Or
                TextBox2.Text = "" Or
                TextBox3.Text = "" Or
            TextBox4.Text = "" Or
            TextBox5.Text = "" Or
            (RadioButton1.Checked = False And RadioButton2.Checked = False) Then
            MessageBox.Show("please fill the form")


            Exit Sub
        End If
        If RecSetObj.BOF <> True Then


            RecSetObj.MoveFirst()
        End If
        Dim strCriteria As String
        strCriteria = "StudentID=" + TextBox1.Text
        RecSetObj.Find(strCriteria)
        If RecSetObj.EOF Then
            RecSetObj.AddNew()
            Call SaveInAccessFile()
            RecSetObj.Update()
            MessageBox.Show("New Record Saved!")
        Else
            MessageBox.Show("Duplicate Record, please try Again!")






        End If

    End Sub
    Private Sub SaveInAccessFile()
        If IsNumeric(TextBox5.Text) <> True Then

            MessageBox.Show("Age is not in a numeric form")

            Exit Sub
        End If
        RecSetObj.Fields("Age").Value = TextBox5.Text

            RecSetObj.Fields("StudentID").Value = TextBox1.Text
            RecSetObj.Fields("FirstName").Value = TextBox2.Text
            RecSetObj.Fields("LastName").Value = TextBox3.Text
            RecSetObj.Fields("Nationality").Value = TextBox4.Text


            If RadioButton1.Checked Then
            RecSetObj.Fields("Gender").Value = False
        Else
            RecSetObj.Fields("Gender").Value = True
        End If
        RecSetObj.Update()
        MessageBox.Show("Saved Record")

    End Sub

    Private Sub TextBox5_TextChanged(sender As Object, e As EventArgs) Handles TextBox5.TextChanged

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If RecSetObj.BOF <> True Then
            RecSetObj.MoveNext()
            If RecSetObj.EOF Then
                RecSetObj.MoveLast()
                MessageBox.Show("End of Record")

            End If
        End If
        Call ShowData()
    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        RecSetObj.MoveFirst()
        If RecSetObj.BOF Then
            MessageBox.Show("first of Record")
        End If
        ShowData()
    End Sub
    Private Sub ShowData()
        TextBox1.Text = RecSetObj.Fields("StudentID").Value
        TextBox2.Text = RecSetObj.Fields("FirstName").Value.ToString
        TextBox3.Text = RecSetObj.Fields("LastName").Value.ToString
        TextBox4.Text = RecSetObj.Fields("Nationality").Value.ToString
        TextBox5.Text = RecSetObj.Fields("Age").Value.ToString
        If RecSetObj.Fields("Gender").Value = True Then
            RadioButton2.Checked = True
        Else
            RadioButton1.Checked = True

        End If




    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

        RecSetObj.MovePrevious()
        If RecSetObj.BOF Then
            RecSetObj.MoveFirst()
            MessageBox.Show("First of Record")


        End If
        Call ShowData()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        RecSetObj.MoveLast()
        If RecSetObj.EOF Then
            MessageBox.Show("End of Record")
        End If
        ShowData()
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        CleanForm()

    End Sub
    Private Sub CleanForm()
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        RadioButton1.Checked = False
        RadioButton2.Checked = False
        MessageBox.Show("Clean form")


        Exit Sub
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Dim strCriteria As String
        If TextBox2.Text = "" Then



            Dim F As String
            F = InputBox("Enter First Name=")
            TextBox2.Text = F
            strCriteria = "FirstName='" + TextBox2.Text + "'"
            RecSetObj.MoveFirst()
            RecSetObj.Find(strCriteria)
            If RecSetObj.EOF Then


                MessageBox.Show("NOT Found the Record !")
                CleanForm()
            Else
                Call ShowData()
            End If
        Else
            RecSetObj.MoveFirst()
            strCriteria = "FirstName='" + TextBox2.Text + "'"
            RecSetObj.Find(strCriteria)
            If RecSetObj.EOF Then


                MessageBox.Show("NOT Found the Record !")
                CleanForm()
            Else
                Call ShowData()
            End If
        End If
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        Dim strCriteria As String
        If TextBox3.Text = "" Then


            Dim L As String
            L = InputBox("Enter Last Name")
            TextBox3.Text = L
            strCriteria = "LastName='" + TextBox3.Text + "'"
            RecSetObj.MoveFirst()
            RecSetObj.Find(strCriteria)
            If RecSetObj.EOF Then


                MessageBox.Show("NOT Found the Record !")
                CleanForm()
            Else
                Call ShowData()
            End If
        Else
            RecSetObj.MoveFirst()


            strCriteria = "LastName='" + TextBox3.Text + "'"
            RecSetObj.Find(strCriteria)
            If RecSetObj.EOF Then


                MessageBox.Show("NOT Found the Record !")
                CleanForm()
            Else
                Call ShowData()
            End If
        End If
    End Sub

    Private Sub TextBox4_TextChanged(sender As Object, e As EventArgs) Handles TextBox4.TextChanged

    End Sub
End Class
