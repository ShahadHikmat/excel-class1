﻿Public Class Form1

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim BirthYear As Integer
        Dim BirthMonth As Integer
        Dim BirthDay As Integer

        Dim currentYear As Integer
        Dim currentMonth As Integer
        Dim currentDay As Integer

        Dim eYear As Integer
        Dim eMonth As Integer
        Dim eDay As Integer

        BirthYear = Convert.ToInt32(TextBox1.Text)
        BirthMonth = Convert.ToInt32(TextBox2.Text)
        BirthDay = Convert.ToInt32(TextBox3.Text)

        currentYear = Convert.ToInt32(TextBox4.Text)
        currentMonth = Convert.ToInt32(TextBox5.Text)
        currentDay = Convert.ToInt32(TextBox6.Text)

        If Validator(BirthDay, BirthMonth, BirthYear) = True And Validator(currentDay, currentMonth, currentYear) = True Then

            eDay = currentDay - BirthDay
            eMonth = currentMonth - BirthMonth
            eYear = currentYear - BirthYear


            If eDay < 0 Then
                eDay = eDay + 30
                eMonth = eMonth - 1
                If eMonth < 0 Then
                    eMonth = eMonth + 12
                    eYear = eYear - 1
                    RichTextBox1.Text = "your age is :  " & eYear & "years old" & " and " & eMonth & "Month " & "and " & eDay & "days"
                Else
                    RichTextBox1.Text = "your age is :  " & eYear & "years old" & " and " & eMonth & "Month " & "and " & eDay & "days"
                End If
            Else
                If eMonth < 0 Then
                    eMonth = eMonth + 12
                    eYear = eYear - 1
                    RichTextBox1.Text = "your age is :  " & eYear & "years old" & " and " & eMonth & "Month " & "and " & eDay & "days"
                Else
                    RichTextBox1.Text = "your age is :  " & eYear & "years old" & " and " & eMonth & "Month " & "and " & eDay & "days"
                End If
                RichTextBox1.Text = "your age is :  " & eYear & "years old" & " and " & eMonth & "Month " & "and " & eDay & "days"
            End If
        Else
            RichTextBox1.Text = "input is false"
        End If

    End Sub


    Function Validator(Day As Integer, Month As Integer, Year As Integer)


        If (1000 >= Year Or Year <= 3000) And (Year <> 0 And Year > 1000) Then
            Year = True
        Else
            Year = False
        End If



        If ((Month = 1) Or (Month = 3) Or (Month = 5) Or (Month = 7) Or (Month = 8) Or (Month = 10) Or (Month = 12)) And (1 >= Month Or Month <= 12) And (Month <> 0 And Month > 0) Then

            If (1 >= Day Or Day <= 31) And (Day <> 0 And Day > 0) Then
                Day = True
                Month = True
            Else
                Day = False
            End If

        ElseIf ((Month = 4) Or (Month = 6) Or (Month = 9) Or (Month = 11) And (1 >= Month Or Month <= 12)) And (Month <> 0 And Month > 0) Then
            If (1 >= Day Or Day <= 30) And (Day <> 0 And Day > 0) Then
                Day = True
                Month = True
            Else
                Day = False
            End If
        ElseIf ((Month = 2) And (Month <> 0 And Month > 0)) Then

            If (1 >= Day Or Day <= 28) And (Day <> 0 And Day > 0) Then
                Day = True
                Month = True
            Else
                Day = False
            End If

        Else
            Month = False

        End If
        If (Day = True And Month = True And Year = True) Then
            Return True
        Else
            Return False
        End If





    End Function



    Private Sub RichTextBox1_TextChanged(sender As Object, e As EventArgs) Handles RichTextBox1.TextChanged

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub
End Class
