﻿
Public Class Form1
    Dim MyArray(9) As String
    Dim gamer As String
    Dim X_gamers As Boolean
    Dim O_gamers As Boolean
    Dim point_X As Integer = 0
    Dim point_O As Integer = 0
    Dim Level As Integer = 0

    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles PictureBox1.Click
        If MyArray(0) = "" Then
            If gamer = "x" Then


                PictureBox1.Image = Image.FromFile("C:\pic\new.jpg")

                gamer = "o"
                MyArray(0) = "x"
            Else

                PictureBox1.Image = Image.FromFile("C:\pic\newO.png")

                gamer = "x"
                MyArray(0) = "o"
            End If
        Else
            MessageBox.Show("Sorry ,you can not choose again", "Error in PictureBox1 ", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End If

        DoesGameOver()

    End Sub

    Private Sub PictureBox4_Click(sender As Object, e As EventArgs) Handles PictureBox4.Click
        If MyArray(3) = "" Then
            If gamer = "x" Then

                PictureBox4.Image = Image.FromFile("C:\pic\new.jpg")

                gamer = "o"
                MyArray(3) = "x"
            Else

                PictureBox4.Image = Image.FromFile("C:\pic\newO.png")

                gamer = "x"
                MyArray(3) = "o"
            End If
        Else
            MessageBox.Show("Sorry ,you can not choose again", "Error in PictureBox4 ", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End If


        DoesGameOver()


    End Sub

    Private Sub PictureBox7_Click(sender As Object, e As EventArgs) Handles PictureBox7.Click
        If MyArray(6) = "" Then
            If gamer = "x" Then
                PictureBox7.Image = Image.FromFile("C:\pic\new.jpg")


                gamer = "o"
                MyArray(6) = "x"
            Else
                PictureBox7.Image = Image.FromFile("C:\pic\newO.png")

                gamer = "x"
                MyArray(6) = "o"
            End If
        Else
            MessageBox.Show("Sorry ,you can not choose again", "Error in PictureBox7 ", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End If

        DoesGameOver()


    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click
        If MyArray(1) = "" Then
            If gamer = "x" Then

                PictureBox2.Image = Image.FromFile("C:\pic\new.jpg")


                gamer = "o"
                MyArray(1) = "x"
            Else
                PictureBox2.Image = Image.FromFile("C:\pic\newO.png")
                gamer = "x"
                MyArray(1) = "o"
            End If
        Else
            MessageBox.Show("Sorry ,you can not choose again", "Error in PictureBox2 ", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End If

        DoesGameOver()

    End Sub



    Private Sub PictureBox5_Click(sender As Object, e As EventArgs) Handles PictureBox5.Click
        If MyArray(4) = "" Then
            If gamer = "x" Then

                PictureBox5.Image = Image.FromFile("C:\pic\new.jpg")


                gamer = "o"
                MyArray(4) = "x"
            Else
                PictureBox5.Image = Image.FromFile("C:\pic\newO.png")
                gamer = "x"
                MyArray(4) = "o"
            End If
        Else
            MessageBox.Show("Sorry ,you can not choose again", "Error in PictureBox5 ", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End If
        DoesGameOver()
    End Sub

    Private Sub PictureBox8_Click(sender As Object, e As EventArgs) Handles PictureBox8.Click
        If MyArray(7) = "" Then
            If gamer = "x" Then
                PictureBox8.Image = Image.FromFile("C:\pic\new.jpg")

                gamer = "o"
                MyArray(7) = "x"
            Else
                PictureBox8.Image = Image.FromFile("C:\pic\newO.png")
                gamer = "x"
                MyArray(7) = "o"
            End If
        Else
            MessageBox.Show("Sorry ,you can not choose again", "Error in PictureBox8 ", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End If
        DoesGameOver()
    End Sub

    Private Sub PictureBox3_Click(sender As Object, e As EventArgs) Handles PictureBox3.Click
        If MyArray(2) = "" Then
            If gamer = "x" Then

                PictureBox3.Image = Image.FromFile("C:\pic\new.jpg")


                gamer = "o"
                MyArray(2) = "x"

            Else
                PictureBox3.Image = Image.FromFile("C:\pic\newO.png")
                gamer = "x"
                MyArray(2) = "o"
            End If
        Else
            MessageBox.Show("Sorry ,you can not choose again", "Error in PictureBox3 ", MessageBoxButtons.OK, MessageBoxIcon.Error)

        End If
        DoesGameOver()
    End Sub

    Private Sub PictureBox6_Click(sender As Object, e As EventArgs) Handles PictureBox6.Click
        If MyArray(5) = "" Then
            If gamer = "x" Then

                PictureBox6.Image = Image.FromFile("C:\pic\new.jpg")


                gamer = "o"
                MyArray(5) = "x"
            Else
                PictureBox6.Image = Image.FromFile("C:\pic\newO.png")
                gamer = "x"
                MyArray(5) = "o"
            End If
        Else
            MessageBox.Show("Sorry ,you can not choose again", "Error in PictureBox6 ", MessageBoxButtons.OK, MessageBoxIcon.Error)


        End If
        DoesGameOver()
    End Sub

    Private Sub PictureBox9_Click(sender As Object, e As EventArgs) Handles PictureBox9.Click
        If MyArray(8) = "" Then
            If gamer = "x" Then

                PictureBox9.Image = Image.FromFile("C:\pic\new.jpg")


                gamer = "o"
                MyArray(8) = "x"
            Else
                PictureBox9.Image = Image.FromFile("C:\pic\newO.png")
                gamer = "x"
                MyArray(8) = "o"
            End If
        Else
            MessageBox.Show("Sorry ,you can not choose again", "Error in PictureBox9 ", MessageBoxButtons.OK, MessageBoxIcon.Error)


        End If
        DoesGameOver()
    End Sub

    Sub DoesGameOver()
        If (MyArray(0) = "x" And MyArray(1) = "x" And MyArray(2) = "x") Or (MyArray(3) = "x" And MyArray(4) = "x" And MyArray(5) = "x") Or (MyArray(6) = "x" And MyArray(7) = "x" And MyArray(8) = "x") Or (MyArray(0) = "x" And MyArray(4) = "x" And MyArray(8) = "x") Or (MyArray(6) = "x" And MyArray(4) = "x" And MyArray(2) = "x") Or (MyArray(0) = "x" And MyArray(3) = "x" And MyArray(6) = "x") Or (MyArray(4) = "x" And MyArray(1) = "x" And MyArray(7) = "x") Or (MyArray(2) = "x" And MyArray(5) = "x" And MyArray(8) = "x") Then

            X_gamers = True
            wins_Done()
            nextgame()
        ElseIf (MyArray(0) = "o" And MyArray(1) = "o" And MyArray(2) = "o") Or (MyArray(3) = "o" And MyArray(4) = "o" And MyArray(5) = "o") Or (MyArray(6) = "o" And MyArray(7) = "o" And MyArray(8) = "o") Or (MyArray(0) = "o" And MyArray(4) = "o" And MyArray(8) = "o") Or (MyArray(6) = "o" And MyArray(4) = "o" And MyArray(2) = "o") Or (MyArray(0) = "o" And MyArray(3) = "o" And MyArray(6) = "o") Or (MyArray(4) = "o" And MyArray(1) = "o" And MyArray(7) = "o") Or (MyArray(2) = "o" And MyArray(5) = "o" And MyArray(8) = "o") Then

            O_gamers = True
            wins_Done()
            nextgame()
        End If

        Done()

    End Sub
    Sub nextgame()
        Dim randomGamer As New Random
        For index = 0 To 8
            MyArray(index) = ""

        Next
        If randomGamer.Next(0, 6) <= 4 Then
            gamer = "o"
            MessageBox.Show("Next game  O's will start ", "Tic-Tac-Toe", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            gamer = "x"
            MessageBox.Show("Next game  X's will start ", "Tic-Tac-Toe", MessageBoxButtons.OK, MessageBoxIcon.Information)

        End If
    End Sub
    Sub Done()
        Dim counter As Integer = 0

        For index = 0 To 8
            If MyArray(index) = "x" Or MyArray(index) = "o" Then

                counter += 1

                If counter = 9 Then

                    'X_gamers = False
                    'O_gamers = False
                    wins_Done()
                End If
            End If
        Next


    End Sub
    Sub wins_Done()


        If X_gamers = True Then
            MessageBox.Show(" X @ Wins " & vbCrLf & vbCrLf & "Let's play again", "Game Over", MessageBoxButtons.OK, MessageBoxIcon.Information)
            _level()
            _points()

            reset()

        ElseIf O_gamers = True Then

            MessageBox.Show(" O @ Wins " & vbCrLf & vbCrLf & "Let's play again", "Game Over", MessageBoxButtons.OK, MessageBoxIcon.Information)
            _level()
            _points()

            reset()
        Else
            MessageBox.Show("No bady wins " & vbCrLf & vbCrLf & " Let's play again", "Game Over", MessageBoxButtons.OK, MessageBoxIcon.Information)
            _level()
            _points()
            nextgame()
            reset()
        End If

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        MessageBox.Show("Let's reset this level ONLY and play again", "Autreset", MessageBoxButtons.OK, MessageBoxIcon.Information)

        reset()
        nextgame()
    End Sub
    Sub reset()
        PictureBox1.Image = Image.FromFile("C:\Z.jpeg")
        PictureBox2.Image = Image.FromFile("C:\Z.jpeg")
        PictureBox3.Image = Image.FromFile("C:\Z.jpeg")
        PictureBox4.Image = Image.FromFile("C:\Z.jpeg")
        PictureBox5.Image = Image.FromFile("C:\Z.jpeg")
        PictureBox6.Image = Image.FromFile("C:\Z.jpeg")
        PictureBox7.Image = Image.FromFile("C:\Z.jpeg")
        PictureBox8.Image = Image.FromFile("C:\Z.jpeg")
        PictureBox9.Image = Image.FromFile("C:\Z.jpeg")


        For index = 0 To 8
            MyArray(index) = ""



        Next

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        nextgame()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        MessageBox.Show("Let's restat the game and play again from the beginning .", "Autoplay", MessageBoxButtons.OK, MessageBoxIcon.Information)

        nextgame()
        reset()
        X_gamers = False
        O_gamers = False
        Level = 0
        point_X = 0
        point_O = 0

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        _points()
        MessageBox.Show("Hope you had fun time !  " & vbCrLf & vbCrLf & "we wait to join again .", "Exit", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Close()
    End Sub

    Sub _points()

        If X_gamers = True Then
            point_X += 1


        ElseIf O_gamers = True Then
            point_O += 1
        End If

        MessageBox.Show("Level : " & Level & vbCrLf & vbCrLf & " points_O :  { " & point_O & " }   VS    " & "points_X :  { " & point_X & " }", "Score Final ", MessageBoxButtons.OK, MessageBoxIcon.Information)
        X_gamers = False
        O_gamers = False

    End Sub
    Sub _level()

        Level += 1

    End Sub
End Class