﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Bank
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();

        }
        int Account2;
        int Account;
        int _Deposit;
        int _withdrawal;
     

      
       
    
      
      

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void Form2_Load_1(object sender, EventArgs e)
        {
            textBox2.Text = Convert.ToString(sum);

        }

        private void button9_Click(object sender, EventArgs e)
        {
            int sum;
            if (textBox2.Text == "0")
            {
                _withdrawal = 0;
                Form5 f5 = new Form5(textBox2.Text);
                f5.ShowDialog(this); // Shows Form5
            }
            else
            {
               
                if (_withdrawal <= (Convert.ToInt32(textBox2.Text)))
                {
                    Account2 = Account2 + _withdrawal;
                    richTextBox1.Text = "";
                    richTextBox1.Text = richTextBox1.Text + Convert.ToString(Account2);
                    sum = Account - Account2;

                    richTextBox3.Text = Convert.ToString(sum);
                    textBox2.Text = Convert.ToString(sum);
                    Form5 f5 = new Form5(textBox2.Text);
                    f5.ShowDialog(this); // Shows Form5
                }
                else
                {
                    
                    richTextBox1.Text = "";
                    richTextBox1.Text = richTextBox1.Text + Convert.ToString(Account2);
                    sum = Account - Account2;
                    richTextBox3.Text = Convert.ToString(sum);
                    textBox2.Text = Convert.ToString(sum);
                    Form5 f5 = new Form5(textBox2.Text);
                    f5.ShowDialog(this); // Shows Form5
                }

             
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            int sum;
           
                Account = Account + _Deposit;
                richTextBox2.Text = "";
                richTextBox2.Text = richTextBox2.Text + Convert.ToString(Account);
                sum = Account - Account2;
                richTextBox3.Text = Convert.ToString(sum);
                textBox2.Text = Convert.ToString(sum);
            Form5 f5 = new Form5(textBox2.Text);
            f5.ShowDialog(this); // Shows Form5

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            _Deposit = 20;
      
         
                _withdrawal = 20;
       
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            _Deposit = 50;
            _withdrawal = 50;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            _Deposit = 80;
            _withdrawal = 80;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            _Deposit = 100;
            _withdrawal = 100;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            _Deposit = 200;
            _withdrawal = 200;
        }

        private void button8_Click_1(object sender, EventArgs e)
        {
            int Number = Convert.ToInt32(textBox1.Text);

            _Deposit = Number;
            _withdrawal = Number;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        
    }
        int sum;
        private void button10_Click(object sender, EventArgs e)
        {
         
           sum= Account - Account2;
            richTextBox3.Text = Convert.ToString(sum);
            textBox2.Text = Convert.ToString(sum);

            Form5 f5 = new Form5(richTextBox3.Text);
            f5.ShowDialog(this); // Shows Form5
        }

        private void richTextBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
