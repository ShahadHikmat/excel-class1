﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Bank
{
    public partial class Form5 : Form
    {
        int total;
        public Form5(string n1)
        {
          

            InitializeComponent();
            label1.Text =n1;
         total = Convert.ToInt32(label1.Text);
        }

        private void Form5_Load(object sender, EventArgs e)
        {
           
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    
        private void button1_Click(object sender, EventArgs e)
        {
            total = Convert.ToInt32(label1.Text);
        }
    }
}
