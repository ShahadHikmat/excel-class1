﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bank
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }
        String name;
     

        private void button6_Click(object sender, EventArgs e)
        {

            name = Convert.ToString( textBox1.Text);
            int Number = Convert.ToInt32(textBox2.Text);

            label1.Text = Convert.ToString(Number);
            label2.Text = "Helll ! " + name;
            Form4 f4 = new Form4(textBox2.Text, textBox1.Text);
            f4.ShowDialog(this); // Shows Form4
        }
     
        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";


            label1.Text = "Account no.";
            label2.Text = "Account name";
            Close();
        }

     

    
    }
      


    }
    

