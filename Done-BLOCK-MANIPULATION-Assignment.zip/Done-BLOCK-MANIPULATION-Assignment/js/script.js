let block=document.getElementById("block");
let _scaleX=document.getElementById("Size")
let _scaleY=document.getElementById("Size")
console.log(block, "block");


//Position Y
let _posY = document.getElementById("pos-y");
_posY.addEventListener("input",function(){
    block.style.top=_posY.value + "px";
});


//Position X
let _posX = document.getElementById("pos-x");
_posX.addEventListener("input",function(){
    block.style.left=_posX.value + "px";
});

//ReSize
let Size= document.getElementById("Size");
Size.addEventListener("input",function(){

   
     if (shape.value==="3")
        { block.style.transform=`rotate(45deg) scale(${_scaleX.value},${_scaleY.value})`;
         block.style.borderRadius="0%"
        }
        else
        block.style.transform=`scale(${Size.value})`
});

// let string = "Hello world"
// let number = 15;
// console.log("Good afternoon " + string + number)

// console.log(`Good afternoon   ${string} ${number}`)

//opacity
let opacity= document.getElementById("opacity")
opacity.addEventListener("input",function(){
   block.style.opacity=opacity.value
});


/// Shape tupe
let shape= document.getElementById("shape-select")
let button= document.getElementById("ok-shape")

shape.addEventListener("change",function()
{
    button.addEventListener("click", function()
    {
            if (shape.value==="1")
    {
   
      block.style.borderRadius="0%"
   
    }
    else if (shape.value==="2")
{
     
   block.style.borderRadius="50%";

   }
else if (shape.value==="3")
{
   block.style.transform=`rotate(45deg) scale(${_scaleX.value},${_scaleY.value})`;
     block.style.borderRadius="0%";
 }
         

}
);


}
);


//Hex
let hexcollor= document.getElementById("hex")
hexcollor.addEventListener("keypress",function(event) {
    if (event.key === "Enter") {

   block.style.backgroundColor=`#${hexcollor.value}`
    }
});



//RGBA
let _RGBA =document.querySelectorAll(".rgba-container > input");
let _RGBAr =document.getElementById("rgba-r")
let _RGBAg =document.getElementById("rgba-g")
let _RGBAb =document.getElementById("rgba-b")
let _RGBAa =document.getElementById("rgba-a")
_RGBA.forEach((Element)=> {
    Element.addEventListener("input",function(even){
        block.style.backgroundColor=`rgba(${_RGBAr.value},${_RGBAg.value},${_RGBAb.value},${_RGBAa.value})`;

    }
    );
});

